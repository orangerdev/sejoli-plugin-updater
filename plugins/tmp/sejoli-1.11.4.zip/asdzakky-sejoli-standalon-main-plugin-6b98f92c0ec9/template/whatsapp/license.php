
*<?php _e('Kode Lisensi', 'sejoli'); ?>*

<?php echo $license['code']; ?>
