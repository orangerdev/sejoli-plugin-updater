<?php printf(__('Halo %s', 'sejoli'),'{{user-name}}' ); ?>
<?php printf( __('Berikut data diri anda di website %s, harap agar data ini disimpan', 'sejoli'), '{{sitename}}' ); ?> 
{{user-access}}
