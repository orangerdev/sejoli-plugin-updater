Hi admin, ada aorder baru dari {{buyer-name}}

{{order-detail}}
{{order-meta}}
