Nomor Invoice : *INV{{invoice-id}}*
Produk : *{{product-name}}*
Akhir Berlaku : *{{end-date}}*
