<?php printf(__('Halo %s', 'sejoli'),'{{buyer-name}}' ); ?>
<?php _e('Pesananmu telah selasi. Sebagai informasi, berikut detail pesananmu', 'sejoli'); ?>

{{order-detail}}
{{order-meta}}
