{{user-name}}, berikut akses member area {{sitename}} : {{user-access}}
