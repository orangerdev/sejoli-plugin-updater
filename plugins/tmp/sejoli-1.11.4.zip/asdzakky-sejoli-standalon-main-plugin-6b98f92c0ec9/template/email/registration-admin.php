<p><?php printf(__('Halo %s', 'sejoli'),'admin' ); ?></p>
<p><?php printf( __('Ada pendaftar baru di website %s. Berikut datanya', 'sejoli'), '{{sitename}}' ); ?></p>
{{user-access}}
