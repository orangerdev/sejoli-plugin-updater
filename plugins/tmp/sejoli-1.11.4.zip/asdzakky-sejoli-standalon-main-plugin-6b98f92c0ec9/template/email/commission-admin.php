<p><?php printf(__('Affiliasi %s mendapatkan komisi dari pesanan #%s. Informasi detailnya sebagai berikut', 'sejoli'), '{{affiliate-name}}', '{{invoice-id}}', '{{buyer-name}}' ); ?></p>
{{order-detail}}
{{order-meta}}
