<p><?php printf(__('Halo %s', 'sejoli'),'{{user-name}}' ); ?></p>
<p><?php printf( __('Berikut data diri anda di website %s, harap agar data ini disimpan', 'sejoli'), '{{sitename}}' ); ?></p>
{{user-access}}
