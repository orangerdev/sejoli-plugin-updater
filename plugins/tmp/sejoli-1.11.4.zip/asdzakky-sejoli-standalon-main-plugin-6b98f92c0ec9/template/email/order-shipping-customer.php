<p><?php _e('Halo {{buyer-name}}', 'sejoli'); ?></p>
<p><?php _e('Pesanan {{buyer-name}} telah dikirim . Berikut Detail pesanannya : ', 'sejoli'); ?></p>
{{order-detail}}
{{order-meta}}
