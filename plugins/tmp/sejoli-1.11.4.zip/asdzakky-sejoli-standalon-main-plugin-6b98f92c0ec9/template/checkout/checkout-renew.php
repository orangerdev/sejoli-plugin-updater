<?php
global $sejolisa;
extract( (array) $sejolisa['subscription']);
$post = get_post($product_id);
setup_postdata($post);

include 'header.php';
include 'header-logo.php';

$product = sejolisa_get_product($product_id);
$use_checkout_description = boolval(sejolisa_carbon_get_post_meta($post->ID, 'display_product_description'));

$parent_order = sejolisa_get_order([
    'ID' => absint($_GET['order_id'])
]);
?>

<div class="ui text container">

    <?php if(false !== $use_checkout_description) : ?>
    <div class='deskripsi-produk'>
        <?php echo apply_filters('the_content', sejolisa_carbon_get_post_meta($post->ID, 'checkout_product_description')); ?>
    </div>
    <?php endif; ?>

    <div class="produk-dibeli">
        <input type="hidden" id="qty" name="qty" value="<?php echo $parent_order['orders']['quantity']; ?>">
        <?php do_action('sejoli/checkout-template/before-product', $product); ?>
        <table class="ui unstackable table">
            <thead>
                <tr>
                    <th style="width:55%"><?php _e('Produk yang anda beli', 'sejoli'); ?></th>
                    <th style="width:45%"><?php _e('Harga', 'sejoli'); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>
                        <div class="ui placeholder">
                            <div class="image header">
                                <div class="line"></div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="ui placeholder">
                            <div class="paragraph">
                                <div class="line"></div>
                            </div>
                        </div>
                    </td>
                </tr>
            </tbody>
            <tfoot>
                <tr>
                    <th><?php _e('Total', 'sejoli'); ?></th>
                    <th>
                        <div class="total-holder">
                            <div class="ui placeholder">
                                <div class="paragraph">
                                    <div class="line"></div>
                                </div>
                            </div>
                        </div>
                    </th>
                </tr>
                <?php do_action('sejoli/checkout-template/after-product', $product); ?>
                <tr>
                    <th colspan="2">
                        <span class="secure-tagline-icon"><i class="check circle icon"></i> <?php _e('Secure 100%', 'sejoli'); ?></span>
                    </th>
                </tr>
            </tfoot>
        </table>
    </div>
    <div class="kode-diskon">
        <div class="data-holder">
            <div class="ui fluid placeholder">
                <div class="paragraph">
                    <div class="line"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="login">
        <div class="data-holder">
            <div class="ui fluid placeholder">
                <div class="paragraph">
                    <div class="line"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="informasi-pribadi">
        <div class="data-holder">
        </div>
    </div>
    <div class="metode-pembayaran">
        <h3><?php _e('Pilih Metode Pembayaran', 'sejoli'); ?></h3>
        <div class="ui doubling grid data-holder">
            <div class="eight wide column">
                <div class="ui placeholder">
                    <div class="paragraph">
                        <div class="line"></div>
                    </div>
                </div>
            </div>
            <div class="eight wide column">
                <div class="ui placeholder">
                    <div class="paragraph">
                        <div class="line"></div>
                    </div>
                </div>
            </div>
            <div class="eight wide column">
                <div class="ui placeholder">
                    <div class="paragraph">
                        <div class="line"></div>
                    </div>
                </div>
            </div>
            <div class="eight wide column">
                <div class="ui placeholder">
                    <div class="paragraph">
                        <div class="line"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="beli-sekarang element-blockable">
        <div class="data-holder">
            <div class="ui fluid placeholder">
                <div class="paragraph">
                    <div class="line"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="affiliate-name" style='padding-top:4rem'>

    </div>
    <div class="alert-holder checkout-alert-holder"></div>
</div>
<script id="produk-dibeli-template" type="text/x-jsrender">
    {{if product}}
        <tr>
            <td>
                <div class="ui stackable grid">
                    {{if product.image}}
                        <div class="four wide column">
                            <img src="{{:product.image}}">
                        </div>
                    {{/if}}
                    <div class="twelve wide column">
                        {{:product.title}} X {{:product.quantity}}
                        {{if subscription}}
                            {{if subscription.duration}}
                                <br>Durasi: {{:subscription.duration.string}}
                            {{/if}}
                        {{/if}}
                        <input type="hidden" id="product_id" name="product_id" value="{{:product.id}}">
                        <?php
                        $enable_quantity = sejolisa_carbon_get_post_meta( get_the_ID(), 'enable_quantity' );
                        if ( $enable_quantity ) :
                            ?>
                            <div class="ui labeled input">
                                <label class='ui label' for='qty' style='line-height:150%'><?php _e('Jumlah pembelian', 'sejoli'); ?></label>
                                <input type="number" class="qty change-calculate-affect-qty" name="qty" id="qty" value="1" min="1" placeholder="Qty">
                                <!-- <span class="stock"><?php _e('stok tersisa', 'sejoli'); ?> <span class="stock-value">{{:product.stock}}</span> <?php _e('pcs', 'sejoli'); ?></span> -->
                            </div>
                            <?php
                        else : ?>
                        <input type="hidden" class="qty change-calculate-affect-qty" name="qty" id="qty" value="1" placeholder="<?php _e('Qty', 'sejoli'); ?>">
                        <?php endif; ?>
                    </div>
                </div>
            </td>
            <td>{{:product.price}}</td>
        </tr>
    {{/if}}
    {{if subscription}}
        {{if subscription.signup}}
            <tr>
                <td><?php _e('Biaya Awal', 'sejoli'); ?></td>
                <td>{{:subscription.signup.price}}</td>
            </tr>
        {{/if}}
    {{/if}}
    {{if coupon}}
        <tr>
            <td>
                Kode diskon: {{:coupon.code}}, <a class="hapus-kupon"><?php _e('Hapus kupon', 'sejoli'); ?></a>
                <input type="hidden" id="coupon" name="coupon" value="{{:coupon.code}}">
            </td>
            <td>{{:coupon.value}}</td>
        </tr>
    {{/if}}
    {{if wallet}}
        <tr>
            <td>
                <?php _e('Dana di dompet yang anda gunakan', 'sejoli'); ?>
            </td>
            <td>{{:wallet}}</td>
        </tr>
    {{/if}}
    {{if transaction}}
        <tr class="biaya-transaksi">
            <td><?php _e('Biaya Transaksi', 'sejoli'); ?></td>
            <td>{{:transaction.value}}</td>
        </tr>
    {{/if}}
</script>
<script id="metode-pembayaran-template" type="text/x-jsrender">
    {{if payment_gateway}}
        {{props payment_gateway}}
            <div class="eight wide column">
                <div class="ui radio checkbox {{if key == 0}}checked{{/if}}">
                    <input type="radio" name="payment_gateway" tabindex="0" class="hidden" value="{{>prop.id}}" {{if key == 0}}checked="checked"{{/if}}>
                    <label><img src="{{>prop.image}}" alt="{{>prop.title}}"></label>
                </div>
            </div>
        {{/props}}
    {{/if}}
</script>
<script id="alert-template" type="text/x-jsrender">
    <div class="ui {{:type}} message">
        <i class="close icon"></i>
        <div class="header">
            {{:type}}
        </div>
        {{if messages}}
            <ul class="list">
                {{props messages}}
                    <li>{{>prop}}</li>
                {{/props}}
            </ul>
        {{/if}}
    </div>
</script>
<script id="login-template" type="text/x-jsrender">
    <div class="login-welcome">
        <p>&nbsp;</p>
    </div>
</script>
<script id="apply-coupon-template" type="text/x-jsrender">
    <?php if(false !== $product->form['coupon_field']) : ?>
    <div id='kode-diskon-form-toggle' class="kode-diskon-form-toggle">
        <p><img src="<?php echo SEJOLISA_URL; ?>public/img/voucher.png"> <?php _e('Punya Kode Diskon', 'sejoli'); ?> ? <a><?php _e('Klik Untuk Masukkan Kode', 'sejoli'); ?></a></p>
    </div>
    <div id='kode-diskon-form' class="kode-diskon-form">
        <h4><?php _e('Kode Diskon', 'sejoli'); ?></h4>
        <p><?php _e('Masukan kode jika anda punya', 'sejoli'); ?></p>
        <div class="ui fluid action input">
            <input type="text" name="apply_coupon" id="apply_coupon" placeholder="<?php _e('Masukan kode diskon', 'sejoli'); ?>">
            <button type="submit" id='sejoli-submit-coupon' class="submit-coupon massive ui green button"><?php _e('APPLY', 'sejoli'); ?></button>
        </div>
        <div class="alert-holder coupon-alert-holder"></div>
    </form>
    <?php endif; ?>
</script>
<script id="informasi-pribadi-template" type="text/x-jsrender">
    <div class="informasi-pribadi-info">
        <p><?php _e('Isi data-data di bawah untuk informasi akses di website ini. <br />Data dibawah ini akan digunakan untuk kepentingan mengakses halaman member serta informasi terkait pembelian.', 'sejoli'); ?></p>
    </div>
    <h3>Informasi Pribadi</h3>
    <div class="ui form">
        <div class="required field">
            <label><?php _e('Nama Lengkap', 'sejoli'); ?></label>
            <p><?php _e('Harap masukkan nama lengkap anda demi kemudahaan agar jika suatu saat diperlukan pencarian data.', 'sejoli'); ?></p>
            <input type="text" name="user_name" id="user_name" placeholder="<?php _e('Masukan nama lengkap anda', 'sejoli'); ?>">
        </div>
        <div class="required field">
            <label><?php _e('Alamat Email', 'sejoli'); ?></label>
            <p><?php _e('Kami akan mengirimkan konfirmasi pembayaran dan password ke alamat ini', 'sejoli'); ?></p>
            <input type="email" name="user_email" id="user_email" placeholder="<?php _e('Masukan alamat email yang akan anda daftarkan di website ini', 'sejoli'); ?>">
            <div class="alert-holder user-email-alert-holder"></div>
        </div>
        <div class="required field">
            <label><?php _e('Password', 'sejoli'); ?></label>
            <p><?php _e('Pastikan anda menyimpan atau mengingat password yang anda tulis. Password dibawah ini berfungsi untuk anda bisa mengakses halaman member', 'sejoli'); ?></p>
            <input type="password" name="user_password" id="user_password" placeholder="<?php _e('Tuliskan password yang akan anda gunakan untuk website ini', 'sejoli'); ?>" autocomplete='false'>
        </div>
        <div class="required field">
            <label><?php _e('Nomor Handphone', 'sejoli'); ?></label>
            <p><?php _e('Kami akan menggunakan no handphone untuk keperluan administrasi', 'sejoli'); ?></p>
            <input type="text" name="user_phone" id="user_phone" placeholder="<?php _e('Masukan nomor handphone yang terhubung dengan WhatsApp', 'sejoli'); ?>">
            <div class="alert-holder user-phone-alert-holder"></div>
        </div>
    </div>
</script>
<script id="beli-sekarang-template" type="text/x-jsrender">
    <div class="ui stackable grid">
        <div class="eight wide column">
            <div id='sejoli-total-bayar' class="total-bayar">
                <h4><?php _e('Total Bayar', 'sejoli'); ?></h4>
                <div class="total-holder">
                    <div class="ui placeholder">
                        <div class="paragraph">
                            <div class="line"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="eight wide column">
            <button data-fb-pixel-event="<?php echo isset( $fb_pixel['links']['submit']['type'] ) ? $fb_pixel['links']['submit']['type'] : ''; ?>" type="submit" class="submit-button massive right floated ui green button"><?php _e('PROSES SEKARANG', 'sejoli'); ?></button>
        </div>
    </div>
</script>
<script type='text/javascript'>
(function($){
    $(document).ready(function(){
        sejoliSaCheckoutRenew.init();
    });
})(jQuery);
</script>
<?php
include 'footer-renew.php';
include 'footer.php';
