<?php
/**
 * @since   1.0.0
 * @since   1.5.1.1     Change facebook support to fanpage
 */
defined( 'ABSPATH' ) || exit;

if(!current_user_can('manage_sejoli_orders')) { return; } ?>
<div class="notice notice-info is-dismissible sejoli-help-message">
    <h2><?php _e('Penggunaan SEJOLI', 'sejoli'); ?></h2>
    <p><?php _e('Yang perlu anda atur untuk penggunaan SEJOLI adalah sebagai berikut :', 'sejoli'); ?></p>
    <p>
        <a href='<?php echo admin_url('admin.php?page=crb_carbon_fields_container_sejoli.php'); ?>' class='button button-primary'><?php _e('Pengaturan Umum', 'sejoli'); ?></a>
        <a href='<?php echo admin_url('admin.php?page=crb_carbon_fields_container_'.__('notifikasi', 'sejoli').'.php'); ?>' class='button button-primary'><?php _e('Pengaturan Notifikasi', 'sejoli'); ?></a>
        <a href='<?php echo admin_url('admin.php?page=sejoli-coupons'); ?>' class='button button-primary'><?php _e('Pengaturan Kupon', 'sejoli'); ?></a>
        <a href='<?php echo admin_url('post-new.php?post_type=sejoli-product'); ?>' class='button button-primary'><?php _e('Buat Produk', 'sejoli'); ?></a>
        <a href='<?php echo admin_url('post-new.php?post_type=sejoli-access'); ?>' class='button button-primary'><?php _e('Buat Akses Produk', 'sejoli'); ?></a>
        <a href='http://facebook.com/sejoli.id' target="_blank" class='button' style='background-color: #007100;color: white;border-color: #007100;'><?php _e('Facebook Fanpage Support', 'sejoli'); ?></a>
    </p>
</div>
