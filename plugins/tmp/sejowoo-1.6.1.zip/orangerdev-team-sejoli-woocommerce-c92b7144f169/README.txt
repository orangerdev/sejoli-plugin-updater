=== Plugin Name ===
Contributors: ridwanarifandi
Donate link: https://ridwan-arifandi.com
Tags: membership, affiliate, wallet, woocommerce
Requires at least: 5.4.0
Tested up to: 6.0.1
Stable tag: 1.6.1

Premium membership, affiliate and reseller plugin

== Description ==

Coming soon

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `sejoli.zip` to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Input your license key with sejoli member access data

== Frequently Asked Questions ==

Coming soon

== Screenshots ==

Coming soon

== Changelog ==

1.6.1 31 Oktober 2022
* Fix issue with licensing

1.6.0
* Add reduction shipping cost by coupon
* Add user group setting to variation product
* Enable admin to create affiliate coupon
* Integrate with woongkir ( no need to install anymore )
* Fix issue with license reset

1.5.0 18 July 2022
* Add different user group registration both in checkout dan registration form
* Add translation to english and indonesia
* Fix issue in commission

1.4.2 3 April 2022
* Hide non-affiliated coupon from affiliate link generator
* Remove warning and notice messages
* Fix bug in 'kaitkan affiliasi'
* Fix commission issue in multi-tier affiliate

1.4.1 17 Februari 2022
* Fix responsive member area

1.4.0 3 Desember 2021
* Add feature to setup affiliate user
* Fix commission problem
* Fix discount price based on user group price
* Fix affiliate cookie issue
* Fix product field type number for cashback value
* Fix onsale badge for variable product
* Fix display user phone data in user management page

1.3.2 1 November 2021
* Display discount badge for user with user group and special price
* Fix wallet issue ( Produk telah dihapus )
* Fix affiliate form issue
* Fix applied affiliate coupon with cookie
* Fix product price calculation based on user group
* Fix affiliate link generator with or without coupon

1.3.1 07 September 2021
* Fix product price calculated by user group in REST API
* Fix social proof notification

1.3.0 17 Agustus 2021
* Display user group in user profile
* Fix cashback issue for user group per product setting
* Fix issue with thrive apprentice
* Fix wallet issue if the product is deleted

1.2.1.2 04 Mei 2021
* Fix critical issue with coupon link in affiliate link generator

1.2.1.1 03 Mei 2021
* Fix issue in social proof
* Remove buyer validation on adding commission

1.2.1 31 Maret 2021
* Enhance is_wc_endpoint_url, problem with WooCommerce 5.1.0 and WordPress 5.7.0
* Remove unneeded hooks

1.2.0 29 Maret 2021
* Add leaderboard function
* Fix issue with hide several my-account menu
* Enhance Dokan setup

= 1.1.2.3 09 Februari 2021 =
* Fix unloaded carbonfield library in some case

= 1.1.2.2 =
* Fix wrong admin recipient for all request fund emails
* Fix conditional logic for min_request_fund
* Add reload page after submit the request fund form

= 1.1.2.1 =
* Add variation product in product options
* Add admin action to check both product and order commission
* Add option to hide several section in vendor product editor
* Fix social proof layout that block any element
* Critical issue when set user affiliate and commission calculation, change important hook from woocommerce_checkout_order_created to woocommerce_checkout_order_processed

= 1.1.2 =
* Enhance user group update and filter
* Fix discount issue with user group data
* Fix commission issue with product variation
* Restructurize member area menu

= 1.1.1 =
* Fix issue with variation save data

= 1.1.0 =
* Add integration with Dokan Marketplace
* Add minimum and maximum admin commission from Dokan order system
* Add minimum value for request fund
* Add multiple product update for commission, cashback and price modification
* Fix issue when plugin activation without WooCommerce
* Fix issue with variation cashback and commission data
* Fix cashback issue with WooCommerce STM LMS

= 1.0.3 =
* Add cashback setting in each product
* Add possibility to add cashback value for non-registered user

= 1.0.2 =
* Add setting to set default user group when a user registered
* Fix mistypo
* Fix issue with carbon_get_theme_option

= 1.0.1 =
* Add function to affiliate to disable use own affiliate data
* Fix issue in social proof with the date
* Fix issue with wallet theme options
* Fix wrong hook name for affiliate-order

= 1.0.0 =
* First release
