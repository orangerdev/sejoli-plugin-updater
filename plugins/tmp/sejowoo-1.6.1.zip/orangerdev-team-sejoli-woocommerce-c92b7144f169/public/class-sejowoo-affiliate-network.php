<?php

namespace Sejowoo\Front;

/**
 * The affiliate-network public-facing functionality of the plugin.
 *
 * @link       https://sejoli.co.id
 * @since      1.0.0
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/public
 */
class AffiliateNetwork {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Check if current method is already called
	 * @since	1.1.2.1
	 * @var 	boolean
	 */
	protected $is_called = false;

	/**
	 * Hide affiliate network menu
	 * @since 	1.1.2.2
	 * @var 	boolean
	 */
	protected $is_menu_hidden = true;

	/**
	 * Custom endpoint name.
	 *
	 * @var string
	 */
	public static $endpoint = 'affiliate-network';

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since 	1.0.0
	 * @param 	string    $plugin_name       The name of the plugin.
	 * @param   string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version 	   = $version;

	}


	/**
	 * Register new endpoint to use inside My Account page.
	 *
	 * @see https://developer.wordpress.org/reference/functions/add_rewrite_endpoint/
	 */
	public function add_endpoints() {
		
		add_rewrite_endpoint( self::$endpoint, EP_ROOT | EP_PAGES );
	
	}

	/**
	 * Add new query var.
	 *
	 * @param array $vars
	 * @return array
	 */
	public function add_query_vars( $vars ) {
	
		$vars[] = self::$endpoint;

		return $vars;
	
	}

    /**
     * Register my-account endpont
     * Hooked via filter sejowoo/my-account-endpoint/vars, priority 16
     * @since   1.0.0
	 * @since 	1.1.2 		Add condition to hide link
	 * @since 	1.1.2.2
     * @param   array   	$query_vars
     * @return  array
     */
    public function register_my_account_endpoint( $query_vars ) {

		if(
			false === $this->is_called &&
			sejowoo_user_can_affiliate() &&
			true !== sejowoo_get_plugin_setup_options()['hide-affiliate-network']
		) :

			$query_vars['affiliate-network'] = 'affiliate-network';
			$this->is_menu_hidden = false;
			$this->is_called = true;

		endif;

        return $query_vars;
    
    }

    /**
     *  Add custom woocommerce my account links
     *  Hooked via filter sejowoo/myaccount/links, priority 30
     *  @since 	1.0.0
     *  @since 	1.1.2 		Change hook point
     *  @since 	1.1.2.2		Change on how to hide the menu
     *  @param 	array 		$menu_links
     *  @return array
     */
    public function add_my_account_links( array $links ){

		if(
			sejowoo_user_can_affiliate() &&
			true !== $this->is_menu_hidden
		) :

			$links['affiliate-network'] = __('Jaringan Affiliasi', 'sejowoo' );

		endif;

        return $links;

    }

	/**
	 * Register needed css and js files
	 * Hooked via action wp_enqueue_scripts, priority 133
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function register_css_and_js_files( ) {

		global $wp_query;

		wp_register_script 	( 'jstree',	'https://cdnjs.cloudflare.com/ajax/libs/jstree/3.3.10/jstree.min.js', array('jquery'), '3.3.10', true);
		wp_register_style 	( 'jstree', 'https://cdnjs.cloudflare.com/ajax/libs/jstree/3.3.10/themes/default/style.min.css', '3.3.10' );

		if( is_account_page() && isset($wp_query->query['affiliate-network'])) :

			wp_enqueue_script 	( 'jstree' );
			wp_enqueue_script 	( 'jsrender' );
			wp_enqueue_script 	( 'jquery-blockui' );

			wp_enqueue_style 	( 'jstree' );
		endif;

	}

	/**
	 * Set my-account localize javascript data
	 * Hooked via filter sejowoo/myaccount/js-localize-data, priority 133
	 * @since 	1.0.0
	 * @param 	array $vars
	 * @return 	array
	 */
	public function set_localize_js_vars( array $vars ) {

		$vars['network'] = array(
			'list' => array(
				'ajaxurl'	=> add_query_arg(array(
								'nonce' => wp_create_nonce('sejowoo-get-network-list'),
							   ),site_url('sejowoo-ajax/get-network-list')),
			),
			'detail' => array(
				'ajaxurl'	=> add_query_arg(array(
								   'nonce' => wp_create_nonce('sejowoo-get-network-detail'),
							   ),site_url('sejowoo-ajax/get-network-detail')),
			)
		);
	
		return $vars;
	
	}

    /**
     * Set my-account page title
     * Hooked via filter woocommerce_endpoint_affiliate-network_title, priority 133
     * @since   1.0.0
     * @param   string  $title
     * @return  string
     */
    public function set_my_account_title( $title ) {
    
        return __('Jaringan Affiliasi', 'sejowoo');
    
    }

    /**
     * Set my-account page content
     * Hooked via action woocommerce_account_affiliate-network_endpoint, priority 1
     * @since   1.0.0
     * @return  void
     */
    public function set_my_account_content( ) {

        wc_get_template(
            'my-account/affiliate/network.php',
            array(),
            SEJOWOO_DIR . 'templates/',
            SEJOWOO_DIR . 'templates/'
        );
    
    }

}
