<?php

namespace Sejowoo\Front;

class Commission {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.1.2
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.1.2
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.1.2
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

    /**
     * Calculate potensial commission and display it to query_monitor
     * Hooked via action woocommerce_before_checkout_form, priority 10
     * @since   1.1.2
     * @return  void
     */
    public function calculate_potential_commission() {

        $debug_enable = boolval( carbon_get_theme_option( 'sejowoo_debug_enable' ) );

        if( true !== $debug_enable ) :
            return;
        endif;

        global $woocommerce;

        $commission_data = array();

        foreach( (array) $woocommerce->cart->get_cart() as $cart_key => $item ) :

            $product_id       = ( 0 < absint( $item['variation_id'] ) ) ? $item['variation_id'] : $item['product_id'];
            $commission_setup = sejowoo_get_product_commission_setup( $product_id );

            $commission_data[] = array(
                'product'    => $product_id,
                'commission' => $commission_setup
            );

        endforeach;

    }

}
