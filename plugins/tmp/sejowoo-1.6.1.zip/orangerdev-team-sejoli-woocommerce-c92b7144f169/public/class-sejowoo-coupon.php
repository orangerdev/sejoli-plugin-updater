<?php

namespace Sejowoo\Front;

class Coupon {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Check if current method is already called
	 * @since	1.1.2.1
	 * @var 	boolean
	 */
	protected $is_called = false;

	/**
	 * Hide affiliate link menu
	 * @since	1.1.2.2
	 * @var 	boolean
	 */
	protected $is_menu_hidden = true;

	/**
	 * Custom endpoint name.
	 *
	 * @var string
	 */
	public static $endpoint = 'affiliate-coupon';

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

	}

	/**
	 * Register new endpoint to use inside My Account page.
	 *
	 * @see https://developer.wordpress.org/reference/functions/add_rewrite_endpoint/
	 */
	public function add_endpoints() {

		add_rewrite_endpoint( self::$endpoint, EP_ROOT | EP_PAGES );

	}

	/**
	 * Add new query var.
	 *
	 * @param array $vars
	 * @return array
	 */
	public function add_query_vars( $vars ) {

		$vars[] = self::$endpoint;

		return $vars;

	}

	/**
	 * Set affiliate coupon based on affiliate link
	 * Hooked via action sejowoo/affiliate/set-cookie, priority 144
	 * @since 	1.0.0
	 */
	public function set_affiliate_coupon() {

		if(
			isset($_GET['coupon'])		) :

			unset($_COOKIE['sejowoo_affiliate_coupon']);
		    setcookie('sejowoo_affiliate_coupon', $_GET['coupon'], time() + (86400 * 30), "/"); // 86400 = 1 day

		endif;

	}

	/**
	 * Set affiliate coupon based on affiliate link in cart & checkout page
	 * Hooked via action init, priority 100
	 * @since 	1.0.0
	 */
	public function apply_affiliate_coupon_in_cart_checkout_page() {

		if(isset($_COOKIE['sejowoo_affiliate_coupon'])) :

	    	if(is_cart() || is_checkout()) :

	    		if(!in_array( strtolower($_COOKIE['sejowoo_affiliate_coupon']), WC()->cart->applied_coupons)) :

			    	WC()->cart->add_discount( sanitize_text_field( $_COOKIE['sejowoo_affiliate_coupon'] ) );

					$notices = WC()->session->get('wc_notices', array());

					unset($notices['error'], $notices['success'], $notices['info']);

					WC()->session->set('wc_notices', $notices);

	    		endif;

			endif;

	   	endif;

	}

	/**
	 * Overwrite current user affiliate if affiliate coupon applied
	 * Hooked via filter sejowoo/user/affiliate, priority 100
	 * @since 	1.0.0
	 * @param 	integer 		$affiliate_id
	 * @param 	integer 		$user_id
	 * @param 	string  		$from
	 * @param 	false|WC_Order 	$order
	 * @return 	integer	 		If there is any affiliated coupon and permanent affiliate is disabled, will return with author of affiliated coupon
	 */
	public function set_user_affiliate( int $affiliate_id, $user_id = 0, $from = '', $order = false) {

		// overwrite current affiliate if affiliate is not permanent
		if(
			'user-meta' !== $from || $affiliate_id === 0 &&
			!empty(carbon_get_theme_option('sejowoo_permanent_affiliate')) || empty(carbon_get_theme_option('sejowoo_permanent_affiliate'))
		) :

			if( is_a($order, 'WC_Order') ) :
				$coupons = $order->get_coupon_codes();
			else :
				$coupons = WC()->cart->get_applied_coupons();
			endif;

			foreach( (array) $coupons as $coupon_code ) :

				$coupon_post = get_page_by_title( $coupon_code, OBJECT, SEJOWOO_COUPON_CPT );

				// Only apply affiliated coupon
				if( !empty($coupon_post->post_parent) && !empty($coupon_post->post_author) ) :

					return intval( $coupon_post->post_author );

				endif;

			endforeach;
		endif;

		return (int) $affiliate_id;

	}

	/**
     * Register my-account endpont
     * Hooked via filter sejowoo/my-account-endpoint/vars, priority 14
     * @since   1.0.0
	 * @since 	1.1.2 	Add condition to hide link
     * @param   array   $query_vars
     * @return  array
     */
    public function register_my_account_endpoint( $query_vars ) {

		if(
			false === $this->is_called &&
			sejowoo_user_can_affiliate() &&
			true !== sejowoo_get_plugin_setup_options()['hide-affiliate-coupon']
		) :

        	$query_vars['affiliate-coupon'] = 'affiliate-coupon';

			$this->is_menu_hidden = false;
			$this->is_called      = true;

		endif;

        return $query_vars;

    }

	/**
     *  Add custom woocommerce my account links
     *  Hooked via filter sejowoo/myaccount/links, priority 20
     *  @since 	1.0.0
     *  @since 	1.1.2 	Change hook point
     *  @param 	array 	$menu_links
     *  @return array
     */
    public function add_my_account_links( array $links ){

		if(
			sejowoo_user_can_affiliate() &&
			true !== $this->is_menu_hidden
		) :

	        $links['affiliate-coupon']	= __('Kupon Affiliasi', 'sejowoo' );

		endif;

        return $links;

    }

	/**
	 * Set if current page is sejowoo page
	 * Hooked via action template_redirect, priority 144
	 * @since 	1.0.0
	 */
	public function set_is_sejowoo_page() {

		if( sejowoo_check_endpoint_url('affiliate-coupon') ) :

			do_action('sejowoo/myaccount/set-sejowoo-page', true);

		endif;

	}

	/**
	 * Set my-account localize javascript data
	 * Hooked via filter sejowoo/myaccount/js-localize-data, priority 144
	 * @since 	1.0.0
	 * @param 	array $vars
	 * @return 	array
	 */
	public function set_localize_js_vars( array $vars ) {

		$vars['coupon'] = array(
			'create'	=> array(
				'ajaxurl'	=> site_url('sejowoo-ajax/create-affiliate-coupon')
			),
			'table' 	=> array(
				'ajaxurl' => site_url('sejowoo-ajax/render-affiliate-coupon-table'),
				'nonce'   => wp_create_nonce('sejowoo-render-affiliate-coupon-table')
			),
			'parent_list' => array(
				'ajaxurl'	=> add_query_arg(array(
								'nonce' => wp_create_nonce('sejowoo-get-parent-coupon-list'),
							   ),site_url('sejowoo-ajax/get-parent-coupon-list')),
			)
		);

		return $vars;

	}

    /**
     * Set my-account page title
     * Hooked via filter woocommerce_endpoint_affiliate-coupon_title, priority 144
     * @since   1.0.0
     * @param   string  $title
     * @return  string
     */
    public function set_my_account_title( $title ) {

        return __('Kupon Affiliasi', 'sejowoo');

    }

    /**
     * Set my-account page content
     * Hooked via action woocommerce_account_affiliate-coupon_endpoint, priority 1
     * @since   1.0.0
     * @return  void
     */
    public function set_my_account_content( ) {

        wc_get_template(
            'my-account/affiliate/coupon.php',
            array(),
            SEJOWOO_DIR . 'templates/',
            SEJOWOO_DIR . 'templates/'
        );

    }

	public function set_shipping_cost_reduction() {

		$shipping_total = WC()->cart->get_shipping_total();

		if( 0 === $shipping_total ) :
			return;
		endif;

		foreach( (array) WC()->cart->get_applied_coupons() as $coupon_code ) :

			$coupon = new \WC_Coupon( $coupon_code );

			if(
				"yes" === $coupon->get_meta( "enable_shipping_cost_reduction", true) &&
				0 < floatval($coupon->get_meta( "shipping_cost_reduction_term")) &&
				floatval($coupon->get_meta( "shipping_cost_reduction_term")) <= WC()->cart->get_cart_contents_total()
			) :

				$percentage = absint( $coupon->get_meta( "shipping_cost_reduction_percentage", true) );
				$amount     = absint( $coupon->get_meta( "shipping_cost_reduction_amount", true) );

				$discount = $shipping_total * $percentage / 100;
				$discount = ( $amount < $discount ) ? $amount : $discount;

				WC()->cart->add_fee(
					__("Subsidi Ongkos Kirim", "sejowoo"),
					-$discount
				);

			endif;

		endforeach;
	}

}
