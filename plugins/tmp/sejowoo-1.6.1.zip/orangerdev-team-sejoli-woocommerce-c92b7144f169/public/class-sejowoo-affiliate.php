<?php

namespace Sejowoo\Front;

use Delight\Cookie\Cookie;

/**
 * The affiliate public-facing functionality of the plugin.
 *
 * @link       https://sejoli.co.id
 * @since      1.0.0
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/public
 */
class Affiliate {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Affiliasi data
	 * @since 	1.0.0
	 * @access	protected
	 */
	protected $affiliate = false;

	/**
	 * Refere data
	 * @since 	1.0.0
	 * @access	protected
	 */
	protected $target = false;

	/**
	 * Set if current request is already checked
	 * @since 	1.0.0
	 * @var 	boolean
	 */
	protected $checked = false;

	/**
	 * Check if current method is already called
	 * @since	1.1.2.1
	 * @var 	boolean
	 */
	protected $is_called = false;

	/**
	 * Hide affiliate link menu
	 * @since	1.1.2.2
	 * @var 	boolean
	 */
	protected $is_menu_hidden = true;

	/**
	 * Custom endpoint name.
	 *
	 * @var string
	 */
	public static $endpoint = 'affiliate-link';

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since 	1.0.0
	 * @param 	string    $plugin_name       The name of the plugin.
	 * @param   string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version 	   = $version;

	}

	/**
	 * Register new endpoint to use inside My Account page.
	 *
	 * @see https://developer.wordpress.org/reference/functions/add_rewrite_endpoint/
	 */
	public function add_endpoints() {

		add_rewrite_endpoint( self::$endpoint, EP_ROOT | EP_PAGES );

	}

	/**
	 * Add new query var.
	 *
	 * @param array $vars
	 * @return array
	 */
	public function add_query_vars( $vars ) {

		$vars[] = self::$endpoint;

		return $vars;

	}

	/**
     *  Set end point custom menu
     *  Hooked via action init, priority 100
     *  @since 	1.0.0
     *  @param 	void
     *  @return void
     */
    public function set_endpoint()
    {

		// Register affiliate link
		add_rewrite_rule( '^aff/([^/]*)/([^/]*)/?',	'index.php?affiliate-link-redirect=1&affiliate=$matches[1]&target=$matches[2]','top');
		add_rewrite_rule( '^aff/([^/]*)/?',			'index.php?affiliate-link-redirect=1&affiliate=$matches[1]','top');

        flush_rewrite_rules();

	}

	/**
	 * Register my-account endpoint
	 * Hooked via filter sejowoo/my-account-endpoint/vars, priority 10
	 * @since 	1.0.0
	 * @since 	1.1.2 	Add condition to hide link
	 * @param  	array  $vars
	 * @return 	array
	 */
	public function register_my_account_endpoint( array $vars ) {

		if(
			sejowoo_user_can_affiliate() &&
			false === $this->is_called &&
			true !== sejowoo_get_plugin_setup_options()['hide-affiliate-link']
		) :

			$vars['affiliate-link']  = 'affiliate-link';
			$this->is_menu_hidden = false;
			$this->is_called = true;

		endif;

		return $vars;

	}

    /**
     * Set custom query vars
     * Hooked via filter query_vars, priority 999
     * @since   1.0.0
     * @access  public
     * @param   array $vars
     * @return  array
     */
    public function set_query_vars( $vars = array() ){

        $vars[] = 'affiliate-link-redirect';
		$vars[] = 'affiliate';
		$vars[] = 'target';

        return $vars;

    }

	/**
	 * Set affiliate data to cookie
	 * Hooked via action sejowoo/affiliate/set-cookie, priority 1
	 * @since 	1.0.0
	 * @param 	array 	$args
	 * @return 	void
	 */
	public function set_cookie(array $args) {

		$affiliate_id        = ( !empty($args['affiliate']) ) ? $args['affiliate']->ID : '';
		$cookie_name         = sejowoo_get_cookie_name();
		$cookie_age          = absint( carbon_get_theme_option('sejowoo_cookie_age') );
		$lifespan_cookie_day = time() + ( DAY_IN_SECONDS * $cookie_age );
		$affiliate_data      = $current_cookie = sejowoo_get_affiliate_cookie();

		$affiliate_data['general'] = $affiliate_id;
		$affiliate_data = apply_filters('sejowoo/affiliate/cookie-data', $affiliate_data, $affiliate_id);

		setcookie($cookie_name, serialize($affiliate_data), $lifespan_cookie_day, COOKIEPATH, COOKIE_DOMAIN);

	}

	/**
	 * Redirect customer to selected sales page
	 * Hooked via action sejowoo/affiliate/redirect, priority 999
	 * @since 	1.0.0
	 * @param 	array 	$args
	 * @return 	void
	 */
	public function redirect(array $args) {

		global $wp_query;

		$redirect_link = NULL;

        if(isset($wp_query->query_vars['affiliate-link-redirect'])) :

			// Get redirect link from affiliate CPT
			if( false !== $this->target ) :

				$affiliate_page = get_page_by_path( $this->target, OBJECT, SEJOWOO_AFFILIATE_CPT);

				if( is_a( $affiliate_page,  'WP_Post') ) :
					$redirect_link  = esc_url( carbon_get_post_meta($affiliate_page->ID, 'link_redirect') );
				endif;

			endif;

			if(empty($redirect_link)) :
				$redirect_link 	= esc_url(home_url('/'));
			endif;

			if(empty($redirect_link)) :

				wp_die(
					__('Terjadi kesalahan pada link affiliate. Kontak pemilik website ini', 'sejowoo'),
					__('Kesalahan pada pengalihan', 'sejowoo')
				);

			endif;

			wp_redirect($redirect_link);

			exit;

		endif;

	}

    /**
     * Check parse query and if aff found, $enable_framework will be true
     * Hooked via action parse_query, priority 100
     * @since 	1.0.0
     * @access 	public
     * @return 	void
     */
    public function check_parse_query() {

		global $wp_query;

		if(is_admin()) :
			return;
		endif;

		if($this->checked) :
			return;
		endif;

        if(
			isset($wp_query->query_vars['affiliate-link-redirect']) &&
			false === $this->checked
		) :

			$this->checked = true;

			$args = array(
				'affiliate' => null
			);

			if(isset($wp_query->query_vars['affiliate']) && !empty($wp_query->query_vars['affiliate'])) :
				$this->affiliate = $wp_query->query_vars['affiliate'];
			endif;

			if(isset($wp_query->query_vars['target']) && !empty($wp_query->query_vars['target'])) :
				$this->target = $wp_query->query_vars['target'];
			endif;

			$affiliate 	= get_user_by('id', $this->affiliate);

			if(!is_a($affiliate, 'WP_User')) :
				wp_die(
					__('Affiliasi tidak terdaftar di database', 'sejowoo'),
					__('Affiliasi tidak valid', 'sejowoo')
				);
				exit;
			endif;

			if( ! sejowoo_user_can_affiliate( $affiliate->ID ) ) :

				wp_die(
					__('User ini tidak memiliki hak untuk menjadi affiliasi', 'sejowoo'),
					__('Affiliasi tidak valid', 'sejowoo')
				);

				exit;
			endif;

			$args['affiliate'] = $affiliate;

			do_action('sejowoo/affiliate/set-cookie', 	$args);
			do_action('sejowoo/affiliate/redirect', 	$args);

			exit;

        endif;

    }

	/**
	 * Set if current page is sejowoo page
	 * Hooked via action template_redirect, priority 111
	 * @since 	1.0.0
	 * @since 	1.2.1	Enhance is_wc_endpoint_url
	 */
	public function set_is_sejowoo_page() {

		if( sejowoo_check_endpoint_url('affiliate-link') ) :

			do_action('sejowoo/myaccount/set-sejowoo-page', true);

		endif;

	}

	/**
	 * Set my-account localize javascript data
	 * Hooked via filter sejowoo/myaccount/js-localize-data, priority 111
	 * @since 	1.0.0
	 * @param 	array $vars
	 * @return 	array
	 */
	public function set_localize_js_vars( array $vars ) {

		$vars['affiliate'] = array(
			'coupon_list'	=> array(
				'ajaxurl'	=> add_query_arg(
									array(
										'nonce'	=> wp_create_nonce('sejowoo-get-affiliate-coupon-list')
									),
									site_url('sejowoo-ajax/get-available-coupon-list')
							   )
			)
		);

		return $vars;

	}

	/**
     *  Add custom woocommerce my account links
     *  Hooked via filter sejowoo/myaccount/links, priority 10
     *  @since 	1.0.0
     *  @since 	1.1.2 	Change hook point
     *  @param 	array 	$menu_links
     *  @return array
     */
    public function add_my_account_links( array $links ){

		if(
			sejowoo_user_can_affiliate() &&
			true !== $this->is_menu_hidden
		) :

			$links['affiliate-link'] = __('Link Affiliasi', 'sejowoo' );

		endif;

        return $links;

    }

	/**
	 * Set my-account page title
	 * Hooked via woocommerce_endpoint_affiliate_title, priority 1
	 * @since 	1.0.0
	 * @param 	string 	$title
	 * @return 	string
	 */
	public function set_my_account_title( $title ) {

		return __('Link Affiliasi', 'sejowoo');

	}

	/**
     *  Add affiliate link endpoint page content
     *  Hooked via action woocommerce_account_affiliate-link_endpoint, priority 1
     *  @since 	1.0.0
     *  @return void
     */
    public function set_my_account_content() {

		wc_get_template(
            'my-account/affiliate/link.php',
            array(),
            SEJOWOO_DIR . 'templates/',
            SEJOWOO_DIR . 'templates/'
        );

	}

	/**
     *  Set affiliate when order create if current user affiliate exist or based on cookie
     *  Hooked via action woocommerce_checkout_create_order, priority 10
     *  @since 	1.0.0
     *  @param 	WC_Order 	$order
     *  @return WC_Order 	$order
     */
	public function set_order_meta($order) {

		$affiliate_id  = sejowoo_get_user_affiliate( $order->get_user_id(), $order );
		$set_affiliate = apply_filters( 'sejowoo/order/set-affiliate', true, $order, $affiliate_id );

		if(
			false !== $affiliate_id &&
			false !== $set_affiliate
		) :

			$order->update_meta_data(
				sejowoo_get_affiliate_key(),
				$affiliate_id
			);

		endif;

		return $order;

	}

	/**
     *  Add custom query var to wc_get_orders functions
     *  Hooked via filter woocommerce_order_data_store_cpt_get_orders_query, priority 10
     *  @since 	1.0.0
     *  @param 	array 	$query
	 *  @param 	array 	$query_vars
     *  @return array
     */
	public function set_wc_order_custom_query_var( $query, $query_vars ) {

		if ( ! empty( $query_vars['affiliate_id'] ) ) :

			$query['meta_query'][] = array(
				'key'   => sejowoo_get_affiliate_key(),
				'value' => esc_attr( $query_vars['affiliate_id'] ),
			);

		endif;

		return $query;

	}

	/**
	 * Disable use own affiliate
	 * Hooked via filter sejowoo/user/affiliate, priority 9999
	 * @since 	1.0.0
	 * @param  	integer 		$affiliate_id
	 * @param  	integer 		$user_id
	 * @return 	false|integer
	 */
	public function disable_use_own_affiliate( $affiliate_id, $user_id ) {

		if( is_user_logged_in() && $affiliate_id === get_current_user_id()) :
			return false;
		endif;

		return $affiliate_id;

	}

	/**
	 * Display affiliate info by ajax fragments
	 * Hooked via filter woocommerce_update_order_review_fragments, priority 200
	 * @since 	1.0.0
	 * @param 	array 	$fragments
	 * @return 	array
	 */
	public function ajax_display_affiliate_info( array $fragments) {

		$affiliate = sejowoo_get_user_affiliate();

		if( $affiliate ) :

			$fragments['.sejowoo-affiliate-info'] = wc_get_template_html(
														'affiliate-info.php',
														array(
															'affiliate'	=> new \WC_Customer($affiliate)
														),
														SEJOWOO_DIR . 'templates/checkout/',
														SEJOWOO_DIR . 'templates/checkout/'
													);

		endif;

		return $fragments;

	}

	/**
	 * Display affiliate info in checkout form
	 * Hooked via action woocommerce_review_order_after_submit, priority 200
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function display_affiliate_info() {

		$affiliate = sejowoo_get_user_affiliate();

		if( $affiliate ) :

			wc_get_template(
				'affiliate-info.php',
				array(
					'affiliate'	=> new \WC_Customer($affiliate)
				),
				SEJOWOO_DIR . 'templates/checkout/',
				SEJOWOO_DIR . 'templates/checkout/'
			);

		endif;

	}

}
