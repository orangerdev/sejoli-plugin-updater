<?php

namespace Sejowoo\Front;

class Endpoint {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Refere data
	 * @since 	1.0.0
	 * @access	protected
	 */
	protected $target = false;

	/**
	 * Set if current request is already checked
	 * @since 	1.4.1
	 * @var 	boolean
	 */
	protected $is_checked = false;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
     *  Set custom rewrite rule for AJAX special
     *  Hooked via action init, priority 10
     *  @since 1.0.0
     *  @param void
     *  @return void
     */
    public function set_endpoint()
    {
		add_rewrite_rule( '^sejowoo-ajax/([^/]*)/?',				'index.php?sejowoo-ajax=$matches[1]','top');

        flush_rewrite_rules();
	}

    /**
     * Set custom query vars
     * Hooked via filter query_vars, priority 999
     * @since   1.0.0
     * @access  public
     * @param   array $vars
     * @return  array
     */
    public function set_query_vars($vars = array())
    {
        $vars[] = 'sejowoo-ajax';

        return $vars;
    }

    /**
     * Check parse query and if sejowoo-ajax found, and then will called the parameter hooked
     * Hooked via action parse_query, priority 100
     * @since 1.0.0
     * @access public
     * @return void
     */
    public function check_parse_query()
    {
		global $wp_query;

		if(is_admin()) :
			return;
		endif;

		if($this->is_checked) :
			return;
		endif;

        if(isset($wp_query->query_vars['sejowoo-ajax']) && false === $this->is_checked) :

            $this->is_checked = true;

            do_action('sejowoo-ajax/' . $wp_query->query_vars['sejowoo-ajax']);
            exit;

        endif;
    }

}
