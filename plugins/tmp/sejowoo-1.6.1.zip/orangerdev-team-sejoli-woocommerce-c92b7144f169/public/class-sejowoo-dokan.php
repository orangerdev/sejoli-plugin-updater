<?php

namespace Sejowoo\Front;

class Dokan {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.1.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.1.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

    /**
	 * Set woocommerce log $context
	 * @since 	1.0.0
	 * @var		array
	 */
	protected $log = array(
		'source' => 'sejowoo-dokan-product'
	);

	/**
	 * Product editor setup
	 * @since 	1.1.2
	 * @var 	array
	 */
	protected $product_editor = array(
		'only' => array(
			'simple'	=> false,
			'virtual'	=> false,
		),
		'hide' => array(
			'inventory'       => false,
			'download'        => false,
			'seo'			  => false,
			'shipping'        => false,
			'variations'      => false,
			'linked_products' => false,
			'discount'        => false,
			'other_options'   => false
		)
	);

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.1.0
	 * @param    string    $plugin_name       The name of this plugin.
	 * @param    string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

	}

	/**
     *  Set endpoint custom menu
     *  Hooked via action init, priority 999
     *  @since 		1.0.0
     *  @return 	void
     */
    public function register_myaccount_endpoint() {

		add_rewrite_endpoint( 'vendor-dashboard', EP_PAGES );

		flush_rewrite_rules();
	}

	/**
	 * Remove unneeded product fields
	 * Hooked via action init, priority 999
	 * @since 	1.1.2
	 * @since 	1.2.0	Check if dokan class exists
	 * @return 	void
	 */
	public function remove_unneeded_product_fields() {

		global $wp_filter;

		if( !class_exists('WeDevs_Dokan') ) :
			return;
		endif;

		if(!is_array($this->product_editor['only'])) :

			$this->product_editor['only'] = array(
				'simple'  => boolval( carbon_get_theme_option( 'sejowoo_dokan_default_product_type_as_simple' ) ),
				'virtual' => boolval( carbon_get_theme_option( 'sejowoo_dokan_default_product_type_as_virtual' ) ),
			);

		endif;

		if(!is_array($this->product_editor['hide'])) :

			$this->product_editor['hide'] = array(
				'inventory'       => boolval( carbon_get_theme_option( 'sejowoo_dokan_hide_inventory_product_setup' ) ),
				'download'        => boolval( carbon_get_theme_option( 'sejowoo_dokan_hide_download_product_setup') ),
				'seo'			  => boolval( carbon_get_theme_option( 'sejowoo_dokan_hide_seo_product_setup') ),
				'shipping'        => boolval( carbon_get_theme_option( 'sejowoo_dokan_hide_shipping_product_setup' ) ),
				'linked_products' => boolval( carbon_get_theme_option( 'sejowoo_dokan_hide_linked_product_setup') ),
				'variations'      => boolval( carbon_get_theme_option( 'sejowoo_dokan_hide_variations_product_setup') ),
				'discount'        => boolval( carbon_get_theme_option( 'sejowoo_dokan_hide_discount_product_setup') ),
				'other_options'   => boolval( carbon_get_theme_option( 'sejowoo_dokan_hide_other_options_product_setup') )
			);

		endif;

		if( true === $this->product_editor['hide']['inventory'] ) :
			remove_action( 'dokan_product_edit_after_main', array( 'WeDevs\Dokan\Dashboard\Templates\Products', 'load_inventory_template' ), 5  );
		endif;

		if( true === $this->product_editor['hide']['download'] ) :
			remove_action( 'dokan_product_edit_after_main', array( 'WeDevs\Dokan\Dashboard\Templates\Products', 'load_downloadable_template' ), 10 );
		endif;

		if(class_exists('Dokan_Pro')) :

			if( true === $this->product_editor['hide']['seo'] ) :
				remove_action( 'dokan_product_edit_after_inventory_variants', array( dokan_pro()->products, 'load_product_seo_content' ), 5);
			endif;

			if( true === $this->product_editor['hide']['shipping'] ) :
				remove_action( 'dokan_product_edit_after_inventory_variants', array( dokan_pro()->products, 'load_shipping_tax_content' ), 10);
			endif;

			if( true === $this->product_editor['hide']['linked_products'] ) :
	        	remove_action( 'dokan_product_edit_after_inventory_variants', array( dokan_pro()->products, 'load_linked_product_content' ), 15);
			endif;

			if( true === $this->product_editor['hide']['variations'] ) :
	        	remove_action( 'dokan_product_edit_after_inventory_variants', array( dokan_pro()->products, 'load_variations_content' ), 	  20);
			endif;

			if( true === $this->product_editor['hide']['discount'] ) :
	        	remove_action( 'dokan_product_edit_after_inventory_variants', array( dokan_pro()->products, 'load_lot_discount_content' ),   25);
			endif;

		endif;
	}

    /**
     * Process when dokan save product
     * Hooked via action dokan_new_product_added, priority 100
     * Hooked via action dokan_product_updated, priority 100
     * @since   1.1.0
     * @param   integer $product_id
     * @param   array   $data
     * @return  void
     */
    public function save_product( $product_id, $data ) {

        //Set parent category to the product
        if ( isset( $data['product_cat'] ) && ! empty( $data['product_cat'] ) ) :

            $terms = (array) $data['product_cat'];

            foreach( (array) $data['product_cat'] as $cat_id ) :
                $ancestors = get_ancestors( $cat_id, 'product_cat', 'taxonomy' );
                $terms     = array_merge( $terms, $ancestors );
            endforeach;

            if( is_array($terms) && 0 < count($terms) ) :
                wp_set_object_terms( $product_id, array_map( 'absint', $terms ), 'product_cat' );
            endif;

        endif;

        //Set product commission
        $commission_id = absint( carbon_get_theme_option( 'sejowoo_dokan_default_commission' ) );

        if( 0 < $commission_id ) :
            update_post_meta( $product_id, 'sejowoo_commission', $commission_id );
        endif;

    }

	/**
	 * Set wallet detail for dokan revenue
	 * Hooked via filter sejowoo/wallet/note, priority 100
	 * @since 	1.1.0
	 * @param 	string 	$detail
	 * @param 	object 	$wallet_data
	 * @return 	string
	 */
	public function set_wallet_detail( string $detail, object $wallet_data ) {

		if( 'dokan-revenue' === $wallet_data->label) :

			$product      = wc_get_product($wallet_data->product_id);
			$product_name = ( is_a($product, 'WC_Product') ) ? $product->get_name() : $wallet_data->product_id;

			$meta    = wp_parse_args( $wallet_data->meta_data, array(
						'earning'        => 0,
						'seller_earning' => 0,
						'context'		 => 'admin'
					  ));

			$detail = sprintf(
				__('Pendapatan sebesar %s dari order %s untuk produk %s. Sudah dipotong komisi sistem sebesar %s', 'sejowoo'),
				wc_price( $wallet_data->value ),
				$wallet_data->order_id,
				$product_name,
				wc_price( $meta['earning'] )
			);

		endif;

		return $detail;
	}

	/**
	 * Set localize dokan javascript variables
	 * Hooked via action wp_enqueue_scripts, priority 100
	 * @since 	1.1.2
	 * @since 	1.2.0	Check if dokan class exists
	 */
	public function set_localize_js_vars() {

		if(class_exists('WeDevs_Dokan')) :

			wp_localize_script 	( 'dokan-script', 'sejowoo_dokan_product', $this->product_editor );

			wp_enqueue_script(
				'sejowoo-dokan-product',
				SEJOWOO_URL . 'public/js/sejowoo-dokan-product.js',
				array( 'dokan-script' ),
				$this->version,
				true
			);

		endif;
	}

	/**
	 * Remove unneeded menu
	 * Hooked via filter dokan_get_dashboard_nav, priority 100
	 * @since 	1.1.0
	 * @param  	array $navs
	 * @return 	array
	 */
	public function remove_unneeded_menu( $navs ) {

		unset( $navs['withdraw'] );

		return $navs;
	}

	/**
	 * Prevent vendor buy own product
	 * Hooked via action woocommerce_add_to_cart_validation, priority 20
	 * @since  1.1.2
	 * @since  1.2.0	Check if dokan class exists
	 * @param  bool  	$passed
	 * @param  integer 	$product_id
	 * @return bool
	 */
	public function prevent_vendor_buy_own_product( $passed, $product_id ) {

		if( class_exists('WeDevs_Dokan')) :

			$current_user    = absint( get_current_user_id() );
			$vendor_id       = absint( get_post_field( 'post_author', $product_id ) );
			$disallow_to_buy = boolval( carbon_get_theme_option( 'sejowoo_dokan_disable_buy_own_product' ) ) ;

			if ( $current_user === $vendor_id && true === $disallow_to_buy ) :

				$passed = false;

				wc_add_notice( __( 'Maaf, anda tidak bisa membeli produk anda sendiri.', 'woocommerce' ), 'error' );

			endif;

		endif;

		return $passed;
	}

	/**
	 * Redirect user to vendor dashboard
	 * Hooked via action template_redirect, priority 1
	 * @since 	1.1.2
	 * @return 	void
	 */
	public function redirect_myaccount_to_vendor_dashboard() {

		global $wp;

		if( is_account_page() ) :

			$page = explode( '/', $wp->request );

			if( isset($page[1]) && 'vendor-dashboard' === $page[1] ) :

				wp_redirect( dokan_get_navigation_url() );
				exit;

			endif;

		endif;
	}

	/**
	 * Modify product category args for dropdown
	 * Hooked via filter dokan_product_cat_dropdown_args, priority 999
	 * @since	1.1.2
	 * @return 	array
	 */
	public function modify_product_category_args( array $category_args ) {

		$hide_categories = carbon_get_theme_option('sejowoo_dokan_hide_product_categories');

		if( is_array($hide_categories) && 0 < count($hide_categories)) :
			$category_args['exclude'] = implode(',', $hide_categories);
		endif;

		return $category_args;
	}

	/**
	 * Modify bulk order in vendor options
	 * Hooked via filter dokan_bulk_order_statuses, priority 100
	 * @since 	1.1.2
	 * @param  	array  $options
	 * @return 	array
	 */
	public function modify_bulk_order_statuses( array $options ) {

		if ( 'on' === dokan_get_option( 'order_status_change', 'dokan_selling', 'on' ) ) :

			if( isset($options['wc-on-hold']) )
				unset($options['wc-on-hold']);

			if( isset($options['wc-processing']) )
				unset($options['wc-processing']);

			if( isset($options['wc-completed']) )
				unset($options['wc-completed']);

		endif;

		return $options;
	}

	/**
	 * Add custom order action
	 * Hooked via filter woocommerce_admin_order_actions, priority 100
	 * @since 	1.1.2
	 * @param  	array  		$actions
	 * @param  	WC_Order 	$order
	 * @return 	array
	 */
	public function modify_order_actions( array $actions, $order ) {
		return $actions;
	}

	/**
	 * Add dokan dashboard menu
	 * Hooked via filter woocommerce_account_menu_items, priority 999
	 * @since 	1.1.2
	 * @param 	array 	$menu_links
	 * @return 	array
	 */
	public function add_my_account_links( array $menu_links ) {

		if( current_user_can('dokandar') ) :

			$position = count($menu_links) - 1;

			$menu_links = array_slice( $menu_links, 0, $position, true )
								        + array(
											'vendor-dashboard'	=> __('Vendor Dashboard', 'sejowoo')
										)
								        + array_slice( $menu_links, $position, NULL, true );

		endif;

		return $menu_links;
	}

	/**
	 * Hide Store Setting menu
	 * Hooked via filter dokan_get_dashboard_settings_nav, priority 999
	 * @since 	1.1.2
	 * @param  	array  $settings [description]
	 * @return 	array
	 */
	public function setup_dokan_store_setting_nav( array $settings ) {

		if(
			isset( $settings['payment']) &&
			true === boolval( carbon_get_theme_option('sejowoo_dokan_pro_hide_store_payment_setting') )
		) :
			unset( $settings['payment'] );
		endif;

		if(
			isset( $settings['shipping']) &&
			true === boolval( carbon_get_theme_option('sejowoo_dokan_pro_hide_store_shipping_setting') )
		) :
			unset( $settings['shipping'] );
		endif;

		if(
			isset( $settings['social']) &&
			true === boolval( carbon_get_theme_option('sejowoo_dokan_pro_hide_store_social_profile_setting') )
		) :
			unset( $settings['social'] );
		endif;

		if(
			isset( $settings['seo']) &&
			true === boolval( carbon_get_theme_option('sejowoo_dokan_pro_hide_store_seo_setting') )
		) :
			unset( $settings['seo'] );
		endif;

		return $settings;
	}
}
