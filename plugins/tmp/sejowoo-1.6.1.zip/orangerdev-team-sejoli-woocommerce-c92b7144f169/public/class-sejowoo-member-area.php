<?php

namespace Sejowoo\Front;

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://sejoli.co.id
 * @since      1.0.0
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/public
 * @author     Sejoli <orangerdigiart@gmail.com>
 */
class Member_Area {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * List of CSS that will be enabled in custom page
	 * @var array
	 */
	private $css_enabled = [
		'key' => [],
		'src' => []
	];

	/**
	 * List of JS that will be enabled in custom page
	 * @var array
	 */
	private $js_enabled = [
		'key' => [],
		'src' => []
	];

	/**
	 * List of messages
	 * @var array
	 */
	private $messages = [
		'info'    => [],
		'warning' => [],
		'error'   => [],
		'success' => []
	];

	/**
	 * Enable semantic theme
	 * @since 	1.1.7
	 * @var 	boolean
	 */
	protected $enable_member_area = false;

	/**
	 * Set post type that Sejoli Member Area tempate page cant be used in
	 * @since 	1.3.2
	 * @var 	array
	 */
	protected $exclude_post_types = array();

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

		$this->enable_css_and_js();

	}

	/**
	 * Register CSS Files.
	 * Hooked via action hook wp_enqueue_scripts, priority 999
	 * @since 	1.0.0 	Initialization
	 * @since 	1.1.7 	Enable semantic
	 * @return void
	 */

	public function enqueue_styles()
	{

		$enable_member_area = apply_filters('sejowoo/member-area/enable', $this->enable_member_area);

		wp_register_style('bootstrap', 				SEJOWOO_URL . 'public/assets/css/bootstrap.min.css', [], $this->version, 'all' );
		wp_register_style('themify-icons', 			SEJOWOO_URL . 'public/assets/vendors/themefy_icon/themify-icons.css', [], $this->version, 'all' );
		wp_register_style('swiper-slider', 			SEJOWOO_URL . 'public/assets/vendors/swiper_slider/css/swiper.min.css', [], $this->version, 'all' );
		wp_register_style('select2', 				SEJOWOO_URL . 'public/assets/vendors/select2/css/select2.min.css', [], $this->version, 'all' );
		wp_register_style('nice-select', 			SEJOWOO_URL . 'public/assets/vendors/niceselect/css/nice-select.css', [], $this->version, 'all' );
		wp_register_style('owl-carousel', 			SEJOWOO_URL . 'public/assets/vendors/owl_carousel/css/owl.carousel.css', [], $this->version, 'all' );
		wp_register_style('gijgo', 					SEJOWOO_URL . 'public/assets/vendors/gijgo/gijgo.min.css', [], $this->version, 'all' );
		wp_register_style('font-awesome', 			SEJOWOO_URL . 'public/assets/vendors/font_awesome/css/all.min.css', [], $this->version, 'all' );
		wp_register_style('tagsinput', 				SEJOWOO_URL . 'public/assets/vendors/tagsinput/tagsinput.css', [], $this->version, 'all' );
		wp_register_style('jquery-datatables', 		SEJOWOO_URL . 'public/assets/vendors/datatable/css/jquery.dataTables.min.css', [], $this->version, 'all' );
		wp_register_style('responsive-datatables', 	SEJOWOO_URL . 'public/assets/vendors/datatable/css/responsive.dataTables.min.css', [], $this->version, 'all' );
		wp_register_style('buttons-datatables', 	SEJOWOO_URL . 'public/assets/vendors/datatable/css/buttons.dataTables.min.css', [], $this->version, 'all' );
		wp_register_style('summernote-bs4', 		SEJOWOO_URL . 'public/assets/vendors/text_editor/summernote-bs4.css', [], $this->version, 'all' );
		wp_register_style('morris', 				SEJOWOO_URL . 'public/assets/vendors/morris/morris.css', [], $this->version, 'all' );
		wp_register_style('material-icons', 		SEJOWOO_URL . 'public/assets/vendors/material_icon/material-icons.css', [], $this->version, 'all' );
		wp_register_style('metis-menu', 			SEJOWOO_URL . 'public/assets/css/metisMenu.css', [], $this->version, 'all' );
		wp_register_style('member-area', 			SEJOWOO_URL . 'public/assets/css/style.css', [], $this->version, 'all' );
		wp_register_style('default', 				SEJOWOO_URL . 'public/assets/css/colors/default.css', [], $this->version, 'all' );

		// <link rel="stylesheet" href="css/colors/default.css" id="colorSkinCSS">

		if ( sejowoo_is_member_area_page() ) :
			wp_enqueue_style( 'bootstrap' );
			wp_enqueue_style( 'themify-icons' );
			// wp_enqueue_style( 'swiper-slider' );
			// wp_enqueue_style( 'select2' );
			// wp_enqueue_style( 'nice-select' );
			// wp_enqueue_style( 'owl-carousel' );
			wp_enqueue_style( 'gijgo' );
			wp_enqueue_style( 'font-awesome' );
			// wp_enqueue_style( 'tagsinput' );
			// wp_enqueue_style( 'jquery-datatables' );
			// wp_enqueue_style( 'responsive-datatables' );
			// wp_enqueue_style( 'buttons-datatables' );
			// wp_enqueue_style( 'summernote-bs4' );
			wp_enqueue_style( 'morris' );
			wp_enqueue_style( 'material-icons' );
			wp_enqueue_style( 'metis-menu' );
			wp_enqueue_style( 'member-area' );
			wp_enqueue_style( 'default' );

		endif;

	}

	/**
	 * Register JS Files.
	 * Hooked via action hook wp_enqueue_scripts, priority 999
	 * @since 	1.0.0 	initialization
	 * @since 	1.1.7 	Enable semantic
	 * @return void
	 */
	public function enqueue_scripts()
	{

		wp_register_script( 'jquery-slim',				SEJOWOO_URL . 'public/assets/js/jquery-3.4.1.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'popper', 					SEJOWOO_URL . 'public/assets/js/popper.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'bootstrap', 				SEJOWOO_URL . 'public/assets/js/bootstrap.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'metis-menu', 				SEJOWOO_URL . 'public/assets/js/metisMenu.js', ['jquery'], $this->version, true );
		wp_register_script( 'jquery-waypoints', 		SEJOWOO_URL . 'public/assets/vendors/count_up/jquery.waypoints.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'chartlist-chart', 			SEJOWOO_URL . 'public/assets/vendors/chartlist/Chart.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'jquery-counterup', 		SEJOWOO_URL . 'public/assets/vendors/count_up/jquery.counterup.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'swiper-slider', 			SEJOWOO_URL . 'public/assets/vendors/swiper_slider/js/swiper.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'nice-select', 				SEJOWOO_URL . 'public/assets/vendors/niceselect/js/jquery.nice-select.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'owl-carousel', 			SEJOWOO_URL . 'public/assets/vendors/owl_carousel/js/owl.carousel.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'gijgo', 					SEJOWOO_URL . 'public/assets/vendors/gijgo/gijgo.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'jquery-datatables', 		SEJOWOO_URL . 'public/assets/vendors/datatable/js/jquery.dataTables.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'datatables-responsive', 	SEJOWOO_URL . 'public/assets/vendors/datatable/js/dataTables.responsive.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'datatables-buttons', 		SEJOWOO_URL . 'public/assets/vendors/datatable/js/dataTables.buttons.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'datatables-buttons-flash', SEJOWOO_URL . 'public/assets/vendors/datatable/js/buttons.flash.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'datatables-jszip', 		SEJOWOO_URL . 'public/assets/vendors/datatable/js/jszip.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'datatables-pdfmake', 		SEJOWOO_URL . 'public/assets/vendors/datatable/js/pdfmake.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'datatables-vfs-fonts', 	SEJOWOO_URL . 'public/assets/vendors/datatable/js/vfs_fonts.js', ['jquery'], $this->version, true );
		wp_register_script( 'datatables-buttons-html5', SEJOWOO_URL . 'public/assets/vendors/datatable/js/buttons.html5.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'datatables-buttons-print', SEJOWOO_URL . 'public/assets/vendors/datatable/js/buttons.print.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'chart', 					SEJOWOO_URL . 'public/assets/js/chart.min.js', ['jquery'], $this->version, true );
		wp_register_script( 'jquery-barfiller', 		SEJOWOO_URL . 'public/assets/vendors/progressbar/jquery.barfiller.js', ['jquery'], $this->version, true );
		wp_register_script( 'tagsinput', 				SEJOWOO_URL . 'public/assets/vendors/tagsinput/tagsinput.js', ['jquery'], $this->version, true );
		wp_register_script( 'summernote-bs4', 			SEJOWOO_URL . 'public/assets/vendors/text_editor/summernote-bs4.js', ['jquery'], $this->version, true );
		wp_register_script( 'apex-chart-apexcharts', 	SEJOWOO_URL . 'public/assets/vendors/apex_chart/apexcharts.js', ['jquery'], $this->version, true );
		wp_register_script( 'custom', 					SEJOWOO_URL . 'public/assets/js/custom.js', ['jquery'], $this->version, true );
		wp_register_script( 'active-chart', 			SEJOWOO_URL . 'public/assets/js/active_chart.js', ['jquery'], $this->version, true );
		wp_register_script( 'apex-chart-radial-active', SEJOWOO_URL . 'public/assets/vendors/apex_chart/radial_active.js', ['jquery'], $this->version, true );
		wp_register_script( 'apex-chart-stackbar', 		SEJOWOO_URL . 'public/assets/vendors/apex_chart/stackbar.js', ['jquery'], $this->version, true );
		wp_register_script( 'apex-chart-area', 			SEJOWOO_URL . 'public/assets/vendors/apex_chart/area_chart.js', ['jquery'], $this->version, true );
		wp_register_script( 'apex-chart-pie', 			SEJOWOO_URL . 'public/assets/vendors/apex_chart/pie.js', ['jquery'], $this->version, true );
		wp_register_script( 'bar-active-1', 			SEJOWOO_URL . 'public/assets/vendors/apex_chart/bar_active_1.js', ['jquery'], $this->version, true );
		wp_register_script( 'chartjs-active', 			SEJOWOO_URL . 'public/assets/vendors/chartjs/chartjs_active.js', ['jquery'], $this->version, true );

		if ( sejowoo_is_member_area_page() ) :

			// wp_enqueue_script( 'jquery-slim' );
			wp_enqueue_script( 'popper' );
			wp_enqueue_script( 'bootstrap' );
			wp_enqueue_script( 'metis-menu' );
			wp_enqueue_script( 'jquery-waypoints' );
			// wp_enqueue_script( 'chartlist-chart' );
			// wp_enqueue_script( 'jquery-counterup' );
			// wp_enqueue_script( 'swiper-slider' );
			// wp_enqueue_script( 'nice-select' );
			// wp_enqueue_script( 'owl-carousel' );
			wp_enqueue_script( 'gijgo' );
			// wp_enqueue_script( 'jquery-datatables' );
			// wp_enqueue_script( 'datatables-responsive' );
			// wp_enqueue_script( 'datatables-buttons' );
			// wp_enqueue_script( 'datatables-buttons-flash' );
			// wp_enqueue_script( 'datatables-jszip' );
			// wp_enqueue_script( 'datatables-pdfmake' );
			// wp_enqueue_script( 'datatables-vfs-fonts' );
			// wp_enqueue_script( 'datatables-buttons-html5' );
			// wp_enqueue_script( 'datatables-buttons-print' );
			// wp_enqueue_script( 'chart' );
			wp_enqueue_script( 'jquery-barfiller' );
			wp_enqueue_script( 'tagsinput' );
			// wp_enqueue_script( 'summernote-bs4' );
			// wp_enqueue_script( 'apex-chart-apexcharts' );
			// wp_enqueue_script( 'custom' );
			// wp_enqueue_script( 'active-chart' );
			// wp_enqueue_script( 'apex-chart-radial-active' );
			// wp_enqueue_script( 'apex-chart-stackbar' );
			// wp_enqueue_script( 'apex-chart-area' );
			// wp_enqueue_script( 'apex-chart-pie' );
			// wp_enqueue_script( 'bar-active-1' );
			// wp_enqueue_script( 'chartjs-active' );

		endif;

	}

	/**
	 * Override woocommerce myaccount template into template folder
	 * Hooked via filter woocommerce_locate_template, priority 1
	 * @since 1.0.0
	 * @return string $template
	 */
	public function override_myaccount_template( $template, $template_name, $template_path ) {

		global $woocommerce;

		$_template = $template;

		if ( ! $template_path )
		$template_path = $woocommerce->template_url;

		$plugin_path  = SEJOWOO_DIR  . 'templates/';

		// Look within passed path within the theme - this is priority
		$template = locate_template(
		array(
			$template_path . $template_name,
			$template_name
		)
		);

		if( ! $template && file_exists( $plugin_path . $template_name ) )
		$template = $plugin_path . $template_name;

		if ( ! $template )
		$template = $_template;

		return $template;
	}

	/**
	 * Give permission to selected CSS and JS
	 * @return void
	 */
	private function enable_css_and_js()
	{
		$this->css_enabled = [
			'src' => [
				// 'plugins/woocommerce',
				'wp-includes',
				'wp-admin',
				'query-monitor',
				'wc-block-library',
				'wc-block-vendors-style',
				'wc-block-style',
				'select2',
				'woocommerce-layout',
				'woocommerce-smallscreen',
				'woocommerce-general',
				'woocommerce-general-inline',
				'woocommerce-inline',
				'woocommerce-inline-inline'
			],
			'key' => [
				// /'wc-'
			]
		];

		$this->js_enabled = [
			'src' => [
				// 'woocommerce',
				'wp-includes',
				'wp-admin',
				'query-monitor',
				// 'wc-add-to-cart',
				'selectWoo',
				'js-cookie',
				// 'woocommerce-js-extra',
				// 'woocommerce',
				// 'wc-cart-fragments',
				// 'wc-country-select',
				// 'wc-address-i18n'
			],
			'key' => [
				// 'wc-'
			]
		];
	}

	public function register_custom_nav_menu() {
		register_nav_menu('sejowoo-member-area-menu', __( 'Member Area Menu', 'sejowoo' ));
	}

	/**
	 * Deregister unneeded CSS and JS scripts
	 * Hooked via action wp_enqueue_scripts, priority 999
	 * @return void
	 */
	public function deregister_scripts()
	{
		global $wp_styles,$wp_scripts;

		$styles = $scripts = [];

		$enable_member_area = apply_filters('sejowoo/member-area/enable', false);

		return;

		if( true !== sejowoo_is_member_area_page() ) :
			return;
		endif;

		return;

		// $this->css_enabled = apply_filters('sejoli/css/permissions',	$this->css_enabled);
		// $this->js_enabled  = apply_filters('sejoli/js/permissions',		$this->js_enabled);

        // REMOVE ALL UNWANTED STYLES AND SCRIPTS
        foreach( (array) $wp_styles->registered as $key => $object) :
            if(!(
					false !== sejowoo_strpos_array($object->src,$this->css_enabled['src']) ||
					false !== sejowoo_strpos_array($key,$this->css_enabled['key']) ||
                    '' === $object->src ||
                    1  === $object->src )
            ) :
                wp_dequeue_style($key);
			else :
				$styles[]	= $key;
            endif;
        endforeach;


        foreach((array) $wp_scripts->registered as $key => $object) :
            if(!(
				false !== sejowoo_strpos_array($object->src,$this->js_enabled['src']) ||
				false !== sejowoo_strpos_array($key,$this->js_enabled['key']) ||
				'' === $object->src ||
				1  === $object->src )
            ) :
                wp_dequeue_script($key);
			else :
				$scripts[]	= $key;
            endif;
        endforeach;
	}

	/**
	 * Enable semantic
	 * Hooked via filter sejowoo/member-area/enable, priority 100
	 * @since 	1.1.7
	 * @return 	boolean
	 */
	public function enable_member_area($enable_member_area) {
		return (true === $enable_member_area) ? true : $this->enable_member_area;
	}

	/**
	 * Check if current page is using member-template.php
	 * Hooked via filter template_include, priority 10
	 * @since 	1.0.0
	 * @param  	string	$template	Template file
	 * @return 	string
	 */
	public function view_member_template($template) {

		global $post;

		// Return template if post is empty
		if ( ! $post ) :
			return $template;
		endif;

		if( sejowoo_is_member_area_page() ) :

			$template = SEJOWOO_DIR . 'template/member-template.php';

			return $template;
		endif;

		return $template;
	}

	/**
	 * Add inline CSS script
	 * Hooked via action wp_head, priority 100
	 * @since 	1.2.0
	 * @return 	boolean
	 */
	public function add_inline_style() {
		?>
		<style media="screen">
			#wp-admin-bar-sejoli-member-area { background-color: #179822!important; }
		</style>
		<?php
	}

}
