<?php

namespace Sejowoo\Front;

use Carbon\Carbon;

class SocialProof
{
    /**
     * The ID of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $plugin_name    The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     *
     * @since    1.0.0
     * @access   private
     * @var      string    $version    The current version of this plugin.
     */
    private $version;

    /**
     * If social proof enabled
     * @since   1.0.0
     * @var     boolean
     */
    protected $is_enabled = false;

    /**
     * If buyer name is sensored
     * @since   1.0.0
     * @var     boolean
     */
    protected $is_name_sensored = false;

    /**
     * If buyer avatar is showed
     * @since   1.0.0
     * @var     boolean
     */
    protected $is_avatar_showed  = false;

    /**
     * If product image is showed
     * @since   1.5.1.1
     * @var     boolean
     */
    protected $is_product_image_showed = false;

    /**
     * First popup show delay time in mileseconds
     * @since   1.0.0
     * @var     integer
     */
    protected $first_time   = 0;

    /**
     * Popup show time in mileseconds
     * @since   1.0.0
     * @var     integer
     */
    protected $display_time = 2000;

    /**
     * Delay between popup
     * @since   1.0.0
     * @var     integer
     */
    protected $delay_time = 2000;

    /**
     * Set popup position
     * @since   1.0.0
     * @var     string
     */
    protected $position = 'bottom right';

    /**
     * Popup text
     * @since   1.0.0
     * @var     string
     */
    protected $popup_text = '';

    /**
     * Check if query already running
     * @since   1.0.0
     * @var     boolean
     */
    protected $is_checked = false;

    /**
     * Check if init process is already running
     * @since   1.1.2.3
     * @var     boolean
     */
    protected $is_checked_on_init = false;

    /**
     * Construction
    */
    public function __construct( $plugin_name, $version)
    {
        $this->plugin_name = $plugin_name;
        $this->version     = $version;
    }

    /**
     * Get social proof image
     * @since   1.0.0
     * @param   WC_Order  $order
     * @return  string    Image url based
     */
    protected function get_image( \WC_Order $order ) {

        $image = false;

        if( $this->is_avatar_showed ) :

            return get_avatar_url( $order->get_billing_email() );

        elseif( $this->is_product_image_showed ):

            $image = get_the_post_thumbnail_url(
                        current( $order->get_items() )->get_product_id(),
                        'post-thumbnail'
                     );
        endif;

        return ( false === $image ) ? SEJOWOO_URL . 'public/img/placeholder.png' : $image;

    }

    /**
     * Get social proof order data
     * Hooked via sejowoo-ajax/get-social-proof-data, priority 1
     * @since   1.0.0
     * @return  string
     */
    public function get_order_data() {

        $response = array(
            'success'   => false,
            'data'      => array()
        );

        $post     = wp_parse_args($_POST, array(
            'orders'        => NULL
        ));

        $this->is_avatar_showed        = boolval( carbon_get_theme_option( 'social_proof_display_avatar' ) );
        $this->is_product_image_showed = boolval( carbon_get_theme_option( 'social_proof_display_product' ) );
        $current_orders                = ( !empty($post['orders']) ) ? explode(',', $post['orders']) : array();
        $order_status                  = carbon_get_theme_option( 'social_proof_order_status' );
        $order_status                  = 'both' === $order_status ? array( 'on-hold', 'completed' ) : array( $order_status );

        $query = new \WP_Query(array(
            'post_type'              => SEJOWOO_ORDER_CPT,
            'posts_per_page'         => 1,
            'post_status'            => $order_status,
            'post_parent'            => 0,
            'order'                  => 'title',
            'post__not_in'           => $current_orders,
            'no_found_rows'          => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false
        ));

        if( 0 < count( $query->posts ) ) :

            $order_id         = $query->posts[0];
            $order            = wc_get_order( $order_id );
            $current_orders[] = $order->get_id();
            $sensored         = boolval( carbon_get_theme_option( 'social_proof_sensor_buyer_name' ) );

            Carbon::setLocale('id');

            $name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();

            $response['success'] = true;
            $response['data']    = array(
                'orders'    => implode(',', $current_orders),
                'name'      => ( $sensored ) ? sejowoo_get_sensored_string( $name ) : $name,
                'avatar'    => $this->get_image( $order ),
                'product'   => current( $order->get_items() )->get_name(),
                'time'      => Carbon::parse(
                                $order->get_date_created()->date('Y-m-d H:i:s')
                               )->diffForHumans(current_time('mysql'))
            );

        endif;

        wp_send_json($response);
        exit;
    }

    /**
     *  Set end point custom menu
     *  Hooked via action init, priority 1019
     *  @since 1.0.0
     *  @access public
     *  @return void
     */
    public function set_endpoint()
    {

		add_rewrite_rule( '^sejowoo-social-proof/?',		                    'index.php?sejowoo-social-proof=1','top');;
        add_rewrite_rule( '^sejowoo-social-proof-iframe/([^/]*)/([^/]*)/?',		'index.php?sejowoo-social-proof-iframe-js=$matches[1]&request=$matches[2]','top');
        add_rewrite_rule( '^sejowoo-social-proof-ajax/([^/]*)/?',		        'index.php?sejowoo-social-proof-ajax=$matches[1]','top');;

        flush_rewrite_rules();
    }

    /**
     * Set custom query vars
     * Hooked via filter query_vars, priority 1019
     * @since   1.0.0
     * @access  public
     * @param   array $vars
     * @return  array
     */
    public function set_query_vars($vars)
    {
        $vars[] = 'sejowoo-social-proof';
        $vars[] = 'sejowoo-social-proof-ajax';
        $vars[] = 'sejowoo-social-proof-iframe-js';
        $vars[] = 'request';

        return $vars;
    }

    /**
     * Set if social proof is enabled
     * Hooked via action wp_loaded, priority 1
     * @since   1.0.0
     * @since   1.1.2.3
     */
    public function set_if_activated()
    {

        if(
            function_exists('carbon_get_theme_option') &&
            false === $this->is_checked_on_init
        ) :
            $this->is_enabled = boolval( carbon_get_theme_option( 'social_proof_enable') );
            $this->is_checked_on_init = true;
        endif;

    }

    /**
     * Check parse query and if member-area found, $enable_framework will be true
     * Hooked via action parse_query, priority 19
     * @since 1.0.0
     * @access public
     * @return void
     */
    public function check_parse_query()
    {
        global $wp_query;

		if(is_admin() || $this->is_checked) :
			return;
		endif;

        $this->set_if_activated();

        if(
            isset($wp_query->query_vars['sejowoo-social-proof']) &&
            1 === intval($wp_query->query_vars['sejowoo-social-proof'])
        ) :

            $this->is_checked = true;

            /** Allow CORS **/
            header("Access-Control-Allow-Origin: *");
            header("Content-type: application/javascript");

            if( $this->is_enabled && !is_account_page() ) :

                $popup_text = str_replace(
                                array(
                                    '{{buyer_name}}',
                                    '{{product_name}}'
                                ),
                                array(
                                    "<span class='buyer-name'>".__('Buyer name', 'sejowoo')."</span>",
                                    "<span class='product-name'></span>"
                                ),
                                $this->popup_text
                              );

                require_once( plugin_dir_path( __FILE__ ) . 'partials/social-proof/iframe-js.php' );

            else :

                wp_die(
                    __('Social proof is not active', 'sejowoo'),
                    __('Problem happened', 'sejowoo')
                );

            endif;

            exit;

        elseif(
            isset($wp_query->query_vars['sejowoo-social-proof-ajax']) &&
            17 === intval($wp_query->query_vars['sejowoo-social-proof-ajax'])
        ) :

            $this->is_checked = true;

            /** Allow CORS **/
            header("Access-Control-Allow-Origin: *");
            header("Content-type: application/json");

            if( $this->is_enabled && !is_account_page() ) :

                $this->get_order_data();

            else :

                wp_die(
                    __('Social proof is not active', 'sejowoo'),
                    __('Problem happened', 'sejowoo')
                );

            endif;

            exit;

        elseif(
            isset($wp_query->query_vars['sejowoo-social-proof-iframe-js']) &&
            isset($wp_query->query_vars['request']) &&
            in_array( $wp_query->query_vars['request'], array('css', 'js') )
        ) :

            $this->is_checked = true;

            /** Allow CORS **/
            header("Access-Control-Allow-Origin: *");
            header("Content-type: text/css");

            if( $this->is_enabled && !is_account_page() ) :

                require_once( plugin_dir_path( __FILE__ ) . 'css/sejowoo-social-proof-iframe-inline.css' );

            else :

                wp_die(
                    __('Social proof is not active', 'sejowoo'),
                    __('Problem happened', 'sejowoo')
                );

            endif;

        exit;

        endif;

    }

    /**
     * Check if social proof popup is enabled
     * Hooked via action wp, priority 1999
     * @since   1.0.0
     * @since   1.5.1.1     Add set value for is_product_image_showed
     * @return  void
     */
    public function check_if_enabled() {

        global $post;

        if( ! is_admin() && $this->is_enabled && !is_account_page() ) :

            $this->is_enabled              = boolval( carbon_get_theme_option( 'social_proof_enable' ) );
            $this->is_name_sensored        = boolval( carbon_get_theme_option( 'social_proof_sensor_buyer_name' ) );
            $this->is_avatar_showed        = boolval( carbon_get_theme_option( 'social_proof_display_avatar' ) );
            $this->is_product_image_showed = boolval( carbon_get_theme_option( 'social_proof_display_product' ) );
            $this->first_time              = intval( carbon_get_theme_option( 'social_proof_first' ) );
            $this->display_time            = intval( carbon_get_theme_option( 'social_proof_display' ) );
            $this->delay_time              = intval( carbon_get_theme_option( 'social_proof_delay' ) );
            $this->position                = carbon_get_theme_option( 'social_proof_position' );
            $this->popup_text              = wp_strip_all_tags( carbon_get_theme_option( 'social_proof_text' ) );

        endif;

    }

    /**
     * Set current body classes
     * Hooked via filter body_class, priority 1999
     * @since   1.0.0
     * @param   array $body_classes
     * @return  array
     */
    public function set_body_classes( array $body_classes ) {

        if( $this->is_enabled && !is_account_page() ) :

            $body_classes[] = 'sejowoo-social-proof';

        endif;

        return $body_classes;
    }

    /**
     * Set localize js variables
     * Hooked via action wp_enqueue_scripts, priority 888
     * @since 1.0.0
     */
    public function set_localize_js_vars() {

        global $post;

        if( $this->is_enabled && !is_account_page() ) :

            wp_enqueue_script   ('sejoli-social-proof', SEJOWOO_URL . 'public/js/sejowoo-social-proof.js', array(), $this->version, true);
            wp_localize_script  ('sejoli-social-proof', 'sejowoo_social_proof', [

                'main_css'      => SEJOWOO_URL . 'public/css/sejowoo-social-proof.css?v=' . $this->version,
                'ajax_url'      => home_url('sejowoo-ajax/get-social-proof-data'),
                'first_time'    => $this->first_time,
                'show_time'     => $this->display_time,
                'delay_time'    => $this->delay_time,
                'position'      => $this->position,
            ]);

        endif;
    }

    /**
     * Set CSS and JS need files
     * Hooked via action wp_footer, priority 1999
     * @since   1.0.0
     * @return  void
     */
    public function set_scripts() {

        if ( $this->is_enabled && !is_account_page() ) :

            require_once( plugin_dir_path( __FILE__ ) . 'partials/social-proof/setup.php' );

        endif;

    }
}
