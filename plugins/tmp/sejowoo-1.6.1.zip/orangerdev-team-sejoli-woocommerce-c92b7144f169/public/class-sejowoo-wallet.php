<?php

namespace Sejowoo\Front;


/**
 * The wallet for public-facing functionality of the plugin.
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/public
 * @author     Sejoli <orangerdigiart@gmail.com>
 */
class Wallet {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Set if current action is already checked
	 * @since	1.0.0
	 * @var 	boolean
	 */
	protected $is_checked = false;

	/**
	 * Define amount of wallet use
	 * @since 	1.0.0
	 * @var 	float
	 */
	protected $wallet_use = 0.0;

	/**
	 * Wallet fee name in carts
	 * @since 	1.0.0
	 * @var 	string
	 */
	protected $wallet_cart_name = 'Penggunaan Dana';

	/**
	 * Set woocommerce log $context
	 * @since 	1.0.0
	 * @var		array
	 */
	protected $log = array(
		'source' => 'sejowoo-wallet'
	);

    /**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
     *  Set endpoint custom menu
     *  Hooked via action init, priority 999
     *  @since 		1.0.0
     *  @return 	void
     */
    public function register_myaccount_endpoint() {

		add_rewrite_endpoint( 'wallet-data', EP_PAGES );

		flush_rewrite_rules();
	}

	/**
	 * Set is_sejowoo_page if current page is wallet data
	 * Hooked via action parse_query, priority 105
	 * @since 1.0.0
	 */
	public function set_is_sejowoo_page() {

		global $wp_query;

		if(is_admin()) :
			return;
		endif;

		if($this->is_checked) :
			return;
		endif;

		if( array_key_exists( 'wallet-data', $wp_query->query_vars ) ) :

			$this->is_checked = true;

			do_action( 'sejowoo/myaccount/set-sejowoo-page', true);

		endif;

	}

	/**
	 * Set my-account localize javascript data
	 * Hooked via filter sejowoo/myaccount/js-localize-data, priority 105
	 * @since 	1.0.0
	 * @param 	array $vars
	 * @return 	array
	 */
	public function set_localize_js_vars( array $vars ) {
		$vars['wallet'] = array(
			'single_table' => array(
				'ajaxurl'	=> site_url('sejowoo-ajax/get-wallet-list'),
				'nonce'		=> wp_create_nonce('sejowoo-render-single-wallet-table')
			)
		);
		return $vars;
	}

	/**
     *  Add custom woocommerce my account links
     *  Hooked via filter sejowoo/myaccount/links, priority 50
     *  @since 	1.0.0
     *  @since 	1.1.2 	Change hook point
     *  @param 	array 	$menu_links
     *  @return array
     */
    public function add_my_account_links( array $links ){

		$links['wallet-data'] 	= __('Dompet Anda', 'sejowoo' );

        return $links;

    }

	/**
	 * Set cashback if enabled to cart
	 * Hooked via action woocommerce_calculate_totals, priority 105
	 * @since 1.0.0
	 * @param WC_Cart $cart
	 */
	public function set_wallet_use_to_cart( \WC_Cart $cart) {

		if( ! isset($_POST['post_data']) ) :
			return;
		endif;

		$post_data 	= wp_parse_args(
						$_POST['post_data'],
						array(
							'sejowoo-use-wallet-point' => false
						)
					  );

		if( false !== $post_data['sejowoo-use-wallet-point'] ) :

			$wallet_data = sejowoo_get_single_user_wallet();
			$available_total = (isset($wallet_data['available_total'])) ? $wallet_data['available_total'] : 0;

			if( 0 < floatval($available_total)) :

				$this->wallet_use  = floatval( $available_total );

				WC()->cart->add_fee( __('Penggunaan Dana', 'sejowoo'), -$this->wallet_use );

			endif;

		endif;
	}

	/**
	 * Calculate cart total, reduced by wallet value used
	 * Hooked via filter woocommerce_calculated_total, priority 105
	 * @since 	1.0.0
	 * @param 	float   	$cart_total
	 * @param 	WC_Cart 	$cart
	 * @return 	float
	 */
	public function set_cart_total_value( float $cart_total, \WC_Cart $cart ) {

		$post_data 	= wp_parse_args(
						$_POST,
						array(
							'sejowoo-use-wallet-point' => false
						)
					  );

		if( false !== $post_data['sejowoo-use-wallet-point'] ) :

			$wallet_data = sejowoo_get_single_user_wallet();
			$available_total = (isset($wallet_data['available_total'])) ? $wallet_data['available_total'] : 0;

			if( 0 < floatval($available_total)) :

				$wallet_use = floatval( $available_total );

				if( $wallet_use > $cart_total ) :
					return 0;
				else :
					return $cart_total - $wallet_use;
				endif;

			endif;

		endif;

		return $cart_total;
	}

	/**
	 * Set wallet use data to an order
	 * Hooked via action woocommerce_checkout_order_created, priority 105
	 * @since 	1.0.0
	 * @param 	integer 	$order_id
	 * @param 	array 		$posted_data
	 * @param 	WC_Order 	$order
	 */
	public function set_wallet_use_to_order( \WC_Order $order ) {

		$post_data = wp_parse_args( $_POST, array(
						'sejowoo-use-wallet-point' => false
					));

		if(
			is_a($order, 'WC_Order') &&
			false !== boolval($post_data['sejowoo-use-wallet-point'])
		) :

			$wallet_data = sejowoo_get_single_user_wallet();
			$available_total = (isset($wallet_data['available_total'])) ? $wallet_data['available_total'] : 0;

			if( 0 < floatval($available_total)) :

				$order_total = $order->calculate_totals();
				$wallet_use  = $wallet_available = floatval( $available_total );

				if( $wallet_available > $order_total ) :
					$wallet_use = $order_total;
				endif;

				$item_fee = new \WC_Order_Item_Fee();

				$item_fee->set_name( __('Penggunaan Dana', 'sejowoo') );
				$item_fee->set_amount( -$wallet_use );
				$item_fee->set_total( -$wallet_use );

				$order->add_item( $item_fee );
				$order->calculate_totals();
				$order->save();

				$respond = sejowoo_add_wallet_value(array(
					'order_id'    => $order->get_id(),
					'user_id'     => $order->get_user_id(),
					'valid_point' => true,
					'value'		  => $wallet_use,
					'label'		  => 'wallet-use',
					'type'		  => 'out'
				));

				$logger  = wc_get_logger();
		        $context = array( 'source' => 'sejowoo-cashback' );

		        if( is_wp_error( $respond) ) :

		            foreach( $respond->get_error_messages() as $message ) :
		                $logger->error( $message, $this->log );
		            endforeach;

		        else :

	                $logger->info(
	                    sprintf(
	                        __('Wallet used with amount %s for order_id %s, user_id %s and wallet_id %s', 'sejowoo'),
	                        $wallet_use,
	                        $order->get_id(),
	                        $order->get_user_id(),
	                        $respond['ID']
	                    ),
	                    $this->log
	                );

		        endif;

			endif;

		endif;
	}

	/**
     *  Add wallet-data endpoint page content
     *  Hooked via action woocommerce_account_wallet-data_endpoint, priority 1
     *  @since 		1.0.0
     *  @return 	void
     */
    public function display_data_content() {

        include_once( SEJOWOO_DIR . 'templates/my-account/wallet/table.php' );

	}

	/**
     * Display cashback use field
     * Hooked via action woocommerce_checkout_order_review, priority 11
     * @since   1.0.0
     * @return  void
     */
    public function display_wallet_use_field() {

		$wallet_data = sejowoo_get_single_user_wallet();

		require_once ( SEJOWOO_DIR . 'templates/checkout/wallet-field.php');
    }

	/**
	 * Add js script in checkout page
	 * Hooked via action wp_footer, priority 105
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function add_checkout_script_js() {

		include_once( SEJOWOO_DIR . 'templates/checkout/wallet-use-js.php' );

	}
}
