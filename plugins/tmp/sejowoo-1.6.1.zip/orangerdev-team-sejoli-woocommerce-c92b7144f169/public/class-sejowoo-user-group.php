<?php

namespace Sejowoo\Front;

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://sejowoo.co.id
 * @since      1.0.0
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the user group public-facing stylesheet and JavaScript.
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/public
 * @author     Sejoli <orangerdigiart@gmail.com>
 */
class UserGroup {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

    /**
     * Set temporarty current+_user_group
     * @since   1.0.0
     * @var     false|stdClass
     */
    protected $current_user_group = false;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

    /**
     * Calculate price based on user group setting
     * @since   1.0.0
     * @since 	1.1.2		Fix with less than zero price
     * @param   float       $price
     * @param   WC_Product  $product
     * @param   object      $user_group_setting
     * @return  float
     */
    protected function calculate_price( float $price, \WC_Product $product, object $user_group_setting ) {

   //      $product_id       = $product->get_id();
   //      $discount_setting = false;

   //      if( array_key_exists($product->get_id(), $user_group_setting->per_product ) )  :
   //          $discount_setting = $user_group_setting->per_product[$product_id]['discount'];
   //      else :
   //          $discount_setting = $user_group_setting->discount;
   //      endif;

   //      if( false !== $discount_setting && false !== $discount_setting['enabled'] ) :

   //          if( 'fixed' === $discount_setting['type'] ) :
   //              $price -= $discount_setting['value'];
   //          else :
   //              $price -= ( $price * $discount_setting['value'] ) / 100;
   //          endif;

			// if( 0 > $price ) :
			// 	return 0;
			// endif;

   //      endif;

        return $price;
    }

    /**
     * Modify product price based on current user group setting
     * Hooked via filter woocommerce_product_get_price, priority 220
     * @since   1.0.0
     * @param   string      $price
     * @param   WC_Product  $product
     * @return  string
     */
    public function set_front_price_html( string $price_html, \WC_Product $product) {

        if( is_admin() ) return $price_html;

        if ( '' === $product->get_price() ) return $price_html;

        if( is_user_logged_in() ) :

            if( false === $this->current_user_group ) :

                $this->current_user_group = sejowoo_get_current_user_group_data();

                if( ! $this->current_user_group ) :
                    return $price_html;
                endif;

            endif;

            // $price      = $this->calculate_price(
            //                     $product->get_price(),
            //                     $product,
            //                     $this->current_user_group
            //               );
            $price      = $product->get_price();

            $price_html = wc_price( $price );

        endif;

        return $price_html;
    }

    /**
     * Set modified user group product price in cart
     * Hooked via action woocommerce_before_calculate_totals, priority 220
     * @since 1.0.0
     * @param WC_Cart $cart [description]
     */
    public function set_price_in_cart( \WC_Cart $cart) {

        if ( is_admin() && ! defined( 'DOING_AJAX' ) ) return;

        if ( did_action( 'woocommerce_before_calculate_totals' ) >= 2 ) return;

        if( is_user_logged_in() ) :

            if( false === $this->current_user_group ) :

                $this->current_user_group = sejowoo_get_current_user_group_data();

                if( ! $this->current_user_group ) :
                    return;
                endif;

            endif;

            // LOOP THROUGH CART ITEMS & APPLY 20% DISCOUNT
            foreach ( $cart->get_cart() as $cart_item_key => $cart_item ) :

                $product = $cart_item['data'];
                $price   = $product->get_price();
                // $cart_item['data']->set_price( $this->calculate_price( $price, $product, $this->current_user_group) );

            endforeach;

        endif;
    }

    /**
     * Returns the product's regular price
     * Hooked via filter woocommerce_product_get_regular_price, priority 99, 2
     * Hooked via filter woocommerce_product_get_sale_price, priority 99, 2
     * Hooked via filter woocommerce_product_get_price, priority 99, 2
     * Hooked via filter woocommerce_product_variation_get_regular_price, priority 99, 2
     * Hooked via filter woocommerce_product_variation_get_sale_price, priority 99, 2
     * Hooked via filter woocommerce_product_variation_get_price, priority 99, 2
     *
     * @param $price
     * @param $product
     *
     * @return string price
     */
    public function set_price_based_user_group($price, $product) {
        $user_id            = get_current_user_id();
        $user_group_id      = intval(carbon_get_user_meta($user_id, 'user_group'));
        $product_id         = $product->get_id();
        $discount_setting   = false;
        $user_group_setting = sejowoo_get_user_group_data($user_group_id);

        if( $user_group_setting )  :
            
            if( array_key_exists($product->get_id(), $user_group_setting->per_product ) )  :
                $discount_setting = $user_group_setting->per_product[$product_id]['discount'];
            else :
                $discount_setting = $user_group_setting->discount;
            endif;

            if( false !== $discount_setting && false !== $discount_setting['enabled'] ) :

                if( 'fixed' === $discount_setting['type'] ) :
                    $price = floatval($price) - $discount_setting['value'];
                else :
                    $price = floatval($price) - ( floatval($price) * ($discount_setting['value'] / 100) );
                endif;

                if( 0 > $price ) :
                    return 0;
                endif;
            else:
                $price = floatval($price);
            endif;

        endif;

        return $price;
    
    }

    /**
     * Returns badge for user groups
     * Hooked via filter woocommerce_before_shop_loop_item_title, priority 20, 3
     * Hooked via filter woocommerce_product_thumbnails, priority 20, 3
     *
     * @param $price
     * @param $product
     *
     * @return string price
     */
    public function add_percentage_to_sale_badge() {
        global $product;

        $user_id               = get_current_user_id();
        $user_group_id         = intval(carbon_get_user_meta($user_id, 'user_group'));
        $product_id            = $product->get_id();
        $discount_setting      = false;
        $user_group_setting    = sejowoo_get_user_group_data($user_group_id);
        $badge_text            = carbon_get_theme_option( 'badge_text' );
        $badge_show_precentage = intval(carbon_get_theme_option( 'badge_show_precentage' ));

        if( $user_group_setting ) :
            if( $product->is_type('variable')){
                $percentages = array();

                // Get all variation prices
                $prices = $product->get_variation_prices();

                // Loop through variation prices
                foreach( $prices['price'] as $key => $price ){
                    // Calculate and set in the array the percentage for each variation on sale
                    // error_log(print_r($prices['sale_price'][$key], true));
                    if($prices['sale_price'][$key] !== $prices['regular_price'][$key]){
                        $percentages[] = round( 100 - ( floatval($prices['sale_price'][$key]) / floatval($prices['regular_price'][$key]) * 100 ) );
                    } else {
                        $percentages[] = round( 100 - ( floatval($product->get_price()) / floatval($prices['regular_price'][$key]) * 100 ) );
                    }
                }
                // We keep the highest value
                $percentage = min($percentages) . '%';
                if($percentage > 0){
                    if($badge_show_precentage === 1) {
                        echo '<span class="onsale">' . $badge_text . ' ' . $percentage . '</span>';
                    } else {
                        echo '<span class="onsale">' . $badge_text . '</span>';
                    }
                }
            } elseif( $product->is_type('grouped') ){
                $percentages = array();

                // Get all variation prices
                $children_ids = $product->get_children();

                // Loop through variation prices
                foreach( $children_ids as $child_id ){
                    $child_product = wc_get_product($child_id);

                    $price = (float) $child_product->get_price();
                    $regular_price = (float) $child_product->get_regular_price();
                    $sale_price    = (float) $child_product->get_sale_price();

                    if ( $sale_price > 0 || ! empty($sale_price) ) {
                        // Calculate and set in the array the percentage for each child on sale
                        $percentages[] = round(100 - ($sale_price / $regular_price * 100));
                    } 
                    if ( $price > 0 || ! empty($price) ) {
                        // Calculate and set in the array the percentage for each child on sale
                        $percentages[] = round(100 - ($price / $regular_price * 100));
                    }
                }
                // We keep the highest value
                $percentage = max($percentages) . '%';
                if($percentage > 0){
                    if($badge_show_precentage === 1) {
                        echo '<span class="onsale">' . $badge_text . ' ' . $percentage . '</span>';
                    } else {
                        echo '<span class="onsale">' . $badge_text . '</span>';
                    }
                }
            } else {
                $price = (float) $product->get_price();
                $regular_price = (float) $product->get_regular_price();
                $sale_price    = (float) $product->get_sale_price();

                if ( $price > 0 || ! empty($price) ) {
                    $percentage = round(100 - ($price / $regular_price * 100)) . '%';
                    if($percentage > 0){
                       if($badge_show_precentage === 1) {
                        echo '<span class="onsale">' . $badge_text . ' ' . $percentage . '</span>';
                    } else {
                        echo '<span class="onsale">' . $badge_text . '</span>';
                    }
                    }
                } else {
                    return false;
                }
            }
        else:
            if( $product->is_type('variable') ) {
                $percentages = array();

                // Get all variation prices
                $prices = $product->get_variation_prices();

                // Loop through variation prices
                foreach( $prices['price'] as $key => $price ){
                    // Only on sale variations
                    if( $prices['regular_price'][$key] !== $price ){
                        // Calculate and set in the array the percentage for each variation on sale
                        $percentages[] = round( 100 - ( floatval($prices['sale_price'][$key]) / floatval($prices['regular_price'][$key]) * 100 ) );
                    } else {
                        $percentages[] = round( 100 - ( floatval($prices['sale_price'][$key]) / floatval($prices['regular_price'][$key]) * 100 ) );
                    }
                }
                // We keep the highest value
                $percentage = max($percentages) . '%';
                if($percentage > 0){
                    if($badge_show_precentage === 1) {
                        echo '<span class="onsale">' . $badge_text . ' ' . $percentage . '</span>';
                    } else {
                        echo '<span class="onsale">' . $badge_text . '</span>';
                    }
                }
            } elseif( $product->is_type('grouped') ) {
                $percentages = array();

                // Get all variation prices
                $children_ids = $product->get_children();

                // Loop through variation prices
                foreach( $children_ids as $child_id ){
                    $child_product = wc_get_product($child_id);

                    $price = (float) $child_product->get_price();
                    $regular_price = (float) $child_product->get_regular_price();
                    $sale_price    = (float) $child_product->get_sale_price();

                    if ( $sale_price > 0 || ! empty($sale_price) ) {
                        // Calculate and set in the array the percentage for each child on sale
                        $percentages[] = round(100 - ($sale_price / $regular_price * 100));
                    } 
                    if ( $price > 0 || ! empty($price) ) {
                        // Calculate and set in the array the percentage for each child on sale
                        $percentages[] = round(100 - ($price / $regular_price * 100));
                    }
                }
                // We keep the highest value
                $percentage = max($percentages) . '%';
                if($percentage > 0){
                    if($badge_show_precentage === 1) {
                        echo '<span class="onsale">' . $badge_text . ' ' . $percentage . '</span>';
                    } else {
                        echo '<span class="onsale">' . $badge_text . '</span>';
                    }
                }
            } else {
                $price = (float) $product->get_price();
                $regular_price = (float) $product->get_regular_price();
                $sale_price    = (float) $product->get_sale_price();

                if ( $sale_price > 0 || ! empty($sale_price) ) {
                    $percentage = round(100 - ($sale_price / $regular_price * 100)) . '%';
                    if($percentage > 0){
                        if($badge_show_precentage === 1) {
                        echo '<span class="onsale">' . $badge_text . ' ' . $percentage . '</span>';
                    } else {
                        echo '<span class="onsale">' . $badge_text . '</span>';
                    }
                    }
                } else {
                    return false;
                }
            }
        endif;
    }

    /**
     * Remove default badge on sale WooCommerce
     * Hooked via filter woocommerce_sale_flash
     *
     * @param $price
     * @param $product
     *
     * @return string price
     */
    public function sejowoo_hide_default_sales_flash() {
        return false;
    }

}
