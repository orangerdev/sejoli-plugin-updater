<?php

namespace Sejowoo;

/**
 * The public-facing functionality of the plugin.
 *
 * @link       https://sejowoo.co.id
 * @since      1.0.0
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/public
 */

/**
 * The public-facing functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the public-facing stylesheet and JavaScript.
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/public
 * @author     Sejoli <orangerdigiart@gmail.com>
 */
class Front {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Set if current page is based on sejowoo request
	 * @since 	1.0.0
	 * @var 	boolean
	 */
	private $is_sejowoo_page = false;

	/**
	 * Check if current method is already called
	 * @since	1.1.2.1
	 * @var 	boolean
	 */
	protected $is_called = false;

	/**
	 * Set woocommerce endpoint
	 * @since 	1.2.0
	 */
	protected $query_vars = array();

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of the plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Set $this->is_sejowoo_page value
	 * Hooked via action sejowoo/myaccount/set-sejowoo-page, priority 1
	 * @since 	1.0.0
	 * @since 	1.1.2 	Remove did_notice
	 * @param 	bool 	$is_page
	 */
	public function set_is_sejowoo_page( bool $is_page) {

		$this->is_sejowoo_page = boolval( $is_page );

	}

	/**
	 * Prepare woocommerce endpoint vars
	 * Hooked via action init, priority 1
	 * @since 	1.2.0
	 * @return 	void
	 */
	public function prepare_woocommerce_endpoint() {

		$this->query_vars = apply_filters( 'sejowoo/my-account-endpoint/vars', $this->query_vars );

	}

	/**
	 * Register my_account endpoint variables
	 * Hooked via filter woocommerce_get_query_vars, priority 1999
	 * @since 	1.1.2.2
	 * @param 	array $vars
	 * @return	array
	 */
	public function register_my_account_endpoint( $vars ) {

		if(
			false === $this->is_called &&
			0 < count($this->query_vars)
		) :

			$vars += $this->query_vars;
			$this->is_called = true;

		 endif;

		return $vars;
	}

	/**
	 * Register CSS Files.
	 * Hooked via action hook wp_enqueue_scripts, priority 999
	 * @since 	1.0.0 	Initialization
	 * @return 	void
	 */
	public function enqueue_styles()
	{

		wp_register_style( 'select2', 			'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.10/css/select2.min.css', [], '4.0.10', 'all' );
		wp_register_style( 'daterangepicker', 	'https://cdnjs.cloudflare.com/ajax/libs/bootstrap-daterangepicker/3.0.5/daterangepicker.min.css', [], '3.0.5', 'all' );
		wp_register_style( 'dataTables',		'https://cdn.datatables.net/1.10.18/css/jquery.dataTables.min.css', 		 [], '1.10.18', 'all');

		wp_register_style(
			$this->plugin_name,
			SEJOWOO_URL . 'public/css/sejowoo-public.css',
			array(),
			$this->version,
			'all'
		);

		wp_register_style(
			$this->plugin_name . '-management',
			SEJOWOO_URL . 'public/css/sejowoo-dashboard-management.css',
			array( 'select2', 'dataTables', 'daterangepicker' ),
			$this->version,
			'all'
		);

		wp_register_style(
			$this->plugin_name . '-checkout',
			SEJOWOO_URL . 'public/css/sejowoo-checkout.css',
			array(),
			$this->version,
			'all'
		);

		/**
		 * Check if current page is woocommerce account page
		 */
		if ( is_account_page() ) :

			wp_enqueue_style( $this->plugin_name );

		endif;

		/**
		 * Check if current page is my-account page using sejowoo
		 */

		if( true === $this->is_sejowoo_page ) :

			wp_enqueue_style( $this->plugin_name . '-management' );

		endif;

		/**
		 * Check if current page is checkout page
		 */
		if( is_checkout() ) :

			wp_enqueue_style( $this->plugin_name . '-checkout' );

		endif;

	}

	/**
	 * Register JS Files.
	 * Hooked via action hook wp_enqueue_scripts, priority 999
	 * @since 	1.0.0 	initialization
	 * @return void
	 */
	public function enqueue_scripts()
	{
		wp_register_script( 'dataTables', 				'https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js', 			['jquery', $this->plugin_name], '1.10.18', true);
		wp_register_script( 'moment',					'https://cdn.jsdelivr.net/momentjs/latest/moment.min.js',					['jquery'], NULL, true);
		wp_register_script( 'daterangepicker',			'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js',		['moment'], NULL, true);

		wp_register_script( 'jsrender', 				'https://cdnjs.cloudflare.com/ajax/libs/jsrender/0.9.91/jsrender.min.js', 	['jquery'], '0.9.91', true );
		wp_register_script( 'clipboardjs', 			 	'https://cdn.jsdelivr.net/npm/clipboard@2/dist/clipboard.min.js', 			[], NULL, false );

		wp_register_script(
			$this->plugin_name,
			SEJOWOO_URL . 'public/js/sejowoo-public.js',
			array( 'jquery' ),
			$this->version,
			false
		);

		wp_register_script(
			$this->plugin_name . '-management',
			SEJOWOO_URL . 'public/js/sejowoo-dashboard-management.js',
			array( 'jquery', 'select2', 'dataTables', 'jsrender', 'daterangepicker' ),
			$this->version,
			false
		);

		$localize_data = apply_filters('sejowoo/myaccount/js-localize-data', array());

		wp_localize_script( $this->plugin_name, 'sejowoo_myaccount', $localize_data);

		wp_localize_script ("dataTables","dataTableTranslation",array(
			"all"			 => __('Semua','sejowoo'),
			"decimal"        => ",",
			"emptyTable"     => __("Tidak ada data yang bisa ditampilkan","sejowoo"),
			"info"           => __("Menampikan _START_ ke _END_ dari _TOTAL_ data","sejowoo"),
			"infoEmpty"      => __("Menampikan 0 ke 0 dari 0 data","sejowoo"),
			"infoFiltered"   => __("Menyaring dari total _MAX_ data","sejowoo"),
			"infoPostFix"    => "",
			"thousands"      => ".",
			"lengthMenu"     => __("Menampilkan _MENU_ data","sejowoo"),
			"loadingRecords" => __("Mengambil data...","sejowoo"),
			"processing"     => __("Memproses data...","sejowoo"),
			"search"         => __("Cari data :","sejowoo"),
			"zeroRecords"    => __("Tidak ditemukan data yang sesuai","sejowoo"),
			"paginate"       =>
			 array(
				"first"    => __("Pertama","sejowoo"),
				"last"     => __("Terakhir","sejowoo"),
				"next"     => __("Selanjutnya","sejowoo"),
				"previous" => __("Sebelumnya","sejowoo")
			),
			"aria"           => array(
				"sortAscending"  => __("Klik untuk mengurutkan kolom naik","sejowoo"),
				"sortDescending" => __("Klik untuk mengurutkan kolom turun","sejowoo")
			)
		));

		/**
		 * Check if current page is woocommerce account page
		 */
		if ( is_account_page() ) :

			wp_enqueue_script( 'jsrender' );
			wp_enqueue_script( 'clipboardjs' );
			wp_enqueue_script( 'jquery-blockui' );
			wp_enqueue_script( $this->plugin_name );

		endif;

		wp_localize_script( $this->plugin_name, "sejowoo_object", array(
			"ajaxurl"			=> admin_url('admin-ajax.php'),
			'text' => [
				'main'     => __('Pengaturan', 'sejowoo'),
				'currency' => 'Rp. ',
				'status'   => [
					'pending'  => __('Belum Aktif', 'sejowoo'),
					'inactive' => __('Tidak Aktif', 'sejowoo'),
					'active'   => __('Aktif', 'sejowoo'),
					'expired'  => __('Berakhir', 'sejowoo')
				]
			],
			'color' => sejowoo_get_all_colors(),
			'order' => [
				'table' => [
					'nonce' => wp_create_nonce('sejowoo-list-orders')
				],
				'detail' => [
					'ajaxurl' => add_query_arg([
						'action' => 'sejowoo-order-detail'
					], admin_url('admin-ajax.php')),
					'nonce' => wp_create_nonce('sejowoo-order-detail')
				],
				'status' => apply_filters('sejowoo/order/status', []),
				'status_classes'	=> [
					'on-hold'     		=> 'danger',
					'payment-confirm' 	=> 'warning',
					'in-progress' 		=> 'info',
					'shipping'    		=> 'primary',
					'completed'   		=> 'success',
					'refunded'    		=> 'default',
					'cancelled'   		=> 'default'
				]
			],
			'subscription' => [
				'table' => [
					'nonce' => wp_create_nonce('sejowoo-list-subscriptions')
				],
				'detail' => [
					'ajaxurl' => add_query_arg([
						'action' => 'sejowoo-order-detail'
					], admin_url('admin-ajax.php')),
					'nonce' => wp_create_nonce('sejowoo-order-detail')
				],
				'status' => apply_filters('sejowoo/order/status', []),
				'type' => [
					'subscription-tryout'  => 'tryout',
					'subscription-signup'  => 'signup',
					'subscription-regular' => 'regular',
				]
			],
		));

		wp_localize_script( $this->plugin_name, "dataTableTranslation", array(
			"all"			 => __('Semua','sejowoo'),
			"decimal"        => ",",
			"emptyTable"     => __("Tidak ada data yang bisa ditampilkan","sejowoo"),
			"info"           => __("Menampikan _START_ ke _END_ dari _TOTAL_ data","sejowoo"),
			"infoEmpty"      => __("Menampikan 0 ke 0 dari 0 data","sejowoo"),
			"infoFiltered"   => __("Menyaring dari total _MAX_ data","sejowoo"),
			"infoPostFix"    => "",
			"thousands"      => ".",
			"lengthMenu"     => __("Menampilkan _MENU_ data","sejowoo"),
			"loadingRecords" => __("Mengambil data...","sejowoo"),
			"processing"     => __("Memproses data...","sejowoo"),
			"search"         => __("Cari data :","sejowoo"),
			"zeroRecords"    => __("Tidak ditemukan data yang sesuai","sejowoo"),
			"paginate"       =>
				array(
				"first"    => __("Pertama","sejowoo"),
				"last"     => __("Terakhir","sejowoo"),
				"next"     => __("Selanjutnya","sejowoo"),
				"previous" => __("Sebelumnya","sejowoo")
			),
			"aria"           => array(
				"sortAscending"  => __("Klik untuk mengurutkan kolom naik","sejowoo"),
				"sortDescending" => __("Klik untuk mengurutkan kolom turun","sejowoo")
			)
		));

		/**
		 * Check if current page is my-account page using sejowoo
		 */

		if( true === $this->is_sejowoo_page ) :

			wp_enqueue_script( $this->plugin_name . '-management' );


		endif;

	}

	/**
	 * Add all sejowoo menu links
	 * Hooked via filter sejowoo/myaccount/links, priority 100
	 * @since 	1.1.2
	 * @param 	array 	$menu_links
	 */
	public function add_my_account_links( $menu_links ) {

		$sejowoo_links = apply_filters('sejowoo/myaccount/links', array() );

		if( is_array($sejowoo_links) && 0 < count( $sejowoo_links) ) :

			$menu_links = array_slice( $menu_links, 0, 1, true )
					        + $sejowoo_links
					        + array_slice( $menu_links, 1, NULL, true );

		endif;

		return $menu_links;
	}

}
