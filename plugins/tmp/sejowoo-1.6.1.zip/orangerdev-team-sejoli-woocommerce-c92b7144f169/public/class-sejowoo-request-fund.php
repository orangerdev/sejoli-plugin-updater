<?php

namespace Sejowoo\Front;

/**
 */
class RequestFund {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

    /**
	 * Set if current action is already checked
	 * @since	1.0.0
	 * @var 	boolean
	 */
	protected $is_checked = false;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

    /**
     *  Set endpoint custom menu
     *  Hooked via action init, priority 1002
     *  @since 		1.0.0
     *  @return 	void
     */
    public function set_endpoint() {

		add_rewrite_endpoint( 'request-fund', EP_PAGES );

		flush_rewrite_rules();
	}

    /**
	 * Set is_sejowoo_page if current page is request fund
	 * Hooked via action parse_query, priority 122
	 * @since 1.0.0
	 */
	public function set_is_sejowoo_page() {

		global $wp_query;

		if(is_admin()) :
			return;
		endif;

		if($this->is_checked) :
			return;
		endif;

		if( array_key_exists( 'request-fund', $wp_query->query_vars ) ) :

			$this->is_checked = true;

			do_action( 'sejowoo/myaccount/set-sejowoo-page', true);

		endif;

	}

    /**
	 * Set my-account localize javascript data
	 * Hooked via filter sejowoo/myaccount/js-localize-data, priority 122
	 * @since 	1.0.0
	 * @param 	array $vars
	 * @return 	array
	 */
	public function set_localize_js_vars( array $vars ) {

		$vars['request_fund'] = array(
			'submit' => array(
				'ajaxurl'	=> site_url('sejowoo-ajax/submit-request-fund'),
				'nonce'		=> wp_create_nonce('sejowoo-submit-request-fund')
			)
		);
		return $vars;
	}

	/**
     *  Add custom woocommerce my account links
     *  Hooked via filter sejowoo/myaccount/links, priority 55
     *  @since 	1.0.0
     *  @since 	1.1.2 	Change hook point
     *  @param 	array 	$menu_links
     *  @return array
     */
    public function add_my_account_links( array $links ){

		$links['request-fund'] 	= __('Pencairan Dana', 'sejowoo');

        return $links;

    }

    /**
     * Set my-account page title
     * Hooked via filter the_title, priority 122
     * @since   1.0.0
     * @param   string  $title
     * @return  string
     */
    public function set_page_title( $title ) {

        global $wp_query;

        if( array_key_exists( 'request-fund', $wp_query->query_vars ) && in_the_loop() ) :
            $title  = __('Pencairan Dana', 'sejowoo');
        endif;

        return $title;
    }

    /**
     * Display request fund page in my-account
     * Hooked via action woocommerce_account_request-fund_endpoint, priority 100
     * @since   1.0.0
     * @return  void
     */
    public function display_request_fund_page() {

        wc_get_template(
            'my-account/request-fund/form.php',
            array(),
            SEJOWOO_DIR . 'templates/',
            SEJOWOO_DIR . 'templates/'
        );

    }

}
