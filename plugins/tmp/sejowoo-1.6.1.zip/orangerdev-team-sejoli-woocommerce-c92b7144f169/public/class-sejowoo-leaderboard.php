<?php

namespace Sejowoo\Front;

/**
 * The affiliate-network public-facing functionality of the plugin.
 *
 * @link       https://sejoli.co.id
 * @since      1.2.0
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/public
 */

/**
 * The leaderboard functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the leaderboard stylesheet and JavaScript.
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/public
 * @author     Sejoli <orangerdigiart@gmail.com>
 */
class Leaderboard {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.2.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.2.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Check if current method is already called
	 * @since	1.1.2.1
	 * @var 	boolean
	 */
	protected $is_called = false;

	/**
	 * Hide affiliate network menu
	 * @since 	1.1.2.2
	 * @var 	boolean
	 */
	protected $is_menu_hidden = true;

	/**
	 * Custom endpoint name.
	 *
	 * @var string
	 */
	public static $endpoint = 'leaderboard';

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since 	1.2.0
	 * @param 	string    $plugin_name       The name of the plugin.
	 * @param   string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

	}

	/**
	 * Register new endpoint to use inside My Account page.
	 *
	 * @see https://developer.wordpress.org/reference/functions/add_rewrite_endpoint/
	 */
	public function add_endpoints() {
	
		add_rewrite_endpoint( self::$endpoint, EP_ROOT | EP_PAGES );
	
	}

	/**
	 * Add new query var.
	 *
	 * @param array $vars
	 * @return array
	 */
	public function add_query_vars( $vars ) {
	
		$vars[] = self::$endpoint;

		return $vars;
	
	}

    /**
    * Register my-account endpont
    * Hooked via filter sejowoo/my-account-endpoint/vars, priority 16
    * @since   1.2.0
    * @param   array   	$query_vars
    * @return  array
    */
    public function register_my_account_endpoint( $query_vars ) {

       if(
           false === $this->is_called &&
           sejowoo_user_can_affiliate() &&
           true !== sejowoo_get_plugin_setup_options()['hide-leaderboard']
       ) :

           $query_vars['leaderboard'] = 'leaderboard';
           $this->is_menu_hidden = false;
           $this->is_called = true;

       endif;

       return $query_vars;
    
    }

    /**
	 * Register needed css and js files
	 * Hooked via action wp_enqueue_scripts, priority 1155
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function register_css_and_js_files( ) {

        global $wp_query;

		if( is_account_page() && isset($wp_query->query['leaderboard'])) :

            wp_register_style ( 'daterangepicker',	'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css',		[], NULL, 'all');
            wp_register_script( 'moment',			'https://cdn.jsdelivr.net/momentjs/latest/moment.min.js',				['jquery'], NULL, true);
    		wp_register_script( 'daterangepicker',	'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js',	['moment'], NULL, true);

			wp_enqueue_style  ( 'daterangepicker' );

			wp_enqueue_script ( 'daterangepicker' );

		endif;

	}

    /**
	 * Set if current page is sejowoo page
	 * Hooked via action template_redirect, priority 155
	 * @since 	1.0.0
	 */
	public function set_is_sejowoo_page() {

        global $wp_query;

		if( is_account_page() && isset($wp_query->query['leaderboard'])) :

			do_action('sejowoo/myaccount/set-sejowoo-page', true);

		endif;

	}

    /**
     *  Add custom woocommerce my account links
     *  Hooked via filter sejowoo/myaccount/links, priority 30
     *  @since 	1.2.0
     *  @param 	array 		$menu_links
     *  @return array
     */
    public function add_my_account_links( array $links ){

		if(
			sejowoo_user_can_affiliate() &&
			true !== $this->is_menu_hidden
		) :

			$links['leaderboard'] 	= __('Leaderboard', 'sejowoo' );

		endif;

        return $links;

    }

    /**
	 * Set my-account localize javascript data
	 * Hooked via filter sejowoo/myaccount/js-localize-data, priority 155
	 * @since 	1.0.0
	 * @param 	array $vars
	 * @return 	array
	 */
	public function set_localize_js_vars( array $vars ) {

		$vars['leaderboard'] = array(

            'table'	=> array(
				'ajaxurl'	=> home_url('sejowoo-ajax/get-table-list'),
				'nonce'		=> wp_create_nonce('sejowoo-render-table-list'),
				'header'	=> array(
					'commission' => __('Total Komisi', 'sejowoo'),
					'quantity'   => __('Total Item', 'sejowoo'),
					'omset'      => __('Total Omset', 'sejowoo')
				),
				'display_point' => boolval( carbon_get_theme_option('sejowoo_display_leaderboard_point') )
			),
		);

        $vars['product'] = array(
            'options' 	=> array(
                'ajaxurl'     => site_url('sejowoo-ajax/get-product-list'),
                'nonce'       => wp_create_nonce('sejowoo-render-product-options'),
                'placeholder' => __('Pilih produk', 'sejowoo')
            )
        );

		return $vars;

	}

    /**
     * Set my-account page title
     * Hooked via filter woocommerce_endpoint_leaderboard_title, priority 1
     * @since   1.0.0
     * @param   string  $title
     * @return  string
     */
    public function set_my_account_title( $title ) {

        return __('Leaderboard', 'sejowoo');

    }

    /**
     * Set my-account page content
     * Hooked via action woocommerce_account_leaderboard_endpoint, priority 1
     * @since   1.0.0
     * @return  void
     */
    public function set_my_account_content( ) {

        wc_get_template(
            'my-account/affiliate/leaderboard.php',
            array(),
            SEJOWOO_DIR . 'templates/',
            SEJOWOO_DIR . 'templates/'
        );

    }

}
