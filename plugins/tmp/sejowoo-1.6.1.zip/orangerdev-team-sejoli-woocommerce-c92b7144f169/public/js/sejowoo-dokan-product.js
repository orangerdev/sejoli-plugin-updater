(function($){

    'use strict';

    $(document).ready(function(){

        if(true === sejowoo_dokan_product.only.simple) {
            $('select[name="product_type"]').parent().remove();
        }

        if(true === sejowoo_dokan_product.only.virtual) {
            $('._is_virtual').parent().parent().remove();
        }
    });

})(jQuery);
