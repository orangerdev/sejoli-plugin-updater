let sejowoo;

function sejowoo_get_nested_object(nestedObj, pathArr){
    return pathArr.reduce((obj, key) =>
        (obj && obj[key] !== 'undefined') ? obj[key] : '', nestedObj);
}

function sejowoo_sanitize_title( str = '' )
{
	str = str.toString();
	str = str.replace(/^\s+|\s+$/g, ''); // trim
	str = str.toLowerCase();

	// remove accents, swap ñ for n, etc
	var from = "àáäâèéëêìíïîòóöôùúüûñçěščřžýúůďťň·/_,:;";
	var to   = "aaaaeeeeiiiioooouuuuncescrzyuudtn------";

	for (var i=0, l=from.length ; i<l ; i++)
	{
		str = str.replace(new RegExp(from.charAt(i), 'g'), to.charAt(i));
	}

	str = str.replace('.', '-') // replace a dot by a dash
		.replace(/[^a-z0-9 -]/g, '') // remove invalid chars
		.replace(/\s+/g, '-') // collapse whitespace and replace by a dash
		.replace(/-+/g, '-') // collapse dashes
		.replace( /\//g, '' ); // collapse all forward-slashes

	return str;
}

(function( $ ) {
	'use strict';

	sejowoo = {
		var : {
			search : [],
			hari : ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'],
			bulan : ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des']
		},
		daterangepicker: function(element, start = '', end = '') {

            if($().daterangepicker) {

				var start = ('' === start) ? moment().subtract(29, 'days') : start;
				var end   = ('' === end) ? moment() : end;

				$(element).daterangepicker({
					startDate: start,
					endDate:   end,
					locale:    {
						format: 'YYYY-MM-DD'
					},
					ranges: {
							'Hari Ini':         [moment(), moment()],
							'7 Hari Terakhir':  [moment().subtract(6, 'days'), moment()],
							'30 Hari Terakhir': [moment().subtract(29, 'days'), moment()],
							'Bulan Ini':        [moment().startOf('month'), moment().endOf('month')],
							'3 Bulan Terakhir': [moment().subtract(3, 'month'), moment()],
							'6 Bulan Terakhir': [moment().subtract(6, 'month'), moment()],
							'1 Tahun Terakhir': [moment().subtract(1, 'year'), moment()],
							'2 Tahun Terakhir': [moment().subtract(2, 'year'), moment()],
						}
					});
			}
		},
		filter: function(selector) {
			var data = [];
            var val = '';
            $( selector ).find('select,input,textarea').each(function(i,e){
                if ( $(e).attr('type') === 'checkbox' ){
                    if ( $(e).prop('checked') ) {
                        val = 1;
                    } else {
                        val = 0;
                    }
                } else {
                    val = $(e).val();
                }
                data.push({
                    'name': $(e).attr('name'),
                    'val': val,
                });
            });
            return data;
		},
		block: function( selector = "" ) {

            if(! $().block || ! $().unblock ) { return; }

			if ( selector ) {
				$( selector ).block({
					message: '<i class="huge notched circle loading icon"></i>',
					css: { backgroundColor: 'transparent', border: 0, color: '#fff' }
				});
			} else {
				$.blockUI({
					message: '<i class="huge notched circle loading icon"></i>',
					css: { backgroundColor: 'transparent', border: 0, color: '#fff' }
				});
			}
		},
		unblock: function( selector = "" ) {

            if(! $().block || ! $().unblock ) { return; }

			if ( selector ) {
				$( selector ).unblock();
			} else {
				$.unblockUI();
			}
		},
		convertdate: function(mysql_date, format) {

			if(!mysql_date) {
				return null;
			}

			let t = mysql_date.split(/[- :]/),
				   d = new Date(Date.UTC(t[0], t[1]-1, t[2], t[3], t[4], t[5]));

			let tanggal = d.getDate(),
				   xhari = d.getDay(),
				   xbulan = d.getMonth(),
				   xtahun = d.getYear();

			let hari = sejowoo.var.hari[xhari],
				   bulan = sejowoo.var.bulan[xbulan],
				   tahun = (xtahun < 1000)?xtahun + 1900 : xtahun;

			return tanggal + ' ' + bulan + ' ' + tahun;
		},
		formatPrice: function(angka) {
			var angka  = parseInt(angka);
			var rupiah   = '';
			var angkarev = angka.toString().split('').reverse().join('');
			for(var i = 0; i < angkarev.length; i++) if(i%3 == 0) rupiah += angkarev.substr(i,3)+'.';
			return rupiah.split('',rupiah.length-1).reverse().join('');
		},
		affiliate : {
			link: {
				init: function() {
					sejowoo.affiliate.link.other();
				},
				other: function() {

					$(document).on('submit','#aff-link-parameter',function(e){
						e.preventDefault();

						var param_platform = sejowoo_sanitize_title($('#param-platform').val());
						var param_id = sejowoo_sanitize_title($('#param-id').val());

						$('#affiliate-link-holder input').each(function(){

							var utm_source = 1;
							var utm_media = 1;
							var link = $(this).val();
							var link_arr = link.split("?");
							var link_new = link_arr[0];

							if ( link_arr.length > 1 ) {

								var link_param_arr = link_arr[1].split("&");

								var link_param_arr_length = link_param_arr.length-1;
								link_param_arr.forEach( function(item, index) {
									var param_arr = item.split('=');

									if ( param_arr[0] === 'utm_source' ) {
										utm_source = 0;
										param_arr[1] = param_platform;
									}
									if ( param_arr[0] === 'utm_media' ) {
										utm_media = 0;
										param_arr[1] = param_id;
									}

									if ( index === 0 ) {
										link_new += '?'+param_arr[0]+'='+param_arr[1];
									} else if ( index === link_param_arr_length ) {
										link_new += '&'+param_arr[0]+'='+param_arr[1];
									} else {
										link_new += param_arr[0]+'='+param_arr[1]+'&';
									}

								});

							}

							if ( utm_source === 1 ) {
								var separator = link_new.indexOf('?') !== -1 ? '&' : '?';
								link_new += separator+'utm_source='+param_platform;
							}
							if ( utm_media === 1 ) {
								var separator = link_new.indexOf('?') !== -1 ? '&' : '?';
								link_new += separator+'utm_media='+param_id;
							}

							$(this).val(link_new);

						});

					});
				}
			}
		}
    }

	$(document).ready(function(){

        if (typeof ClipboardJS === 'function') {

    		var clipboard = new ClipboardJS('.copy-btn' );

        }

	});

})( jQuery );
