<?php
/**
 * @since   1.0.0
 */

    defined( 'ABSPATH' ) || exit;

    $user    = wp_get_current_user();
    $text    = str_replace(
                array(
                    '{{buyer_name}}',
                    '{{product_name}}'
                ),
                array(
                    '<span class="buyer-name">' . $user->display_name . '</span>',
                    '<span class="product-name"></span>'
                ),
                $this->popup_text
               );
    $has_photo = ( $this->is_avatar_showed || $this->is_product_image_showed ) ? 'has-photo' : '';
?>
<div class="social-proof-container <?php echo $this->position; ?>">
    <input type="hidden" name="social-proof-orders" id='social-proof-orders' value="">
    <section id='social-proof-holder' class="social-proof-holder <?php echo $has_photo; ?> animated">
    <?php if( $this->is_avatar_showed || $this->is_product_image_showed ) : ?>
        <figure class='buyer-photo'>
            <?php echo get_avatar($user); ?>
        </figure>
    <?php endif; ?>
        <div class="buyer-detail">
            <div class="buyer-text"><?php echo $text; ?></div>
            <span class='order-text'><?php _e('45 menit lalu', 'sejowoo'); ?></span>
        </div>
    </section>
</div>
