<?php

namespace Sejowoo\Front;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

class Cashback {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

    /**
     * Potential cashback value
     *
     * @since   1.0.0
     * @var     float
     */
    protected $cashback_value = 0.0;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

    /**
     * Calculate potensial cashback
     * Hooked via action woocommerce_before_checkout_form, priority 10
     * @since   1.0.0
     * @return  void
     */
    public function calculate_potential_cashback() {

        global $woocommerce;

		$cashback = 0;

        foreach( (array) $woocommerce->cart->get_cart() as $cart_key => $item ) :

            $cashback_setting = apply_filters( 'sejowoo/cashback/setting', false, $item);
        	
            if(
				false !== $cashback_setting &&
				true === $cashback_setting['enabled']
			) :

                if('fixed' === $cashback_setting['type'] ) :
                    $cashback += (float) ( $item['quantity'] * $cashback_setting['value'] );
                else :
                    $cashback += (float) ( ( $cashback_setting['value'] * $item['line_subtotal'] ) / 100 );
                endif;

            endif;

            // Enabled later
            // $cashback = apply_filters( 'sejoli/cashback/value', $cashback, $item['data'], $user_group_data, $calculate_by );

        endforeach;

        $this->cashback_value = $cashback;

    }

    /**
     * Display cashback info
     * Hooked via action woocommerce_checkout_order_review, priority 11
     * @since   1.0.0
     * @return  void
     */
    public function display_cashback_info() {

		$display_cashback_info = apply_filters( 'sejowoo/checkout/display-cashback-info', true );

		if( false !== $display_cashback_info ) :

			$cashback = $this->cashback_value;

			require_once ( SEJOWOO_DIR . 'templates/checkout/cashback-info.php');

		endif;
    }

	/**
	 * Display cashback info by update_order_review via ajax
	 * Hooked via filter woocommerce_update_order_review_fragments, priority 100
	 * @since 	1.0.0
	 * @param  	array  	$fragments
	 * @return 	array
	 */
	public function ajax_display_cashback_info( array $fragments ) {

		$display_cashback_info = apply_filters( 'sejowoo/checkout/display-cashback-info', true );

		if( false !== $display_cashback_info ) :

			$this->calculate_potential_cashback();

			$cashback = $this->cashback_value;

			ob_start();

			require_once ( SEJOWOO_DIR . 'templates/checkout/cashback-info.php');

			$content  = ob_get_clean();

			$fragments['.sejowoo-display-cashback-info'] = $content;

		else :

			$fragments['.sejowoo-display-cashback-info'] = '';

		endif;

		return $fragments;

	}

}
