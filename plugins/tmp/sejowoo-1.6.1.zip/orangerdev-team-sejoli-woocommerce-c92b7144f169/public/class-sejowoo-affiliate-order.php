<?php

namespace Sejowoo\Front;

class AffiliateOrder
{

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Check if current method is already called
	 * @since	1.1.2.1
	 * @var 	boolean
	 */
	protected $is_called = false;

	/**
	 * Hide affiliate order menu
	 * @since	1.1.2.2
	 * @var 	boolean
	 */
	protected $is_menu_hidden = true;

	/**
	 * Custom endpoint name.
	 *
	 * @var string
	 */
	public static $endpoint = 'affiliate-order';

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

	}

	/**
	 * Register new endpoint to use inside My Account page.
	 *
	 * @see https://developer.wordpress.org/reference/functions/add_rewrite_endpoint/
	 */
	public function add_endpoints() {
		
		add_rewrite_endpoint( self::$endpoint, EP_ROOT | EP_PAGES );
	
	}

	/**
	 * Add new query var.
	 *
	 * @param array $vars
	 * @return array
	 */
	public function add_query_vars( $vars ) {
	
		$vars[] = self::$endpoint;

		return $vars;
	
	}

	/**
	 * Set is_sejowoo_page if current page is request fund
	 * Hooked via action parse_query, priority 111
	 * @since 	1.0.0
	 * @since 	1.1.0	Add function_exists condition to prevent error when the
	 * 					plugin activated without WooCommerce
	 * @since 	1.2.1	Enhance is_wc_endpoint_url
	 *
	 */
	public function set_is_sejowoo_page() {

		if( sejowoo_check_endpoint_url( 'affiliate-order' ) ) :

			do_action( 'sejowoo/myaccount/set-sejowoo-page', true);

		endif;

	}

	/**
	 * Set my-account localize javascript data
	 * Hooked via filter sejowoo/myaccount/js-localize-data, priority 122
	 * @since 	1.0.0
	 * @param 	array $vars
	 * @return 	array
	 */
	public function set_localize_js_vars( array $vars ) {

		$vars['order'] = array(
			'table' => array(
				'ajaxurl'	=> site_url('sejowoo-ajax/get-order-list'),
				'nonce'		=> wp_create_nonce('sejowoo-render-order-table')
			),
			'status'	=> wc_get_order_statuses()
		);
	
		return $vars;
	
	}

	/**
     * Set my-account page title
     * Hooked via filter the_title, priority 111
     * @since   1.0.0
     * @param   string  $title
     * @return  string
     */
    public function set_my_account_title( $title ) {

		$title  = __('Order Dari Affiliasi Anda', 'sejowoo');

        return $title;
    
    }

	/**
     *  Display affiliate order content
     *  Hooked via action woocommerce_account_affiliasi-order_endpoint, priority 1
     *  @since 	1.0.0
     *  @return void
     */
    public function set_my_account_content() {

		wc_get_template(
			'my-account/affiliate/order.php',
			array(),
			SEJOWOO_DIR . 'templates/',
			SEJOWOO_DIR . 'templates/'
		);

	}

	/**
	 * Register my-account endpoint
	 * Hooked via filter sejowoo/my-account-endpoint/vars, priority 10
	 * @since 	1.0.0
	 * @since 	1.1.2 	Add condition to hide link
	 * @param  	array  $vars
	 * @return 	array
	 */
	public function register_my_account_endpoint( array $vars ) {

		if(
			sejowoo_user_can_affiliate() &&
			false === $this->is_called &&
			true !== sejowoo_get_plugin_setup_options()['hide-affiliate-order']
		) :

			$vars['affiliate-order'] = 'affiliate-order';
			$this->is_menu_hidden = false;

			$this->is_called = true;

			if( is_admin() ) :
				$this->is_called = true;
			endif;

		endif;

		return $vars;
	
	}

	/**
     *  Add custom woocommerce my account links
     *  Hooked via filter sejowoo/myaccount/links, priority 5
     *  @since 	1.0.0
     *  @since 	1.1.2 	Change hook point
     *  @param 	array 	$menu_links
     *  @return array
     */
    public function add_my_account_links( array $links ){

		if(
			sejowoo_user_can_affiliate() &&
			true !== $this->is_menu_hidden
		) :

			$links['affiliate-order'] = __('Order Affiliasi', 'sejowoo' );

		endif;

        return $links;

    }

}
