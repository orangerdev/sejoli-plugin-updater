<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://sejoli.co.id
 * @since             1.0.0
 * @package           Sejowoo
 *
 * @wordpress-plugin
 * Plugin Name:       Sejoli feat WooCommerce
 * Plugin URI:        https://sejoli.co.id
 * Description:       Premium membership plugin that integrates with WooCommerce.
 * Version:           1.6.1
 * Author:            Sejoli
 * Author URI:        https://sejoli.co.id
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       sejowoo
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

global $sejowoo;

function sejowoo_check_woongkir_plugin(){

    if(is_plugin_active('woongkir/woongkir.php')){
		return false;
	} else {
		require_once plugin_dir_path( __FILE__ ) . 'plugins/woongkir/woongkir.php';
	}

}
add_action('init', 'sejowoo_check_woongkir_plugin');

$sejowoo = array(
	'active'	=> true,
	'data'		=> array(
		'commission'      => array(),
		'commission-post' => array()
	)
);

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
 /**
  * Currently plugin version.
  * Start at version 1.3.1 and use SemVer - https://semver.org
  * Rename this for your plugin and update it as you release new versions.
  */
 define( 'SEJOWOO_VERSION', 			'1.6.1' );
 define( 'SEJOWOO_MODE',				'production');
 define( 'SEJOWOO_DIR',	 				plugin_dir_path(__FILE__));
 define( 'SEJOWOO_URL',					plugin_dir_url(__FILE__));

/**
 * Define all needed post types
 */
 define( 'SEJOWOO_AFFILIATE_CPT', 		'sejowoo-affiliasi');
 define( 'SEJOWOO_USER_GROUP_CPT',		'sejowoo-user-group');
 define( 'SEJOWOO_COMMISSION_CPT', 		'sejowoo-commission');
 define( 'SEJOWOO_PRODUCT_CPT',			'product');
 define( 'SEJOWOO_COUPON_CPT',			'shop_coupon');
 define( 'SEJOWOO_ORDER_CPT',			'shop_order');

 /**
  * All available WooCommerce product types
  */
 define( 'SEJOWOO_WC_PRODUCT_TYPES',	array('product', 'product_variation') );

 if(version_compare(PHP_VERSION, '7.0.8') < 0 && !class_exists( 'WP_CLI' )) :

 	add_action('admin_notices', 'sejowoo_error_php_message', 1);

 	/**
 	 * Display error message when PHP version is lower than 7.2.0
 	 * Hooked via admin_notices, priority 1
 	 * @return 	void
 	 */
 	function sejolisa_error_php_message() {
 		?>
 		<div class="notice notice-error">
 			<h2>SEJOLI TIDAK BISA DIGUNAKAN DI HOSTING ANDA</h2>
 			<p>
 				Versi PHP anda tidak didukung oleh SEJOLI dan HARUS diupdate. Update versi PHP anda ke versi yang terbaru. <br >
 				Minimal versi PHP adalah 7.0.8 dan versi PHP anda adalah <?php echo PHP_VERSION; ?>
 			</p>
 			<p>
 				Jika anda menggunakan cpanel, anda bisa ikuti langkah ini <a href='https://www.rumahweb.com/journal/memilih-versi-php-melalui-cpanel/' target="_blank" class='button'>Update Versi PHP</a>
 			</p>
 			<p>
 				Jika anda masih kesulitan untuk update versi PHP anda, anda bisa meminta bantuan pada CS hosting anda.
 			</p>
 		</div>
 		<?php
 	}

 else :

	/**
	 * The code that runs during plugin activation.
	 * This action is documented in includes/class-sejowoo-activator.php
	 */
	function activate_sejowoo() {
		require_once plugin_dir_path( __FILE__ ) . 'includes/class-sejowoo-activator.php';
		Sejowoo_Activator::activate();
	}

	/**
	 * The code that runs during plugin deactivation.
	 * This action is documented in includes/class-sejowoo-deactivator.php
	 */
	function deactivate_sejowoo() {
		require_once plugin_dir_path( __FILE__ ) . 'includes/class-sejowoo-deactivator.php';
		Sejowoo_Deactivator::deactivate();
	}

	register_activation_hook( __FILE__, 'activate_sejowoo' );
	register_deactivation_hook( __FILE__, 'deactivate_sejowoo' );

	/**
	 * Required third party scripts
	 */
	require SEJOWOO_DIR . '/third-parties/autoload.php';

	/**
	 * The core plugin class that is used to define internationalization,
	 * admin-specific hooks, and public-facing site hooks.
	 */
	require plugin_dir_path( __FILE__ ) . 'includes/class-sejowoo.php';

	/**
	 * Begins execution of the plugin.
	 *
	 * Since everything within the plugin is registered via hooks,
	 * then kicking off the plugin from this point in the file does
	 * not affect the page life cycle.
	 *
	 * @since    1.0.0
	 */
	function run_sejowoo() {

		$plugin = new Sejowoo();
		$plugin->run();

	}

	if(!function_exists('__debug')) :
	function __debug()
	{
		$bt     = debug_backtrace();
		$caller = array_shift($bt);
		$args   = [
			"file"  => $caller["file"],
			"line"  => $caller["line"],
			"args"  => func_get_args()
		];

		if ( class_exists( 'WP_CLI' ) || sejowoo_is_ajax_request() ) :
			?><pre><?php print_r($args); ?></pre><?php
		else :
			do_action('qm/info', $args);
		endif;
	}
	endif;

	if(!function_exists('__print_debug')) :

	function __print_debug()
	{
		if( 'production' === SEJOWOO_MODE ) :
			return;
		endif;

		$bt     = debug_backtrace();
		$caller = array_shift($bt);
		$args   = [
			"file"  => $caller["file"],
			"line"  => $caller["line"],
			"args"  => func_get_args()
		];

		?><pre><?php print_r($args); ?></pre><?php
	}
	endif;

	run_sejowoo();

endif;
