<?php

namespace Sejowoo\Admin;

use Carbon_Fields\Container;
use Carbon_Fields\Field;
use Brick\PhoneNumber\PhoneNumber;
use Brick\PhoneNumber\PhoneNumberParseException;

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://ridwan-arifandi.com
 * @since      1.0.0
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/admin
 * @author     Ridwan Arifandi <orangerdigiart@gmail.com>
 */
class User {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;


	/**
	 * All affiliate data
	 * @since 	1.1.0
	 * @var 	array
	 */
	protected $affiliates = array();

	/**
	 * Set woocommerce log $context
	 * @since 	1.0.0
	 * @var		array
	 */
	protected $log = array(
		'source' => 'sejowoo-user-affiliate'
	);

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Create member role
	 * Hooked via init, priority 1
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function create_member_role() {

		global $wp_roles;

		if( !isset( $wp_roles) ) :
			$wp_roles = new WP_Roles();
		endif;

		/**
		 * Add custom role to administrator
		 */
		$wp_roles->add_cap('administrator', 'manage_sejoli_sejoli');
		$wp_roles->add_cap('administrator', 'manage_sejoli_products');
		$wp_roles->add_cap('administrator', 'manage_sejoli_orders');
		$wp_roles->add_cap('administrator', 'manage_sejoli_subscriptions');
		$wp_roles->add_cap('administrator', 'manage_sejoli_coupons');
		$wp_roles->add_cap('administrator', 'manage_sejoli_commissions');
		$wp_roles->add_cap('administrator', 'manage_sejoli_licenses');
		$wp_roles->add_cap('administrator', 'manage_sejoli_wallet');

		// Reminders
		$wp_roles->add_cap('administrator', 'edit_others_sejoli_reminders');
		$wp_roles->add_cap('administrator', 'edit_sejoli_reminders');
		$wp_roles->add_cap('administrator', 'publish_sejoli_reminders');
		$wp_roles->add_cap('administrator', 'read_private_sejoli_reminders');
		$wp_roles->add_cap('administrator',	'edit_sejoli_reminder');
		$wp_roles->add_cap('administrator',	'delete_sejoli_reminder');
		$wp_roles->add_cap('administrator',	'read_sejoli_reminder');

		// Access
		$wp_roles->add_cap('administrator', 'edit_others_sejoli_accesses');
		$wp_roles->add_cap('administrator', 'edit_sejoli_accesses');
		$wp_roles->add_cap('administrator', 'publish_sejoli_accesses');
		$wp_roles->add_cap('administrator', 'read_private_sejoli_accesses');
		$wp_roles->add_cap('administrator',	'edit_sejoli_access');
		$wp_roles->add_cap('administrator',	'delete_sejoli_access');
		$wp_roles->add_cap('administrator',	'read_sejoli_access');

		// Commission
		$wp_roles->add_cap('administrator', 'edit_others_sejowoo_commissions');
		$wp_roles->add_cap('administrator', 'edit_sejowoo_commissions');
		$wp_roles->add_cap('administrator', 'publish_sejowoo_commissions');
		$wp_roles->add_cap('administrator', 'read_private_sejowoo_commissions');
		$wp_roles->add_cap('administrator',	'edit_sejowoo_commission');
		$wp_roles->add_cap('administrator',	'delete_sejowoo_commission');
		$wp_roles->add_cap('administrator',	'read_sejowoo_commission');

		// Any Content
		$wp_roles->add_cap('administrator', 'edit_others_sejoli_content');
		$wp_roles->add_cap('administrator', 'edit_sejoli_content');
		$wp_roles->add_cap('administrator', 'publish_sejoli_content');
		$wp_roles->add_cap('administrator', 'read_private_sejoli_content');
		$wp_roles->add_cap('administrator',	'edit_sejoli_content');
		$wp_roles->add_cap('administrator',	'delete_sejoli_content');
		$wp_roles->add_cap('administrator',	'read_sejoli_content');

		$wp_roles->add_cap('administrator', 'sejoli_user_can_access_admin');

		/**
		 * Modify WooCommerce Shop Manager Role
		 */

		$wp_roles->add_cap('shop_manager', 'manage_sejoli_products');
		$wp_roles->add_cap('shop_manager', 'manage_sejoli_orders');
		$wp_roles->add_cap('shop_manager', 'manage_sejoli_subscriptions');
		$wp_roles->add_cap('shop_manager', 'manage_sejoli_coupons');
		$wp_roles->add_cap('shop_manager', 'manage_sejoli_commissions');
		$wp_roles->add_cap('shop_manager', 'manage_sejoli_licenses');
		$wp_roles->add_cap('administrator', 'manage_sejoli_wallet');

		// Commission
		$wp_roles->add_cap('shop_manager', 'edit_others_sejowoo_commissions');
		$wp_roles->add_cap('shop_manager', 'edit_sejowoo_commissions');
		$wp_roles->add_cap('shop_manager', 'publish_sejowoo_commissions');
		$wp_roles->add_cap('shop_manager', 'read_private_sejowoo_commissions');
		$wp_roles->add_cap('shop_manager', 'edit_sejowoo_commission');
		$wp_roles->add_cap('shop_manager', 'delete_sejowoo_commission');
		$wp_roles->add_cap('shop_manager', 'read_sejowoo_commission');

		// Reminders
		$wp_roles->add_cap('shop_manager', 'edit_others_sejoli_reminders');
		$wp_roles->add_cap('shop_manager', 'edit_sejoli_reminders');
		$wp_roles->add_cap('shop_manager', 'publish_sejoli_reminders');
		$wp_roles->add_cap('shop_manager', 'read_private_sejoli_reminders');
		$wp_roles->add_cap('shop_manager', 'edit_sejoli_reminder');
		$wp_roles->add_cap('shop_manager', 'delete_sejoli_reminder');
		$wp_roles->add_cap('shop_manager', 'read_sejoli_reminder');

		// Access
		$wp_roles->add_cap('shop_manager', 'edit_others_sejoli_accesses');
		$wp_roles->add_cap('shop_manager', 'edit_sejoli_accesses');
		$wp_roles->add_cap('shop_manager', 'publish_sejoli_accesses');
		$wp_roles->add_cap('shop_manager', 'read_private_sejoli_accesses');
		$wp_roles->add_cap('shop_manager', 'edit_sejoli_access');
		$wp_roles->add_cap('shop_manager', 'delete_sejoli_access');
		$wp_roles->add_cap('shop_manager', 'read_sejoli_access');

		// Any Content
		$wp_roles->add_cap('shop_manager', 'edit_others_sejoli_content');
		$wp_roles->add_cap('shop_manager', 'edit_sejoli_content');
		$wp_roles->add_cap('shop_manager', 'publish_sejoli_content');
		$wp_roles->add_cap('shop_manager', 'read_private_sejoli_content');
		$wp_roles->add_cap('shop_manager', 'edit_sejoli_content');
		$wp_roles->add_cap('shop_manager', 'delete_sejoli_content');
		$wp_roles->add_cap('shop_manager', 'read_sejoli_content');

		$wp_roles->add_cap('shop_manager', 'sejoli_user_can_access_admin');

		/**
		 * Create member role
		 */
		$member_role = $wp_roles->get_role('subscriber');

		$wp_roles->add_role('sejoli-member', 'Member', $member_role->capabilities);

		$wp_roles->add_cap('sejoli-member', 'manage_sejoli_own_coupons');
		$wp_roles->add_cap('sejoli-member', 'manage_sejoli_own_affiliates');
		$wp_roles->add_cap('sejoli-member', 'manage_sejoli_own_orders');
	}

	/**
	 * Add JS Vars for localization
	 * Hooked via sejowoo/admin/js-localize-data, priority 1
	 * @since 	1.0.0
	 * @param 	array 	$js_vars 	Array of js vars
	 * @return 	array
	 */
	public function set_localize_js_var(array $js_vars) {

		$js_vars['user'] = [
			'select' => [
				'ajaxurl' => add_query_arg([
					'action' => 'sejowoo-user-options',
				], admin_url('admin-ajax.php')),
				'nonce' => wp_create_nonce('sejowoo-render-user-options')
			],
			'placeholder' => __('Pencarian user', 'sejowoo')
		];

		return $js_vars;
	}

	/**
	 * Add profile fields
	 * Hooked via action carbon_fields_register_fields, priority 999
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function setup_profile_fields() {

		$fields = apply_filters( 'sejowoo/user/fields', []);

		if(is_array($fields) && 0 < count($fields)) :
			$container = Container::make('user_meta', __('Sejowoo Profile', 'sejowoo'))
				->set_classes('sejowoo-metabox');

			foreach($fields as $field) :
				$container->add_tab($field['title'], $field['fields']);
			endforeach;
		endif;

	}

	/**
	 * Hide admin bar for non administrator
	 * Hooked via filter show_admin_bar, priority 1
	 * @since 	1.0.0
	 * @since 	1.4.0		Enable show admin bar for all user
	 * @param 	boolean 	$is_show	Current state of admin bar
	 * @return 	boolean 	State if admin bar showed or n
	 */
	public function hide_admin_bar($is_show = true) {

		if(!is_user_logged_in()) :
			return false;
		endif;

		return $is_show;

	}
	/**
	 * Disable admin page access if user is not grnated
	 * Hooked via action admin_init, priority 1
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function disable_admin_access() {

		if(
			(!is_user_logged_in() || !current_user_can('sejoli_user_can_access_admin')) &&
			false === wp_doing_ajax()
		) :
			wp_redirect( home_url('/member-area/'));
			exit;
		endif;
	}

	/**
	 * Add custom columns to user table
	 * Hooked via filter manage_user_columns, priority 1
	 * @since 	1.1.0
	 * @param  	array  $columns Current user columns
	 * @return 	array
	 */
	public function modify_user_table(array $columns) {

		unset($columns['posts']);

		$columns['sejowoo-affiliate']	= __('Affiliasi', 'sejowoo');
		// $columns['sejoli-history']		= __('Log', 'sejowoo');

		return $columns;
	}

	/**
	 * Declare property meta under WP_User
	 * Hooked via filter sejowoo/user/meta-data, priority 11
	 * @since 	1.0.0
	 * @param 	WP_User $user
	 * @return 	WP_User
	 */
	public function declare_user_meta($user) {

		if(!property_exists($user, 'meta')) :
			$user->meta = new \stdClass();
		endif;

		return $user;
	}

	/**
	 * Set user meta
	 * Hooked via filter sejowoo/user/meta-data, priority 100
	 * @since 	1.0.0
	 * @param 	WP_User $user
	 * @return 	WP_User
	 */
	public function set_user_meta($user) {

		$user->meta->phone       = get_user_meta($user->ID, 'billing_phone'); //carbon_get_user_meta($user->ID, 'phone');
		$user->meta->address     = carbon_get_user_meta($user->ID, 'address');
		$user->meta->destination = carbon_get_user_meta($user->ID, 'destination');

		return $user;
	}

	/**
	 * Get affiliate name
	 * @since 	1.1.0
	 * @param  	integer $user_id
	 * @return 	string
	 */
	protected function get_affiliate_name($user_id) {

		$affiliate_id = get_user_meta($user_id, sejowoo_get_affiliate_key(), true);

		if(empty($affiliate_id)) :
			return '-';
		endif;

		if(!isset($this->affiliates[$affiliate_id])) :
			$this->affiliates[$affiliate_id] = sejowoo_get_user($affiliate_id);
		endif;

		return $this->affiliates[$affiliate_id]->display_name;
	}

	/**
	 * Display custom column value
	 * Hooked via filter manage_users_custom_column, priority 100
	 * @since 	1.1.0
	 * @param  	string 	$value
	 * @param  	string 	$column_name
	 * @param  	integer 	$user_id
	 * @return 	string
	 */
	public function display_value_for_custom_table($value, $column_name, $user_id) {

		if('sejowoo-affiliate' === $column_name) :
			return $this->get_affiliate_name($user_id);
		endif;

		return $value;
	}

	/**
	 * Set affiliate value based on order meta to user meta
	 * Hooked via action woocommerce_checkout_order_created, priority 10
	 * @since 	1.0.0
	 * @since 	1.1.2.1 	Change hook and any parameters
	 * @param  	integer 	$order
	 * @param 	array  		$post_data
	 * @param 	WC_Order 	$order
	 */
	public function set_affiliate( \WC_Order $order ) {

		$user_id              = $order->get_user_id();
		$current_affiliate_id = get_user_meta( $user_id, sejowoo_get_affiliate_key(), true);

		if(
			false === $current_affiliate_id ||
			empty($current_affiliate_id)
		) :

			$order_affiliate_id = intval( $order->get_meta( sejowoo_get_affiliate_key(), true) );
			$set_affiliate      = apply_filters( 'sejowoo/user/set-affiliate', true, $order );

			if(
				0 !== $order_affiliate_id &&
				!empty($order_affiliate_id) &&
				false !== $set_affiliate
			) :

				$logger = wc_get_logger();

				update_user_meta(
					$user_id,
					sejowoo_get_affiliate_key(),
					$order_affiliate_id
				);

				$logger->info(
					sprintf(
						__('User %s set affiliate as %s', 'sejowoo'),
						$user_id,
						$order_affiliate_id
					),
					$this->log
				);

			endif;

		endif;
	}

	/**
	 * Get all affiliate user
	 * Hooked via filter sejowoo/user/affiliate-user, priority 1
	 * @since  1.0.0
	 * @return array
	 */
	public function get_affiliate_users($options = array()) {

	    $options = [];

	    $users = get_users();

	    foreach($users as $user){
	        $options[$user->ID] =  $user->display_name . ' - ' . $user->user_email;
	    }

	    asort($options);

	    return $options;

	}

	/**
	 * Add custom js in profile page
	 * Hooked via action admin_footer, priority 999
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function add_profile_js() {

		global $pagenow;

		if(in_array($pagenow, ['profile.php', 'user-edit.php'])) :
		?>
		<script type="text/javascript">
		jQuery(document).ready(function($){
			sejowoo.helper.select_2(
	            "select[name='carbon_fields_compact_input[_affiliate_id]']",
	            sejowoo_admin.user.select.ajaxurl,
	            sejowoo_admin.affiliate.placeholder
	        );
		});
		</script>
		<?php
		endif;
		
	}

	 /**
	 * Set User Affiliate Field
	 * Hooked via action show_user_profile, priority 10
	 * Hooked via action edit_user_profile, priority 10
	 * @since  1.0.0
	 * @return array
	 */
	function set_user_affiliate( $user ) {

		$html = '';

		require_once( plugin_dir_path( __FILE__ ) . 'partials/user/user-affiliate.php' );

		echo $html;

	}

	/**
	 * Save User Affiliate Field
	 * Hooked via action personal_options_update, priority 10
	 * Hooked via action edit_user_profile_update, priority 10
	 * @since  1.0.0
	 * @return array
	 */
	function save_user_affiliate_profile_fields( $user_id ) {

	    if ( !current_user_can( 'edit_user', $user_id ) )
	        return false;

	    /* Edit the following lines according to your set fields */
	    update_usermeta( $user_id, '_affiliate_id', $_POST['affiliate_id'] );
	
	}

}
