<?php

namespace Sejowoo\Admin;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://sejowoo.co.id
 * @since      1.0.0
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/admin
 * @author     sejowoo <orangerdigiart@gmail.com>
 */
class UserGroup {

    /**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Commission fields
	 * @since	1.0.0
	 * @var 	array
	 */
	protected $commission_fields = array();

	/**
	 * Avalaible user roles
	 * @since	1.0.0
	 * @var 	array
	 */
	protected $available_roles = NULL;

	/**
	 * Set temporary user groups
	 * @var array
	 */
	protected $current_user_groups = array();

	/**
	 * Set temporary single user group
	 * @since 	1.1.0
	 * @var 	false|array
	 */
	protected $current_user_group = false;

	/**
	 * Static transient keys
	 * @since 	1.0.0
	 * @var 	array
	 */
	protected $transient_key	= array(
		'upgrade'	=> 'sejowoo_user_group_upgrade'
	);

	/**
	 * Enable empty option in dropdown
	 * @since 	1.0.2
	 * @var 	boolean
	 */
	protected $enable_empty_option = false;

	/**
	 * WooCommerce log
	 * @since 	1.0.2
	 * @var 	array
	 */
	protected $log = array(
		'source' => 'sejowoo-update-group'
	);

	/**
	 * Dropdown options
	 * @since 	1.1.2.3
	 * @var 	false|array
	 */
	protected $dropdown_options = false;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name     = $plugin_name;
		$this->version         = $version;

	}

    /**
     * Register access post type
     * Hooked via action init, priority 1010
     * @return void
     */
    public function register_post_type() {

		if( ! sejowoo_is_woocommerce_active() || false === sejowoo_check_own_license() ) :
			return;
		endif;

		$labels = [
    		'name'               => _x( 'User Group', 'post type general name', 'sejowoo' ),
    		'singular_name'      => _x( 'User Group', 'post type singular name', 'sejowoo' ),
    		'menu_name'          => _x( 'User Group', 'admin menu', 'sejowoo' ),
    		'name_admin_bar'     => _x( 'User Group', 'add new on admin bar', 'sejowoo' ),
    		'add_new'            => _x( 'Add New', 'access', 'sejowoo' ),
    		'add_new_item'       => __( 'Add New User Group', 'sejowoo' ),
    		'new_item'           => __( 'New User Group', 'sejowoo' ),
    		'edit_item'          => __( 'Edit User Group', 'sejowoo' ),
    		'view_item'          => __( 'View User Group', 'sejowoo' ),
    		'all_items'          => __( 'All User Groups', 'sejowoo' ),
    		'search_items'       => __( 'Search User Group', 'sejowoo' ),
    		'parent_item_colon'  => __( 'Parent User Group:', 'sejowoo' ),
    		'not_found'          => __( 'No access found.', 'sejowoo' ),
    		'not_found_in_trash' => __( 'No access found in Trash.', 'sejowoo' )
    	];

    	$args = [
    		'labels'             => $labels,
            'description'        => __( 'Description.', 'sejowoo' ),
    		'public'             => true,
    		'publicly_queryable' => false,
    		'show_ui'            => true,
    		'show_in_menu'       => true,
    		'query_var'          => true,
    		'rewrite'            => [ 'slug' => 'sejowoo-user-group' ],
    		'capability_type'    => 'post',
    		'has_archive'        => true,
    		'hierarchical'       => false,
    		'menu_position'      => 37,
    		'supports'           => [ 'title' ],
			'menu_icon'			 => ! defined('zshop') ? plugin_dir_url( __FILE__ ) . 'images/icon.png' : NULL
    	];

    	register_post_type( SEJOWOO_USER_GROUP_CPT, $args );
    }

	/**
	 * Set cashback configuration setting
	 * Hooked via filter sejowoo/cashback/setting, priority 5
	 * @since 	1.0.0
	 * @param  	array|false 				$cashback_setting
	 * @param  	WC_Order_Item_Product 		$item
	 * @return 	array|false
	 */
	public function set_cashback_setting( $cashback_setting, $item ) {

		if( false === $this->current_user_group ) :
        	$this->current_user_group = $user_group_data = sejowoo_get_current_user_group_data();
		else :
			$user_group_data = $this->current_user_group;
		endif;

		$product = ( is_a( $item, 'WC_Order_Item_Product') ) ? $item->get_product() : $item['data'];

		if( false !== $user_group_data && false !== $user_group_data->cashback['enabled'] || false !== $user_group_data && false !== $user_group_data->per_product[ $product->get_id() ]['cashback']['enabled'] ) :

			if(
				array_key_exists( $product->get_id(), $user_group_data->per_product ) &&
				false !== $user_group_data->per_product[ $product->get_id() ]['cashback']['enabled']
			) :

				$cashback_setting         = $user_group_data->per_product[$product->get_id()]['cashback'];
				$cashback_setting['from'] = 'user-group-per-product';

			elseif(
				false !== $user_group_data &&
				property_exists($user_group_data, 'cashback')
			) :

				$cashback_setting         = $user_group_data->cashback;
				$cashback_setting['from'] = 'user-group';

			endif;

		endif;

		return $cashback_setting;
	}

	/**
	 * Set user group dropdown options
	 * @since 	1.1.2.3
	 * @return 	array
	 */
	public function set_options() {

		if(false === $this->dropdown_options) :
			$this->dropdown_options = sejowoo_get_product_options();
		endif;

		return $this->dropdown_options;

	}

	/**
	 * Setup per product
	 * @since 	1.3.3
	 * @return 	return
	 */
	protected function setup_per_product() {

		$fields = array(

			Field::make( 'select',	'product', __('Produk', 'sejowoo'))
				->set_options( array($this, 'set_options')),

			Field::make('separator', 'sep_cashback', __('Pengaturan Cashback', 'sejowoo'))
				->set_classes('sejowoo-with-help'),

			Field::make( 'checkbox', 'cashback_enable', __('Aktifkan cashback', 'sejowoo'))
				->set_default_value(false),

			Field::make( 'text', 'cashback_value', __('Nilai cashback', 'sejowoo'))
				->set_width(50)
				->set_attribute('type', 'number')
				->set_required(true)
				->set_conditional_logic(array(
					array(
						'field'	=> 'cashback_enable',
						'value'	=> true
					)
				)),

			Field::make( 'select', 'cashback_type', __('Tipe cashback', 'sejowoo'))
				->set_options(array(
					'fixed'			=> __('Tetap', 'sejowoo'),
					'percentage'	=> __('Persentase', 'sejowoo')
				))
				->set_conditional_logic(array(
					array(
						'field'	=> 'cashback_enable',
						'value'	=> true
					)
				))
				->set_width(50),

			Field::make( 'checkbox', 'cashback_refundable', __('Cashback bisa dicairkan', 'sejowoo'))
				->set_conditional_logic(array(
					array(
						'field'	=> 'cashback_enable',
						'value'	=> true
					)
				)),

			Field::make('separator', 'sep_discount', __('Pengaturan Diskon', 'sejowoo'))
				->set_classes('sejowoo-with-help'),

			Field::make( 'checkbox', 'discount_enable', __('Aktifkan diskon harga', 'sejowoo'))
				->set_default_value(false)
				->set_conditional_logic(array(
					array(
						'field'   => 'product',
						'value'   => '',
						'compare' => '!='
					)
				)),

			Field::make('text', 'discount_price', __('Diskon harga (Rp.)', 'sejowoo'))
				->set_attribute('type', 'number')
				->set_required(true)
				->set_conditional_logic(array(
					array(
						'field'	=> 'discount_enable',
						'value'	=> true
					),array(
						'field'   => 'product',
						'value'   => '',
						'compare' => '!='
					)
				))
				->set_width(50),


			Field::make('select', 'discount_price_type', __('Tipe diskon', 'sejowoo'))
				->set_options(array(
					'fixed'			=> __('Tetap', 'sejowoo'),
					'percentage'	=> __('Persentase', 'sejowoo')
				))
				->set_width(50)
				->set_conditional_logic(array(
					array(
						'field'	=> 'discount_enable',
						'value'	=> true
					),array(
						'field'   => 'product',
						'value'   => '',
						'compare' => '!='
					)
				)),

			Field::make('separator', 'sep_commission', __('Pengaturan Komisi', 'sejowoo'))
				->set_classes('sejowoo-with-help'),

			Field::make('complex', 'commission', __('Komisi','sejowoo'))
				->add_fields(
					apply_filters('sejowoo/commission/fields', array())
				)
				->set_layout('tabbed-vertical')
				->set_header_template(__('Tier','sejowoo').' <%- $_index+1 %>'),
		);

		return apply_filters('sejowoo/user-group/per-product/fields', $fields);
	}

	/**
	 * Get user group options, return as array
	 * @since 	1.0.0
	 * @return 	array
	 */
	public function set_user_group_options() {

		global $post;

		$options = array();

		if( true === $this->enable_empty_option ) :
			$options[0] = __('Tanpa group', 'sejowoo');
		endif;

		$args = array(
			'post_type' => SEJOWOO_USER_GROUP_CPT,
			'order'     => 'ASC',
			'orderby'   => 'title'
		);

		// remove current user group from dropdown options
		if( is_a( $post, 'WP_Post') && 'publish' === $post->post_status ) :
			$args['exclude']	= array( $post->ID );
		endif;

		$user_groups = \SejoWoo\Database\Post::set_args($args)
						->set_total(50)
						->get();

		foreach( $user_groups as $group ) :

			$options[$group->ID]	= sprintf( __('Group %s (%s)', 'sejowoo'), $group->post_title, $group->ID);

		endforeach;


		return $options;

	}

	/**
	 * Modify group column data
	 * Hooked via filter manage_sejowoo-user-group_posts_columns, priority 1
	 * @since 	1.0.0
	 * @since 	1.2.0	Add ID columm
	 * @param  	array  	$columns
	 * @return 	array
	 */
	public function modify_group_columns(array $columns) {

		$columns = array(
			'sejowoo-group-priority' => __('Level', 'sejowoo'),
			'sejowoo-ID'             => __('ID', 'sejowoo'),
			'title'                  => __('Nama Group', 'sejowoo'),
			'sejowoo-group-rule'     => __('Pengaturan', 'sejowoo')
		);

		return $columns;
	}

	/**
	 * Sort group data by priority
	 * Hooked via action pre_get_posts, priority 1
	 * @since 	1.0.0
	 * @param  	WP_Query	$query
	 * @return	void
	 */
	public function sort_group_by_priority($query) {

		if(
			is_admin() &&
			isset($_GET['post_type']) && 'sejowoo-user-group' === $_GET['post_type']
		) :

			$query->set('meta_key', '_priority');
			$query->set('orderby', 'meta_value');
			$query->set('order', 'ASC');

		endif;
	}

	/**
	 * Display custom
	 * @param  [type] $column  [description]
	 * @param  [type] $post_id [description]
	 * @return [type]          [description]
	 */
	public function display_custom_data_in_table($column, $post_id) {

		switch($column) :

			case 'sejowoo-ID' :
				echo $post_id;
				break;

			case 'sejowoo-group-priority' :
				echo carbon_get_post_meta($post_id, 'priority');
				break;

			case 'sejowoo-group-rule' :

				$info = [];
				$group_detail = sejowoo_get_group_detail($post_id);

				if(false !== $group_detail['affiliate']) :
					$info[] = __('Akses sebagai affiliate', 'sejowoo');
				endif;

				if(false !== $group_detail['enable_discount']) :
					$info[] = __('Diskon ke semua produk', 'sejowoo');
				endif;

				if(is_array($group_detail['commissions']) && 0 < count($group_detail['commissions']) ) :
					$info[] = __('Komisi ke semua produk', 'sejowoo');
				endif;

				if(
					isset($group_detail['upgrade']['enable']) &&
					true === $group_detail['upgrade']['enable']
				) :
					$info[] = __('Upgrade user group');
				endif;

				echo implode('<br />', $info);

				break;

		endswitch;

	}

	/**
	 * Get product setting field
	 * @since 	1.0.0
	 * @param  	array  $fields
	 * @return 	array
	 */
	protected function get_product_setting_fields() {

		$fields = array(

			Field::make( 'separator', 'sep_group_product_price', __('Pengaturan Semua Produk', 'sejowoo'))
				->set_classes('sejowoo-with-help'),
				// ->set_help_text('<a href="#" class="thickbox sejowoo-help">Tutorial <span class="dashicons dashicons-video-alt2"></span></a>'),

			Field::make('html',	'sep_group_general_info')
				->set_html(
					'<div class="sejoli-html-message info"><p>'.
					__('Pengaturan ini akan berlaku di semua produk', 'sejowoo').
					'</p></div>'
				),

			/**
			 * ===============================
			 * Cashback setup
			 * ===============================
			 */
			Field::make('separator', 'sep_cashback', __('Pengaturan Cashback', 'sejowoo'))
				->set_classes('sejowoo-with-help'),

			Field::make( 'checkbox', 'group_cashback_enable', __('Aktifkan cashback', 'sejowoo'))
				->set_default_value(false),

			Field::make( 'text', 'group_cashback_value', __('Nilai cashback', 'sejowoo'))
				->set_width(50)
				->set_attribute('type', 'number')
				->set_required(true)
				->set_conditional_logic(array(
					array(
						'field'	=> 'group_cashback_enable',
						'value'	=> true
					)
				)),

			Field::make( 'select', 'group_cashback_type', __('Tipe cashback', 'sejowoo'))
				->set_options(array(
					'fixed'			=> __('Tetap', 'sejowoo'),
					'percentage'	=> __('Persentase', 'sejowoo')
				))
				->set_conditional_logic(array(
					array(
						'field'	=> 'group_cashback_enable',
						'value'	=> true
					)
				))
				->set_width(50),

			Field::make( 'checkbox', 'group_cashback_refundable', __('Cashback bisa dicairkan', 'sejowoo'))
				->set_conditional_logic(array(
					array(
						'field'	=> 'group_cashback_enable',
						'value'	=> true
					)
				)),

			/**
			 * ===============================
			 * Discount setup
			 * ===============================
			 */
			Field::make('separator', 'sep_discount', __('Pengaturan Diskon', 'sejowoo'))
				->set_classes('sejowoo-with-help'),

			Field::make( 'checkbox', 'group_discount_enable', __('Aktifkan diskon harga', 'sejowoo'))
				->set_default_value(false),

			Field::make('text', 'group_discount_price', __('Diskon harga (Rp.)', 'sejowoo'))
				->set_attribute('type', 'number')
				->set_required(true)
				->set_conditional_logic(array(
					array(
						'field'	=> 'group_discount_enable',
						'value'	=> true
					)
				))
				->set_width(50),


			Field::make('select', 'group_discount_price_type', __('Tipe diskon', 'sejowoo'))
				->set_options(array(
					'fixed'			=> __('Tetap', 'sejowoo'),
					'percentage'	=> __('Persentase', 'sejowoo')
				))
				->set_width(50)
				->set_conditional_logic(array(
					array(
						'field'	=> 'group_discount_enable',
						'value'	=> true
					)
				)),

			/**
			 * ===============================
			 * Comission setup
			 * ===============================
			 */
			Field::make('separator', 'sep_commission', __('Pengaturan Komisi', 'sejowoo'))
				->set_classes('sejowoo-with-help'),

			Field::make('html', 'group_commission_info')
				->set_html(
					'<div class="sejoli-html-message warning"><p>' .
					__('PASTIKAN anda sudah mengatur commission type TIAP produk sebelum mengatur komisi berdasarkan group', 'sejowoo') .
					'</p></div>'
				),

			Field::make('complex', 'group_commissions',__('Komisi','sejowoo'))
				->add_fields(
					apply_filters('sejowoo/commission/fields', array())
				)
				->set_layout('tabbed-vertical')
				->set_header_template(__('Tier','sejowoo').' <%- $_index+1 %>'),

			/**
			 * ===============================
			 * Per Product setup
			 * ===============================
			 */
			Field::make( 'separator', 'sep_group_product_setup', __('Pengaturan Per Produk', 'sejowoo'))
				->set_classes('sejowoo-with-help'),

			Field::make('html',	'sep_group_product_setup_info')
				->set_html(
					'<div class="sejowoo-html-message info"><p>'.
					__('Jika pengguna membeli produk yang sesuai dengan pengaturan per produk, maka aturan diskon dan komisi yang digunakan adalah yang tertera di pengaturan tersebut', 'sejowoo').
					'</p></div>'
				),

			Field::make('complex', 'group_setup_per_product', __('Pengaturan per produk', 'sejowoo'))

				->add_fields(
					$this->setup_per_product()
				)
				->set_layout('tabbed-vertical')
				->set_header_template('<% if (product) { %>
					<%- product %>
				  <% } %>')
		);

		return $fields;
	}

	/**
	 * Add user setting to general theme options
	 * Hooked via filter sejowoo/general/fields, priority 70
	 * @since 	1.0.2
	 * @param  	array $fields
	 * @return 	array
	 */
	public function setup_setting_fields( $fields ) {

		$this->enable_empty_option = true;

		$fields['user'] = array(

			'title'		=> __('User', 'sejowoo'),
			'fields'	=> array(
				// Commission Setting
				Field::make('separator', 'sep_sejowoo_user_group', __('Pengaturan User Group', 'sejowoo'))
					->set_classes('sejoli-with-help'),

				Field::make('checkbox', 'sejowoo_enable_set_user_group_after_registration', __('Set default user group', 'sejowoo'))
					->set_help_text( __('Setelah user melakukan pendaftaran atau melakukan pembelian pertama kali dalam keadaan tidak login, dengan mengaktifkan fitur ini maka status group user akan ditentukan sesuai dengan pilihan di bawah', 'sejowoo')),

				Field::make('select', 'sejowoo_default_user_group', __('User group yang ditentukan (Pendaftaran melalui halaman My Account)', 'sejowoo'))
					->set_options( array( $this, 'set_user_group_options' ) )
					->set_conditional_logic(array(
						array(
							'field'	=> 'sejowoo_enable_set_user_group_after_registration',
							'value'	=> true
						)
					)),

				Field::make('select', 'sejowoo_default_user_group_checkout', __('User group yang ditentukan (Pendaftaran melalui halaman Checkout)', 'sejowoo'))
					->set_options( array( $this, 'set_user_group_options' ) )
					->set_conditional_logic(array(
						array(
							'field'	=> 'sejowoo_enable_set_user_group_after_registration',
							'value'	=> true
						)
					)),
			)
		);

		return $fields;
	}

    /**
     * Setup custom fields for user group
     * Hooked via action carbon_fields_register_fields, priority 1010
     * @since 	1.0.0
     * @return 	void
     */
    public function setup_group_fields() {

		if( ! sejowoo_is_woocommerce_active() ) :
			return;
		endif;

        $container = Container::make('post_meta', __('Pengaturan', 'sejowoo'))
            ->where( 'post_type', '=', SEJOWOO_USER_GROUP_CPT)
            ->set_classes('sejowoo-metabox')
			->add_tab( __('Pengaturan', 'sejowoo'), array(

				Field::make( 'separator', 'sep_user_priority_sale', __('Pengaturan', 'sejowoo'))
					->set_classes('sejowoo-with-help'),
					// ->set_help_text('<a href="#" class="thickbox sejowoo-help">Tutorial <span class="dashicons dashicons-video-alt2"></span></a>'),

				Field::make('text',	'priority', __('Prioritas Grup', 'sejowoo'))
					->set_attribute('type', 'number')
					->set_attribute('min', 1)
					->set_default_value(1)
					->set_required(true)
					->set_help_text(
						__('Semakin rendah nilai, semakin tinggi tingkatan grup. 1 tertinggi', 'sejowoo')
					),

				Field::make('separator', 'sep_sejowoo_affiliate_network', __('Jaringan Affiliasi', 'sejowoo')),

				Field::make('text',	'affiliate_network_limit', __('Batasan maksimal tampilan kedalaman jaringan affiliasi', 'sejowoo'))
					->set_attribute( 'type', 'number')
					->set_default_value( 1 )
					->set_help_text( __('Tentukan maksimal kedalaman jaringan affiliasi di menu Jaringan Affiliasi pada halaman member area khusus untuk group ini', 'sejowoo'))
			))

			->add_tab( __('Produk', 'sejowoo'),
				apply_filters('sejowoo/user-group/fields', apply_filters('sejowoo/user-group/product-setting-fields', $this->get_product_setting_fields() ) )
			)

			->add_tab( __('Upgrade', 'sejowoo'), array(
				Field::make( 'separator', 'sep_upgrade_user_group', __('Upgrade User Group', 'sejowoo'))
					->set_classes('sejowoo-with-help'),

				Field::make( 'checkbox', 'enable_user_group_upgrade', __('Aktifkan upgrade user group berdasarkan total belanja', 'sejowoo')),

				Field::make( 'html', 'sep_upgrade_user_group_html')
					->set_html(
						sprintf(
							'<div class="sejoli-html-message info"><p>%s</p></div>',
							__('Bagian ini untuk pengaturan terkait perubahan user group berdasarkan total pembelanjaan sebelum dikurangi diskon dan penambahan ongkos kirim', 'sejowoo')
						)
					)
					->set_conditional_logic(array(
						array(
							'field'	=> 'enable_user_group_upgrade',
							'value'	=> true
						)
					)),

				Field::make( 'text', 'first_purchase_upgrade_min_checkout',
						sprintf(
							__('Minimum pembelanjaan untuk pembelian pertama (%s)', 'sejowoo'),
							get_woocommerce_currency_symbol()
						)
					)
					->set_attribute( 'type', 'number')
					->set_default_value( 0 )
					->set_conditional_logic(array(
						array(
							'field'	=> 'enable_user_group_upgrade',
							'value'	=> true
						)
					)),

				Field::make( 'text', 'next_order_purchase_upgrade_min_checkout',
						sprintf(
							__('Minimum pembelanjaan untuk repeat order (%s)', 'sejowoo'),
							get_woocommerce_currency_symbol()
						)
					)
					->set_attribute( 'type', 'number')
					->set_default_value( 0 )
					->set_conditional_logic(array(
						array(
							'field'	=> 'enable_user_group_upgrade',
							'value'	=> true
						)
					))
					->set_help_text( __('Kondisi ini hanya berlaku jika user belum memiliki user group', 'sejowpp')),

				Field::make( 'complex', 'upgrade_user_group', __('Peraturan Upgrade', 'sejowoo'))

					->add_fields(array(
						Field::make( 'select', 'user_group', __('Kondisi user group yang diizinkan untuk update', 'sejowoo'))
							->set_options( array( $this, 'set_user_group_options')),

						Field::make( 'text', 'min_checkout',
								sprintf(
									__('Minimum pembelanjaan (%s)', 'sejowoo'),
									get_woocommerce_currency_symbol()
								)
							)
							->set_attribute( 'type', 'number')
							->set_default_value( 0 )

					))
					->set_layout( 'tabbed-vertical' )
					->set_header_template( '<% if (user_group) { %> Group #<%- user_group %> <% } %>' )
					->set_conditional_logic(array(
						array(
							'field'	=> 'enable_user_group_upgrade',
							'value'	=> true
						)
					))
			))

			->add_tab(__('Pengaturan Lainnya', 'sejowoo'), array(
				Field::make('checkbox', 'can_view_affiliate', __('Member bisa mengakses menu affiliasi', 'sejowoo'))
			));
    }

	/**
     * Setup custom fields in user page
     * Hooked via filter sejowoo/user/fields, priority 20
     * @since 	1.3.3
     * @return 	void
     */
	public function setup_user_fields($fields) {

		$user_group_options = array(
								'' => __('Tidak masuk ke grup apapun', 'sejowoo')
							  ) + sejowoo_get_user_group_options();

		$fields[]	= array(
			'title'		=> __('Grup', 'sejowoo'),
			'fields'	=> array(
				Field::make('select',	'user_group', __('User Grup', 'sejowoo'))
					->add_options($user_group_options)
			)
		);

		return $fields;

	}

	/**
	 * Set user group transient data
	 * Hooked via action save_post_{SEJOWOO_USER_GROUP_CPT}, priority 1010
	 * @since 	1.0.0
	 * @param 	integer 	$post_id
	 * @param 	WP_Post 	$post
	 */
	public function set_transient_data(int $post_id, \WP_Post $post) {

		if( wp_is_post_revision($post_id) ) :
			return;
		endif;

		if('publish' !== $post->post_status ) :
			return;
		endif;

		$user_groups = get_posts(array(
			'post_type'      => SEJOWOO_USER_GROUP_CPT,
			'posts_per_page' => 99
		));

		$setup 	= array(
			'first'   => array(),
			'upgrade' => array()
		);

		foreach( $user_groups as $group ) :

			$priority 		 = intval( carbon_get_post_meta( $group->ID, 'priority') );
			$enable_cashback = boolval( carbon_get_post_meta( $group->ID, 'enable_cashback_when_upgrade' ) );
			$upgrades        = carbon_get_post_meta( $group->ID, 'upgrade_user_group' );

			$setup['first'][ $group->ID ] = array(
				'priority'	=> $priority,
				'cashback'	=> $enable_cashback,
				'value'		=> floatval( carbon_get_post_meta( $group->ID, 'first_purchase_upgrade_min_checkout' ) )
			);


			$setup['upgrade'][ $group->ID ] = array();

			foreach( $upgrades as $_upgrade ) :

				$setup['upgrade'][ $group->ID ][ $_upgrade['user_group'] ] = array(
					'value'	=> floatval( $_upgrade['min_checkout' ])
				);

			endforeach;

		endforeach;

		set_transient( $this->transient_key['upgrade'], $setup );

	}

	/**
	 * Add custom columns to user table
	 * Hooked via filter manage_user_columns, priority 10
	 * @since 	1.0.0
	 * @param  	array  $columns Current user columns
	 * @return 	array
	 */
	public function modify_user_table(array $columns) {

		unset($columns['posts']);

		$columns['sejowoo-user-group']	= __('Grup', 'sejowoo');

		return $columns;
	}

	/**
	 * Display custom column value
	 * Hooked via filter manage_users_custom_column, priority 20
	 * @since 	1.0.0
	 * @param 	string 	$value
	 * @param  	string 	$column_name
	 * @param  	integer $user_id
	 * @return 	string
	 */
	public function display_value_for_user_table($value, $column_name, $user_id) {

		if('sejowoo-user-group' === $column_name) :

			$user_groups   = sejowoo_get_user_group_options();
			$user_group_id = carbon_get_user_meta($user_id, 'user_group');

			return ( array_key_exists($user_group_id, $user_groups) ) ? $user_groups[$user_group_id] : '-';

		endif;

		return $value;
	}

	/**
	 * Set user meta
	 * Hooked via filter sejowoo/user/meta-data, priority 1001
	 * @since 	1.0.0
	 * @param 	WP_User $user
	 * @return 	WP_User
	 */
	public function set_user_meta($user) {

		$user_groups          = sejowoo_get_user_group_options();
		$user_group_id        = intval(carbon_get_user_meta($user->ID, 'user_group'));

		$user->meta->group    = ( array_key_exists($user_group_id, $user_groups) ) ? $user_groups[$user_group_id] : NULL;
		$user->meta->group_id = $user_group_id;

		return $user;
	}

	/**
	 * Set local JS variables
	 * Hooked via filter sejowoo/admin/js-localize-data, priority 1
	 * @since 	1.0.0
	 * @param 	array $js_vars
	 * @return 	array
	 */
	public function set_localize_js_var($js_vars) {

		$js_vars['userlist']	= array(
			'table' => array(
				'ajaxurl' => add_query_arg(array(
					'action' => 'sejowoo-user-table'
				), admin_url('admin-ajax.php')),
				'nonce' => wp_create_nonce('sejowoo-render-user-table')
			),
			'update' => array(
				'ajaxurl'	=> add_query_arg(array(
					'action' => 'sejowoo-user-update'
				), admin_url('admin-ajax.php')),
				'nonce'	=> wp_create_nonce('sejowoo-user-update')
			),
			'export_prepare'   =>  [
				'ajaxurl' => add_query_arg([
					'action' => 'sejowoo-user-export-prepare'
				], admin_url('admin-ajax.php')),
				'nonce' => wp_create_nonce('sejowoo-user-export-prepare')
			],
		);

		return $js_vars;
	}

	/**
     * Get all user role name
     * Hooked via filter sejowoo/filter/roles, priority 1
     * @since   1.0.0
     * @param   array  	$role_names
     * @param 	array 	$roles
     * @return  array
     */
    public function set_role_names(array $role_names, array $roles) {

        $user_roles = array();

		if(!is_array($this->available_roles)) :
			global $wp_roles;

			$this->available_roles = $wp_roles;
		endif;

        foreach($roles as $role) :

            if(array_key_exists($role, $this->available_roles->roles)) :
                $user_roles[]['name'] = $this->available_roles->roles[$role]['name'];
            endif;

        endforeach;

        return $user_roles;
    }

	/**
	 * Export order data to CSV
	 * Hooked via action sejowoo_ajax_sejowoo-order-export, priority 1
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function export_csv() {

		$post_data = wp_parse_args($_GET,[
			'sejowoo-nonce' => NULL,
			'backend'      => false,
			'affiliate_id' => NULL,
			'user_id'      => NULL,
			'role'         => NULL,
			'group'        => NULL,
			'ID'           => NULL
		]);

		if(wp_verify_nonce($post_data['sejowoo-nonce'], 'sejowoo-user-export')) :

			$filename   = array();
			$filename[] = 'export-users';

			if(!current_user_can('manage_sejowoo_orders') || false === $post_data['backend']) :
				$post_data['affiliate_id']	= get_current_user_id();
			endif;

			if(isset($post_data['affiliate_id'])) :
				$filename[] = 'affiliate-' . $post_data['affiliate_id'];
			endif;

			unset($post_data['backend'], $post_data['sejowoo-nonce']);

			$args 	= array(
				'number'  => -1,
				'orderby' => 'display_name',
				'order'   => 'ASC'
			);

			if(!empty($post_data['role'])) :
	            $args['role'] = (array) $post_data['role'];
	        endif;

	        if(!empty($post_data['ID'])) :
	            $args['include'] = explode(',', $post_data['ID']);
	        endif;

			if(!empty($post_data['user_id'])) :
				if(!array_key_exists('include', $args)) :
					$args['include']	= array();
				endif;

				$args['include'][] = $post_data['user_id'];
			endif;

	        if(!empty($post_data['group'])) :

	            $meta_query[] = array(
	                'key'   => '_user_group',
	                'value' => $post_data['group']
	            );

				$filename[] = 'group-' . $post_data['group'];

	        endif;

	        if(!empty($post_data['affiliate_id'])) :

	            $meta_query[] = array(
	                'key'   => '_affiliate_id',
	                'value' => $post_data['affiliate_id']
	            );

	        endif;

	        if(0 < count($meta_query)) :
	            $args['meta_query']  = $meta_query;
	        endif;

			$csv_data = [];
			$csv_data[0]	= array(
				'User ID', 'name', 'email', 'phone', 'address', 'affiliate', 'group'
			);

			$i = 1;
			foreach(get_users($args) as $user) :

	            $user      = apply_filters('sejowoo/user/meta-data', $user);
	            $affiliate = sejowoo_get_affiliate($user, 'wp_user');

	            $csv_data[$i] = array(
	                'ID'        => $user->ID,
	                'name'      => $user->display_name,
	                'email'     => $user->user_email,
					'phone'     => $user->meta->phone,
					'address'	=> $user->meta->address,
	                'affiliate' => (is_a($affiliate, 'WP_User')) ? $affiliate->display_name : '-',
	                'group'     => ( NULL === $user->meta->group ) ? '-' : $user->meta->group
	            );

	            $i++;

			endforeach;

			header('Content-Type: text/csv');
			header('Content-Disposition: attachment; filename="' . implode('-', $filename) . '.csv"');

			$fp = fopen('php://output', 'wb');
			foreach ($csv_data as $line) :
			    fputcsv($fp, $line, ',');
			endforeach;
			fclose($fp);

		endif;
		exit;
	}

	/**
	 * Add submenu 'Sejowoo User' under User menu
	 * Hooked via action admin_menu, priority 100
	 * @since 1.0.0
	 */
	public function add_custom_user_menu() {

		add_submenu_page(
			'edit.php?post_type=' . SEJOWOO_USER_GROUP_CPT,
			__('Sejowoo User - Manajemen', 'sejowoo'),
			__('Manajemen User', 'sejowoo'),
			'promote_users',
			'sejowoo-user-management',
			array($this, 'display_user_list')
		);

	}

	/**
	 * Enqueue needed CSS and JS files
	 * Hooked via action admin_enqueue_scripts, priority 100
	 * @return 	void
	 */
	public function register_css_and_js() {
		wp_enqueue_style($this->plugin_name . '-post-table', 	SEJOWOO_URL . 'admin/css/post-table.css', [], $this->version, 'all');

		wp_enqueue_script($this->plugin_name . 'post-edit', 	SEJOWOO_URL . 'admin/js/sejowoo-post-edit.js', ['jquery'], $this->version, true );
	}

	/**
	 * Set $is_sejowoo_page true if current page is a sejowoo user management
	 * Hooked via filter sejowoo/admin/is-sejowoo-page, priority 100
	 * @since 	1.0.0
	 * @param  	boolean $is_page
	 * @return	boolean
	 */
	public function is_sejowoo_page($is_page) {

		global $pagenow;

		if('edit.php' === $pagenow && isset($_GET['page']) && 'sejowoo-user-management' === $_GET['page']) :
			return true;
		endif;

		return $is_page;
	}

	/**
	 * Display list user
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function display_user_list() {
		require plugin_dir_path( __FILE__ ) . 'partials/user/page.php';
	}

	/**
	 * Add group tab to product data tabs
	 * Hooked via filter woocommerce_product_data_tabs, priority 10
	 * @since 	0.1.0
	 * @param  array $product_data_tabs
	 * @return 	void
	 */
	public function setup_group_product_data_tab( $product_data_tabs  ) {

		// Adds the new tab

		$product_data_tabs ['user-group-tab'] = array(
			'label' 	=> __( 'User Group', 'woocommerce' ),
			'target' 	=> 'user_group_product_data',
			'priority' 	=> 50,
			'class'		=> array( "hide_if_variable" ),
		);

		return $product_data_tabs ;

	}

	/**
	 * Add user group fields to product fields
	 * @since 	1.6.0
	 * @param 	integer  	$product_id
	 * @param 	boolean 	$is_variation
	 * @param 	integer 	$index 			Only use for variation
	 * @return 	void
	 */
	protected function add_product_fields( int $product_id, $is_variation = false, $index = 0 ) {
		?>
		<div id='user_group_product_data' class='panel woocommerce_options_panel'>
			<div class='options_group'>
				<h4 style="padding:0 1em">
					<?php _e("Pengaturan Pembelian", "sejowoo"); ?>
				</h4>
				<?php

				$user_group_options 	= sejowoo_get_user_group_options();
				$user_group_buy_list	= $user_group_options;
				$user_group_buy_list['0'] = 'User yang belum login';

				woocommerce_wp_checkbox( array(
					'id'          => '_user_group_buy_permission' . (( $is_variation ) ? '-' . $index : ''),
					'name'        => '_user_group_buy_permission' . (( $is_variation ) ? '[' . $index . ']' : ''),
					'label'       => __('Restriksi pembelian', 'sejowoo'),
					'description' => __( 'Hanya grup user tertentu yang membeli produk ini', 'sejowoo' ),
					'value'       => get_post_meta( $product_id, "_user_group_buy_permission", true)
				) );

				woocommerce_wp_select( array(
					'id'				=> '_user_group_buy_list' . (( $is_variation ) ? '-' . $index : ''),
					'label'				=>  __('Pilih grup', 'sejowoo'),
					'name'				=> '_user_group_buy_list' .(( $is_variation ) ? '[' . $index . ']' : ''). '[]',
					'desc_tip'			=> 'true',
					'description'		=> __( 'Pilih grup yang boleh membeli produk ini.', 'sejowoo' ),
					'options'			=> $user_group_buy_list,
					'value'				=> get_post_meta( $product_id, "_user_group_buy_list", true),
					'custom_attributes'	=> array(
						'multiple'	=> 'true',
					),
				) );

				woocommerce_wp_textarea_input( array(
					'id'    => '_user_group_buy_restricted_message' . (( $is_variation ) ? '-' . $index : ''),
					'label' => __('Pesan untuk user yang tidak diberikan akses membeli produk ini', 'sejowoo'),
					'name'  => '_user_group_buy_restricted_message' . (( $is_variation ) ? '[' . $index . ']' : ''),
					'value' => get_post_meta( $product_id, "_user_group_buy_restricted_message", true)
				) );
				?>
			</div>
			<div class='options_group'>
				<h4 style="padding:0 1em">
					<?php _e("Pengaturan Update Group", "sejowoo"); ?>
				</h4>
				<?php

				woocommerce_wp_checkbox( array(
					'id'            => '_user_group_update_check' . (( $is_variation ) ? '-' . $index : ''),
					'name'          => '_user_group_update_check' . (( $is_variation ) ? '[' . $index . ']' : ''),
					'label'         => __('Ubah User Group', 'sejowoo'),
					'description'   => __( 'Ubah grup user yang telah membeli produk ini', 'sejowoo' ),
					'value'         => get_post_meta( $product_id, "_user_group_update_check", true),
					'wrapper_class' => 'form-row form-row-full',
				) );

				woocommerce_wp_select( array(
					'id'      => '_user_group_update' . (( $is_variation ) ? '-' . $index : ''),
					'name'    => '_user_group_update' . (( $is_variation ) ? '[' . $index . ']' : ''),
					'label'   => __('Ubah ke grup', 'sejowoo'),
					'options' => $user_group_options,
					'value'   => get_post_meta( $product_id, "_user_group_update", true),
				) );

				woocommerce_wp_checkbox( array(
					'id'          => '_user_group_update_condition' . (( $is_variation ) ? '-' . $index : ''),
					'name'        => '_user_group_update_condition' . (( $is_variation ) ? '[' . $index . ']' : ''),
					'label'       => __('Kondisi perubahan', 'sejowoo'),
					'description' => __( 'Ubah grup user dengan kondisi tertentu', 'sejowoo' ),
					'value'       => get_post_meta( $product_id, "_user_group_update_condition", true),
				) );

				woocommerce_wp_select( array(
					'id'                => '_user_group_update_list' . (( $is_variation ) ? '-' . $index : ''),
					'label'             => __('Ubah grup jika user termasuk dalam grup ini', 'sejowoo'),
					'name'              => '_user_group_update_list' .(( $is_variation ) ? '[' . $index . ']' : ''). '[]',
					'desc_tip'          => 'true',
					'description'       => __( 'Pilih grup yang akan diubah ketika membeli produk ini.', 'sejowoo' ),
					'options'           => $user_group_options,
					'value'             => get_post_meta( $product_id, "_user_group_update_list", true),
					'custom_attributes' => array(
						'multiple'	=> 'true',
					),
				) );

				?>

			</div>

		</div><?php
	}

	/**
	 * Add custom product data fields
	 * Hooked via action woocommerce_product_data_panels, priority 10
	 * @since 	0.1.0
	 * @return 	void
	 */
	public function user_group_product_data() {
		global $post;

		$this->add_product_fields( $post->ID, false );

	}

	/**
	 * Add custom product data fields in variation
	 * Hooked via action woocommerce_product_after_variable_attributes, priority 10
	 * @since 	1.6.0
	 * @param  [type] $loop           [description]
	 * @param  [type] $variation_data [description]
	 * @param  [type] $variation      [description]
	 * @return [type]                 [description]
	 */
	public function user_group_product_data_in_variation( $loop, $variation_data, $variation ) {
		$this->add_product_fields( $variation->ID, true, $loop);
	}

	/**
	 * Save custom product data
	 * Hooked via action woocommerce_process_product_meta, priority 10
	 * @since 	0.1.0
	 * @return 	void
	 */
	public function save_group_data_product_option_fields( $post_id ) {

		$buy_permission = isset( $_POST['_user_group_buy_permission'] ) ? 'yes' : 'no';
		update_post_meta( $post_id, '_user_group_buy_permission', $buy_permission );

		update_post_meta( $post_id, '_user_group_buy_list', $_POST['_user_group_buy_list'] );

		if ( isset( $_POST['_user_group_buy_restricted_message'] ) ) :
			update_post_meta( $post_id, '_user_group_buy_restricted_message', $_POST['_user_group_buy_restricted_message'] );
		endif;

		$update_check = isset( $_POST['_user_group_update_check'] ) ? 'yes' : 'no';
		update_post_meta( $post_id, '_user_group_update_check', $update_check );

		if ( isset( $_POST['_user_group_update'] ) ) :
			update_post_meta( $post_id, '_user_group_update', $_POST['_user_group_update'] );
		endif;

		$update_condition = isset( $_POST['_user_group_update_condition'] ) ? 'yes' : 'no';
		update_post_meta( $post_id, '_user_group_update_condition', $update_condition );

		update_post_meta( $post_id, '_user_group_update_list', $_POST['_user_group_update_list'] );

	}

	/**
	 * Save custom product variation data
	 * Hooked via action woocommerce_save_product_variation, priority 10
	 * @since 	1.6.0
	 * @param 	integer 	$variation_id
	 * @param 	integer 	$index
	 * @return 	void
	 */
	public function save_group_data_product_option_fields_in_variation( $variation_id, $index ) {

		$buy_permission = isset( $_POST['_user_group_buy_permission'][$index] ) ? 'yes' : 'no';
		update_post_meta( $variation_id, '_user_group_buy_permission', $buy_permission );

			update_post_meta( $variation_id, '_user_group_buy_list', $_POST['_user_group_buy_list'][$index] );

		if ( isset( $_POST['_user_group_buy_restricted_message'][$index] ) ) :
			update_post_meta( $variation_id, '_user_group_buy_restricted_message', $_POST['_user_group_buy_restricted_message'][$index] );
		endif;

		$update_check = isset( $_POST['_user_group_update_check'][$index] ) ? 'yes' : 'no';
		update_post_meta( $variation_id, '_user_group_update_check', $update_check );

		if ( isset( $_POST['_user_group_update'][$index] ) ) :
			update_post_meta( $variation_id, '_user_group_update', $_POST['_user_group_update'][$index] );
		endif;

		$update_condition = isset( $_POST['_user_group_update_condition'][$index] ) ? 'yes' : 'no';
		update_post_meta( $variation_id, '_user_group_update_condition', $update_condition );

		update_post_meta( $variation_id, '_user_group_update_list', $_POST['_user_group_update_list'][$index] );

	}

	/**
	* Set group metadata to product
	* Hooked via filter sejowoo/product/meta, priority 50
	* @since 	1.0.0
	* @param  	WP_Post $product
	* @param  	int     $product_id
	* @return 	WP_Post
	*/
	public function setup_group_product_meta(\WP_Post $product, $product_id) {

		$product->group = array(
			'buy_group'              => ( get_post_meta($product_id, '_user_group_buy_permission', true) == 'yes' ) ? true : false,
			'buy_group_list'         => get_post_meta($product_id, '_user_group_buy_list', true),
			'buy_restricted_message' => get_post_meta($product_id, '_user_group_buy_restricted_message', true),
			'update_group'           => ( get_post_meta($product_id, '_user_group_update_check', true) == 'yes' ) ? true : false,
			'update_group_to'        => intval(get_post_meta($product_id, '_user_group_update', true)),
			'update_group_condition' => ( get_post_meta($product_id, '_user_group_update_condition', true) == 'yes' ) ? true : false,
			'update_group_list'      => get_post_meta($product_id, '_user_group_update_list', true),
		);

		return $product;
	}

	/**
	* Set discount based on current user group
	* Hooked via filter sejowoo/product/price, priority 100
	* @since   1.0.0
	* @param   float   $price
	* @param   WP_Post $product
	* @return  float
	*/
	public function set_discount_product_price( $price = 0.0, \WP_Post $product) {

		$donation_active     = boolval( carbon_get_post_meta($product->ID, 'donation_active') );

		if(is_user_logged_in() && false === $donation_active) :

			$user_id       = get_current_user_id();
			$user_group_id = intval(carbon_get_user_meta($user_id, 'user_group'));

			if(0 < $user_group_id) :

				$group_detail     = sejowoo_get_group_detail($user_group_id);
				$discounted_price = $discount     = 0;
				$type             = 'fixed';

				if(
					is_array($group_detail['per_product']) &&
					array_key_exists($product->ID, $group_detail['per_product'])
				) :

					$group_setup = $group_detail['per_product'][$product->ID];

				else :
					$group_setup = $group_detail;
				endif;

				if(false !== $group_setup['enable_discount']) :

					$discount = $group_setup['discount_price'];
					$type 	  = $group_setup['discount_price_type'];

				endif;

				if(0 < $discount) :

					if('percentage' === $type) :
						$discounted_price = $price - ( $price * $discount / 100 );
					elseif('fixed' === $type) :
						$discounted_price = $price - $discount;
					endif;

					$price = (0 > $discounted_price) ? 0 : $discounted_price;

				endif;

			endif;

		endif;

 	   	return $price;
    }

	/**
	 * Calculate commission based on user group setting
	 * Hooked via filter sejowoo/commission/value, priority 100
	 * @since 	1.0.0
	 * @param 	float      				$commission
	 * @param 	WC_Order_Item_Product	$item
	 * @param 	integer     			$user_id
	 * @param 	integer     			$tier
	 * @return 	float
	 */
	public function set_commission_value( $commission = 0.0, \WC_Order_Item_Product $item , int $user_id, int $tier ) {

		$user_group_id = carbon_get_user_meta($user_id, 'user_group');

		$logger = wc_get_logger();

		if(0 < $user_group_id) :

			// Prevent multiple get same group data
			if( !array_key_exists( $user_group_id, $this->current_user_groups ) ) :
				$group_detail = $this->current_user_groups[$user_group_id] = sejowoo_get_group_detail($user_group_id);
			else :
				$group_detail = $this->current_user_groups[$user_group_id];
			endif;

			$product_id      = $item->get_product()->get_id();
			$commission_data = array();

			// Check group commission set
			if(
				is_array($group_detail['per_product']) &&
				array_key_exists($product_id, $group_detail['per_product'])
			) :

				$commission_data = $group_detail['per_product'][$product_id]['commissions'];
				$based_on = 'user-group-per-product';
			else :
				$based_on = 'user-group-general';
				$commission_data = $group_detail['commissions'];
			endif;

			// Calculate commission by affiliate tier
			if(array_key_exists($tier, $commission_data)) :

				$commission_set = $commission_data[$tier];

				if('percentage' === $commission_set['type']) :

					$commission  = floatval( $item->get_total() * $commission_set['fee'] / 100 );

				elseif('fixed' === $commission_set['type']) :

					$commission = floatval($commission_set['fee']) * $item->get_quantity();

				endif;

				$logger->info(
					sprintf(
						__('Calculate commission based on %s, group ID %s, for user %s, tier %s, product %s, commission %s', 'sejowoo'),
						$based_on,
						$user_group_id,
						$user_id,
						$tier,
						$item->get_product()->get_name(),
						$commission
					),
					array(
						'source' => 'sejowoo-commission'
					)
				);

			else :

				$logger->info(
					__('Not calculated user by user group'),
					array(
						'source' => 'sejowoo-commission'
					)
				);

			endif;

		else :

		endif;

		return $commission;
	}

	/**
	 * Update user group when an order completed based on total_oprder
	 * Hooked via action woocommerce_order_status_completed, priority 90
	 * @since 	1.0.0
	 * @since 	1.2.0 	Add detail information to show what cause
	 * @param  	int 	$order_id
	 * @return 	void
	 */
	public function update_user_group_by_total_order(int $order_id) {

		$order = wc_get_order( $order_id );

		if( is_a($order, 'WC_Order') ) :

			$total_paid      = $order->get_subtotal();
			$count_order     = wc_get_customer_order_count( $order->get_user_id() );
			$user_group_id   = (int) sejowoo_get_current_user_group( $order->get_user_id() );

			$is_first_buy    = ( 1 >= $count_order ) ? true : false;
            $response 	     = sejowoo_check_update_user_group_by_order_total(
                                intval($user_group_id),
                                $total_paid,
                                $is_first_buy
							);

			if( $response && array_key_exists('group_id', $response)) :

				$logger = wc_get_logger();

				update_user_meta(
					$order->get_user_id(),
					'_user_group',
					$response['group_id']
				);

				$logger->info(
					sprintf(
						__('User %s group updated to %s based on total order %s with minumum order %s', 'sejowoo'),
						$order->get_user_id(),
						$response['group_id'],
						$total_paid,
						$response['value']
					),

					$this->log
				);

			endif;

		endif;

	}

	/**
	 * Update user group when an order completed based on product bought
	 * Hooked via action woocommerce_order_status_completed, priority 100
	 * @since 	1.0.0
	 * @since 	1.2.0 	Add detail information to show what cause
	 * @param  	int 	$order_id
	 * @return 	void
	 */
	public function update_user_group_by_product(int $order_id) {

		$order = wc_get_order( $order_id );

		if( is_a($order, 'WC_Order') ) :

			$logger = wc_get_logger();

			foreach ( $order->get_items() as $item_id => $item ) :

				$response   = sejowoo_check_update_user_group_by_product(
								$item->get_product_id(),
								$order->get_user_id()
							  );

				if(false !== $response['update'] && !empty($response['group'])) :

					update_user_meta(
						$order->get_user_id(),
						'_user_group',
						$response['group']
					);

					$logger->info(
						sprintf(
							__('User %s group updated to %s based on product %s', 'sejowoo'),
							$order->get_user_id(),
							$item->get_product()->get_name(),
							$response['group']
						),
						$this->log
					);


				else :

					$logger->info(
						implode('. ', $response['error']['message']),
						$this->log
					);

				endif;

			endforeach;

		endif;
	}

	/**
	 * Check user group with product
	 * Hooked via action woocommerce_add_to_cart_validation, priority 10
	 * @since  1.0.0
	 * @param  bool  	$passed
	 * @param  integer 	$product_id
	 * @param  integer  $quantity
	 * @param  integer 	$variation_id
	 * @return bool
	 */
	public function validate_product_permission_by_user_group( $passed, $product_id, $quantity, $variation_id = 0) {

		$product_id = (!empty($variation_id)) ? $variation_id : $product_id;

		$response   = sejowoo_check_user_permission_by_product_group($product_id);

		if ( !$response['allow'] && !empty($response['error']) ) :

			$passed = false;

			foreach( (array) $response['error'] as $error ) :

				if( is_array($error) ) :

					foreach( $error as $single_error ) :

						if( !empty($single_error['message']) && is_array($single_error['message']) ) :
							foreach( $single_error['message'] as $error_msg ) :
								wc_add_notice( __( $error_msg, 'woocommerce' ), 'error' );
							endforeach;
						else :
							wc_add_notice( __( $single_error, 'woocommerce' ), 'error' );
						endif;


					endforeach;

				else :
					wc_add_notice( __( $error, 'woocommerce' ), 'error' );
				endif;

			endforeach;

		endif;

		return $passed;
	}

	/**
	 * Set default user group to current user if enabled
	 * Hooked via action user_register, priority 10
	 * @since 	1.0.2
	 * @param 	integer 	$user_id
	 */
	public function set_default_user_group( $user_id ) {

		$enable_set_user_group       = boolval( carbon_get_theme_option('sejowoo_enable_set_user_group_after_registration') );
		$default_user_group          = absint( carbon_get_theme_option('sejowoo_default_user_group') );
		$default_checkout_user_group = absint( carbon_get_theme_option('sejowoo_default_user_group_checkout') );

		if( true === $enable_set_user_group && 0 < $default_user_group ||
			true === $enable_set_user_group && 0 < $default_checkout_user_group ||
			true === $enable_set_user_group && 0 < $default_user_group && 0 < $default_checkout_user_group ) :

			$logger = wc_get_logger();

			if ( isset( $_POST['email'] ) ) {

				update_user_meta(
					$user_id,
					'_user_group',
					$default_user_group
				);

			} else {

				update_user_meta(
					$user_id,
					'_user_group',
					$default_checkout_user_group
				);

			}

			$logger->info(

				sprintf(
					__('User %s group updated to %s', 'sejowoo'),
					$user_id,
					$default_user_group
				),
				$this->log
			);

		endif;

	}

}
