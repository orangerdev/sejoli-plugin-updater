<?php

namespace Sejowoo\Admin;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

class Dokan {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.1.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.1.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Current order data
	 *
	 * @since 	1.1.0
	 * @var 	false|WC_Order
	 */
	protected $order = false;

	/**
	 * Current order item data
	 *
	 * @since	1.1.0
	 * @var 	array
	 */
	protected $order_items = array();

	/**
	 * Current product price
	 *
	 * @since	1.1.0
	 * @var 	float
	 */
	protected $product_price = 0.0;

	/**
	 * Dokan data setup
	 *
	 * @since 	1.1.0
	 * @var 	array
	 */
	protected $dokan_data = array(
		'callable'      => NULL,
		'order_id'      => NULL,
		'product_price' => NULL,
		'class'         => NULL
	);

	/**
	 * Item index, incase the revenue calculation is not based by product id
	 * It's very risky since it depends on the iteration, but since Dokan
	 * doesn't provide any detail information if the calculation is not product-based
	 *
	 * @since 	1.1.0
	 * @var 	integer
	 */
	protected $line_index = 0;

    /**
	 * Set woocommerce log $context
	 * @since 	1.0.0
	 * @var		array
	 */
	protected $log = array(
		'source' => 'sejowoo-dokan'
	);

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.1.0
	 * @param    string    $plugin_name       The name of this plugin.
	 * @param    string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

	}

	/**
	 * Get product category options
	 * @since 	1.1.2
	 * @return 	array
	 */
	public function set_product_category_options() {
		return sejowoo_get_product_category_options();
	}

    /**
     * Add dokan setting fields
     * Hooked via filter sejowoo/general/fields, priority 9999
     * @since   1.1.0
     * @since 	1.1.2 	Add setting to prevent vendor buys own product
     * @since 	1.2.0	Check if dokan class exits
     * @param   array  	$fields
     * @return  array
     */
    public function setup_setting_fields( array $fields ) {

		if( ! class_exists('WeDevs_Dokan')) :
			return $fields;
		endif;

        $fields['dokan'] = array(

            'title'  => __('Dokan', 'sejowoo'),
            'fields' => array(

				// ===
				// Dokan Setting
				// ===

                Field::make('separator', 'sep_general_dokan', __('Pengaturan tambahan untuk sistem Dokan Marketplace', 'sejowoo')),

				Field::make('html', 	 'html_general_dokan')
					->set_html( __( 'Pengaturan ini hanya berfungsi jika anda menggunakan Dokan Marketplace', 'sejowoo') ),

                Field::make( 'text', 'sejowoo_dokan_min_limit_commission', __('Minimal komisi admin', 'sejowoo'))
                    ->set_attribute('type', 'number')
                    ->set_attribute('min', 0)
                    ->set_default_value(0)
                    ->set_help_text( __('Isi dengan nilai 0 jika tidak ada limitasi', 'sejowoo') )
                    ->set_width( 50 ),

                Field::make( 'text', 'sejowoo_dokan_max_limit_commission', __('Maksimal komisi admin', 'sejowoo'))
                    ->set_attribute('type', 'number')
                    ->set_attribute('min', 0)
                    ->set_default_value(0)
                    ->set_help_text( __('Isi dengan nilai 0 jika tidak ada limitasi', 'sejowoo') )
                    ->set_width( 50 ),

                Field::make( 'select', 'sejowoo_dokan_default_commission', __('Default komisi produk', 'sejowoo'))
                    ->add_options( apply_filters( 'sejowoo/commission/options', array()) )
                    ->set_help_text( __('Default komisi untuk produk yang ditambahkan oleh vendor', 'sejowoo')),

				Field::make( 'checkbox', 'sejowoo_dokan_disable_buy_own_product', __('Tidak izinkan vendor membeli produknya sendiri', 'sejowoo'))
					->set_help_text( __('Dengan mengaktifkan fitur ini, vendor tidak bisa membeli produknya sendiri', 'sejowoo')),

				// ===
				// Dokan Produk Setting
				// ===
				Field::make('separator', 'sep_general_dokan_product_editor', __('Pengaturan Editor Produk', 'sejowoo')),

				Field::make('multiselect', 'sejowoo_dokan_hide_product_categories', 		__('Sembunyikan produk kategori dari vendor', 'sejowoo'))
					->set_options( array( $this, 'set_product_category_options') ),

				Field::make('checkbox', 'sejowoo_dokan_default_product_type_as_simple', 	__('Semua produk yang dibuat bertipe SIMPLE', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_default_product_type_as_virtual', 	__('Semua produk yang dibuat bertipe VIRTUAL', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_hide_download_product_setup', 		__('Sembunyikan pengaturan download', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_hide_inventory_product_setup', 		__('Sembunyikan pengaturan inventori', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_hide_shipping_product_setup', 		__('Sembunyikan pengaturan pengiriman dan pajak ( Hanya ada di PRO version)', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_hide_discount_product_setup', 		__('Sembunyikan pengaturan discount ( Hanya ada di PRO version)', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_hide_linked_product_setup', 			__('Sembunyikan pengaturan produk bertautan ( Hanya ada di PRO version)', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_hide_seo_product_setup', 			__('Sembunyikan pengaturan SEO produk ( Hanya ada di PRO version)', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_hide_variations_product_setup', 		__('Sembunyikan pengaturan variation produk ( Hanya ada di PRO version)', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_hide_other_options_product_setup', 	__('Sembunyikan pengaturan lainnya', 'sejowoo')),

				// ===
				// Order status setting
				// ===

				Field::make('separator', 'sep_general_dokan_custom_status', __('Pengaturan Order', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_add_send_order_status', __('Tambahkan order status SUDAH DIKIRIM', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_enable_vendor_to_cancel_order', __('Perbolehkan vendor untuk update order BATAL / REFUND', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_enable_vendor_to_complete_order', __('Perbolehkan vendor untuk update order SELESAI', 'sejowoo')),

				// ===
				// Dokan PRO Setting
				// ===

				Field::make('separator', 'sep_general_dokan_pro', __('Pengaturan tambahan untuk sistem Dokan Marketplace - PRO Version', 'sejowoo')),

				Field::make('html', 	 'html_general_dokan_pro')
					->set_html( __( 'Pengaturan ini hanya berfungsi jika anda menggunakan Dokan Marketplace PRO VERSION', 'sejowoo') ),

				Field::make('checkbox', 'sejowoo_dokan_pro_hide_store_payment_setting', __('Sembunyikan pengaturan Payment pada pengaturan Store', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_pro_hide_store_shipping_setting', __('Sembunyikan pengaturan Shipping pada pengaturan Store', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_pro_hide_store_social_profile_setting', __('Sembunyikan pengaturan Social Profile pada pengaturan Store', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_dokan_pro_hide_store_seo_setting', __('Sembunyikan pengaturan Store SEO pada pengaturan Store', 'sejowoo'))
            )
        );

        return $fields;
    }

	/**
	 * Prepare data before insert vendor revenue to wallet
	 * Hooked via action dokan_before_prepare_for_calculation, priority 9999
	 * @since 	1.1.0
	 * @param  	string 	$callable
	 * @param  	integer $product_id
	 * @param  	float 	$product_price
	 * @param  	\WeDevs\Dokan\Commission 	$revenue_class
	 */
	public function prepare_before_insert_to_wallet( $callable, $product_id, $product_price, $revenue_class ) {

		$this->dokan_data = array(
			'callable'      => $callable,
			'order_id'      => $revenue_class->get_order_id(),
			'product_price' => $product_price,
			'class'         => $revenue_class
		);

	}

    /**
     * Calculate admin commission earning
     * Hooked via filter dokan_prepare_for_calculation, priority 9999
     * @since   1.1.0
     * @param  float    $earning
     * @param  float    $commission_rate
     * @param  string   $commission_type
     * @param  float    $additional_fee
     * @param  float    $product_price
     * @param  integer  $order_id
     * @return float
     */
    public function calculate_earning( $earning, $commission_rate, $commission_type, $additional_fee, $product_price, $order_id ) {

        $logger        = wc_get_logger();

		$this->product_price = $product_price;

		// Recalculate earning value
        $prev_earning = $earning;
        $logger       = wc_get_logger();
        $recalculate  = false;

        $admin_commission = $product_price - $earning;
        $min_commission   = floatval( carbon_get_theme_option('sejowoo_dokan_min_limit_commission') );
        $max_commission   = floatval( carbon_get_theme_option('sejowoo_dokan_max_limit_commission') );

        if( 0 < $min_commission && $admin_commission < $min_commission ) :
            $earning = $product_price - $min_commission;
            $recalculate = 'min';
        endif;

        if( 0 < $max_commission && $admin_commission > $max_commission ) :
            $earning = $product_price - $max_commission;
            $recalculate = 'max';
        endif;

        if( false !== $recalculate ) :

            $logger->info(
                sprintf(
                    __('Recalculate admin commission. Product Price %s, previous earning %s, current earning %s, recalculation type %s', 'sejowoo'),
                    $product_price,
                    $prev_earning,
                    $earning,
                    $recalculate
                ),
                $this->log
            );

        endif;

        return $earning;
    }

	/**
     * Insert vendor earning to wallet
     * Hooked via filter dokan_prepare_for_calculation, priority 10001
     * @since   1.1.0
     * @since 	1.1.2 	  	Prevent insert data to wallet from seller context
     * @param   float    	$earning
     * @param   WC_Product 	$product
     * @param   string   	$context
     * @return  float
     */
    public function insert_to_wallet( float $earning, \WC_Product $product, string $context ) {

		if( 'seller' === $context || empty( $this->dokan_data['order_id'] ) ) :
			return $earning;
		endif;

	    $logger         = wc_get_logger();
		$order_id       = $this->dokan_data['order_id'];
		$seller_earning = ( 'admin' === $context ) ? $this->product_price - $earning : $earning;

		//
		// Add earning value to sejoli wallet
		//
		if( 0 === count($this->order_items) ) :

			$this->order = wc_get_order( $order_id );

			foreach( (array) $this->order->get_items() as $item_id => $item ) :

				$this->order_items[$item->get_product_id()] = $item_id;

			endforeach;

		endif;

		$item_id    = $this->order_items[ $product->get_id() ];
		$product_id = $product->get_id();
		$user_id    = get_post_field( 'post_author', $product->get_id() );

		$args = array(
	        'order_id'    => $order_id,
	        'item_id'     => $item_id,
	        'user_id'     => $user_id,
	        'product_id'  => $product_id,
	        'refundable'  => true,
	        'valid_point' => false,
	        'value'       => $seller_earning,
	        'type'        => 'in',
	        'label'       => 'dokan-revenue',
			'meta_data'	  => array(
				'earning'        => $earning,
				'seller_earning' => $seller_earning,
				'context'        => $context
			)
	    );

		$wallet = sejowoo_add_wallet_value($args);

		if( is_wp_error($wallet) ) :

			$logger->error(
				sprintf(
					__('Cant add wallet data based on dokan revenue. Reason(s) : %s', 'sejowoo'),
					$wallet->get_error_message()
				),
				array( 'source' => 'sejowoo-dokan-revenue' )
			);

		else :

			$logger->info(
				sprintf(
					__('New revenue for user ID %s, amount %s based on order ID %s, item ID %s, product ID %s', 'sejowoo'),
					$this->order->get_user_id(),
					$seller_earning,
					$order_id,
					$item_id,
					$product_id
				),
				array( 'source' => 'sejowoo-dokan-revenue' )
			);

		endif;

		$this->line_index++;

		return $earning;
	}

	/**
	 * Update revenue on wallet point valid status to invalid
	 * Hooked via action woocommerce_order_status_pending, priority 399
	 * Hooked via action woocommerce_order_status_on-hold, priority 399
	 * Hooked via action woocommerce_order_status_failed, priority 399
	 * Hooked via action woocommerce_order_status_refunded, priority 399
	 * Hooked via action woocommerce_order_status_processing, priority 399
	 * Hooked via action woocommerce_order_status_cancelled, priority 399
	 * @since 	1.0.0
	 * @since 	1.2.0	Check if dokan class exits
	 * @param 	integer 	$order_id
	 */
	public function set_revenue_status_invalid( int $order_id ) {

		if( ! class_exists('WeDevs_Dokan')) :
			return;
		endif;

		$order = wc_get_order( $order_id );

		sejowoo_update_wallet_point_valid_status( $order_id, false, 'dokan-revenue' );
	}

	/**
	 * Update revenue on wallet point valid status to valid
	 * Hooked via action woocommerce_order_status_completed, priority 399
	 * @since 	1.0.0
	 * @since 	1.2.0	Check if dokan class exits
	 * @param 	integer 	$order_id
	 */
	public function set_revenue_status_valid( int $order_id ) {

		$order = wc_get_order( $order_id );

		sejowoo_update_wallet_point_valid_status( $order_id, true, 'dokan-revenue' );
	}
}
