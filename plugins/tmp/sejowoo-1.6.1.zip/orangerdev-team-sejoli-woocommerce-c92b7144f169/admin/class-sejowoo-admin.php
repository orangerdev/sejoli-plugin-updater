<?php

namespace Sejowoo;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://sejowoo.co.id
 * @since      1.0.0
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/admin
 * @author     OrangerDev <orangerdigiart@gmail.com>
 */
class Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Container from carbonfield
	 * @since   1.0.0
	 * @access 	protected
	 * @var 	Container
	 */
	protected $container;

	/**
	 * Current admin page
	 * @since 	1.0.0
	 * @access 	protected
	 * @var 	bool
	 */
	protected $is_sejowoo_page = false;

	/**
	 * Enable post type for CSS and HS
	 * @since 	1.1.9
	 * @access 	protected
	 * @var 	array
	 */
	protected $enabled_post_type = array(
		'sejowoo-user-group', 'product'
	);

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Load carbon fields library
	 * Hooked via after_setup_theme, prioritas 999
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function load_carbon_fields() {
		\Carbon_Fields\Carbon_Fields::boot();
	}

	/**
	 * Check if WooCommerce is active
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function check_if_woocommerce_active() {

		global $sejowoo;

		if( ! class_exists('woocommerce') ) :
			$sejowoo['active']	= false;
		endif;
	}

	/**
	 * Setup database classes
	 * Hookeed via action plugins_loaded, priority 100
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function setup_database() {
		global $sejowoo;

		$sejowoo['db'] = new \stdClass;

		$sejowoo['db']->commission   = new \SejoWoo\Database\Commission;
		$sejowoo['db']->coupon    	 = new \SejoWoo\Database\Coupon;
		$sejowoo['db']->request_fund = new \SejoWoo\Database\RequestFund;
		$sejowoo['db']->wallet       = new \SejoWoo\Database\Wallet;
	}

	/**
	* Add member area link to admin bar
	* Hooked via action admin_bar_menu, priority 9999
	* @since 	1.1.2
	* @return 	void
	*/
	public function add_member_area_link($admin_bar) {

		$admin_bar->add_menu([
		   'id'	=> 'sejowoo-member-area',
		   'title'	=> 'Member Area',
		   'href'	=> get_permalink( get_option('woocommerce_myaccount_page_id') )
	   	]);

	   	if(!current_user_can('manage_options')) :
			$admin_bar->remove_node('wp-logo');
			$admin_bar->remove_node('site-name');
			$admin_bar->remove_node('new-content');
			$admin_bar->remove_node('query-monitor');
			$admin_bar->remove_node('edit-profile');
			$admin_bar->remove_node('search');
		endif;
	}

	/**
	 * Get container main setting
	 * Hooked via filter sejowoo/general/container, prirority 1
	 * @since 	1.0.0
	 * @param  	string 			$container	Carbon field container object
	 * @return 	Container
	 */
	public function get_container($container = '') {
		return $this->container;
	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles() {
		global $pagenow, $post;

		$is_sejowoo_page = apply_filters('sejowoo/admin/is-sejowoo-page', false);

		wp_register_style( $this->plugin_name.'-carbonfields', 	SEJOWOO_URL . 'admin/css/carbonfields.css', 						 [], $this->version, 'all');
		wp_register_style( $this->plugin_name.'-dataTables',   	SEJOWOO_URL . 'admin/css/dataTables.css', 							 [], $this->version, 'all');
		wp_register_style( 'select2',							'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css',  [], '4.0.7', 'all');
		wp_register_style( 'dataTables',						'https://cdn.datatables.net/1.10.18/css/jquery.dataTables.min.css', 		 [], '1.10.18', 'all');
		wp_register_style( 'semantic-ui', 						'https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css', [], '2.4.1', 'all' );
		wp_register_style( 'dataTables-semantic-ui', 			'https://cdn.datatables.net/1.10.19/css/dataTables.semanticui.min.css', 	 ['dataTables', 'semantic-ui'], '1.10.19', 'all' );
		wp_register_style( 'daterangepicker',					'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css',			 [], NULL, 'all');
		wp_enqueue_style ( $this->plugin_name, 					SEJOWOO_URL . 'admin/css/sejowoo-admin.css', 						 [], $this->version, 'all' );

		if(
			(in_array($pagenow, ['post-new.php', 'post.php']) && in_array($post->post_type, $this->enabled_post_type )) ||
			(
				in_array($pagenow, ['admin.php']) && isset($_GET['page']) &&
				in_array($_GET['page'], ['crb_carbon_fields_container_social_proof.php', 'crb_carbon_fields_container_sejoli.php'])
			)
		) :
			wp_enqueue_style( $this->plugin_name.'-carbonfields');
		endif;

		if(
			in_array($pagenow, ['post-new.php', 'post.php', 'profile.php', 'user-edit.php']) &&
			(
				isset($_GET['user_id']) || 'profile.php' === $pagenow
			)
		) :
			wp_enqueue_style( 'select2' );
		endif;

		if($is_sejowoo_page) :
			wp_enqueue_style( $this->plugin_name.'-dataTables');
			wp_enqueue_style( 'daterangepicker');
			wp_enqueue_style( 'select2' );
			wp_enqueue_style( 'semantic-ui');
			wp_enqueue_style( 'dataTables-semantic-ui' );
		endif;
	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts() {
		global $pagenow, $post;

		$is_sejowoo_page = apply_filters('sejowoo/admin/is-sejowoo-page', false);

		wp_register_script( 'select2', 			'https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js', 					['jquery'], '4.0.7', true);
		wp_register_script( 'dataTables', 		'https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js', 							['jquery', $this->plugin_name], '1.10.18', true);
		wp_register_script( 'jquery-blockUI', 	'https://cdnjs.cloudflare.com/ajax/libs/jquery.blockUI/2.70/jquery.blockUI.min.js', 		['jquery'], '2.70', true );
		wp_register_script( 'js-render', 		'https://cdnjs.cloudflare.com/ajax/libs/jsrender/0.9.91/jsrender.min.js', 					['jquery'], '0.9.91', true );
		wp_register_script( 'jquery-maskmoney', 'https://cdnjs.cloudflare.com/ajax/libs/jquery-maskmoney/3.0.2/jquery.maskMoney.min.js', 	['jquery'], '3.0.2', true );
		wp_register_script( 'moment',			'https://cdn.jsdelivr.net/momentjs/latest/moment.min.js',									['jquery'], NULL, true);
		wp_register_script( 'daterangepicker',	'https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js',						['moment'], NULL, true);
		wp_register_script( 'semantic-ui',		'https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js',					['jquery'], '2.4.1', true );
		wp_register_script( $this->plugin_name . '-hooks',	SEJOWOO_URL . 'admin/js/sejowoo-hooks.js',										['jquery'], $this->version, true );
		wp_enqueue_script( 	$this->plugin_name, SEJOWOO_URL . 'admin/js/sejowoo-admin.js', 													['jquery'], $this->version, true );

		// localize data
		$admin_localize_data = apply_filters('sejowoo/admin/js-localize-data', [
			'text' => [
				'main'     => __('Pengaturan', 'sejowoo'),
				'currency' => 'Rp. ',
				'status'   => [
					'pending'  => __('Belum Aktif', 'sejowoo'),
					'inactive' => __('Tidak Aktif', 'sejowoo'),
					'active'   => __('Aktif', 'sejowoo'),
					'expired'  => __('Berakhir', 'sejowoo')
				]
			],
			'color' => sejowoo_get_all_colors()
		]);

		wp_localize_script( $this->plugin_name, 'sejowoo_admin', $admin_localize_data);

		// If current page is profile
		if(
			in_array($pagenow, ['post-new.php', 'post.php', 'profile.php', 'user-edit.php']) &&
			(
				isset($_GET['user_id']) || 'profile.php' === $pagenow
			)
		) :
			wp_enqueue_script( 'select2' );
		endif;

		// All sejowoo option page
		if($is_sejowoo_page) :

			wp_enqueue_script( 'daterangepicker');
			wp_enqueue_script( 'select2' );
			wp_enqueue_script( 'dataTables' );
			wp_enqueue_script( 'jquery-blockUI');
			wp_enqueue_script( 'js-render');
			wp_enqueue_script( 'semantic-ui');
			wp_enqueue_script ($this->plugin_name . '-hooks');

			wp_localize_script ("dataTables","dataTableTranslation",array(
				"all"			 => __('Semua','sejowoo'),
				"decimal"        => ",",
				"emptyTable"     => __("Tidak ada data yang bisa ditampilkan","sejowoo"),
				"info"           => __("Menampikan _START_ ke _END_ dari _TOTAL_ data","sejowoo"),
				"infoEmpty"      => __("Menampikan 0 ke 0 dari 0 data","sejowoo"),
				"infoFiltered"   => __("Menyaring dari total _MAX_ data","sejowoo"),
				"infoPostFix"    => "",
				"thousands"      => ".",
				"lengthMenu"     => __("Menampilkan _MENU_ data","sejowoo"),
				"loadingRecords" => __("Mengambil data...","sejowoo"),
				"processing"     => __("Mengambil data..","sejowoo"),
				"search"         => __("Cari data :","sejowoo"),
				"zeroRecords"    => __("Tidak ditemukan data yang sesuai","sejowoo"),
				"paginate"       =>
				 array(
					"first"    => __("Pertama","sejowoo"),
					"last"     => __("Terakhir","sejowoo"),
					"next"     => __("Selanjutnya","sejowoo"),
					"previous" => __("Sebelumnya","sejowoo")
				),
				"aria"           => array(
					"sortAscending"  => __("Klik untuk mengurutkan kolom naik","sejowoo"),
					"sortDescending" => __("Klik untuk mengurutkan kolom turun","sejowoo")
				)
			));
		endif;

	}

	/**
	 * Set sejowoo general fields
	 * Hooked via filter sejowoo/general/fields, priority 10
	 * @since 	1.0.0
	 * @param 	array $fields
	 * @return	arrays
	 */
	public function set_sejowoo_general_fields( array $fields ) {

		$fields['main']	= array(
			'title'  => __('Pengaturan utama', 'sejowoo'),
			'fields' => array(
				Field::make('separator', 'sep_general_display_data_in_front_end', __('Penampilan Data di Member Area', 'sejowoo')),

				Field::make('html', 	 'html_general_display_data_in_front_end')
					->set_html(
						__( 'Sejoli menghormati privasi data diri. Oleh karena itu secara default, Sejoli tidak akan menampilkan data pribadi pembeli di halaman <strong>Order dari Affiliasi Anda</strong>. '.
							'Namun admin bisa mengatur hal ini dengan mengaktifkan settingan di bawah ini', 'sejowoo')
					),

				Field::make('checkbox', 'sejowoo_display_buyer_email', __('Tampilkan alamat email pembeli', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_display_buyer_phone', __('Tampilkan nomor telpon pembeli', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_display_buyer_address', __('Tampilkan alamat pengiriman pembeli', 'sejowoo'))
			)
		);

		return $fields;
	}

	/**
	 * Set debug fields
	 * Hooked via filter sejowoo/general/fields, priority 10
	 * @since 	1.1.2
	 * @param 	array $fields
	 * @return	array
	 */
	public function set_debug_fields( array $fields ) {

		$fields['debug']	= array(
			'title'  => __('Debug', 'sejowoo'),
			'fields' => array(
				Field::make('separator', 'sep_general_debug', __('Debugging', 'sejowoo')),

				Field::make('html', 	 'html_general_debug')
					->set_html(
						__( 'Pengaturan debugging ini akan membutuhkan plugin QUERY MONITOR untuk menampilkan log data. Pergunakan jika memang anda adalah developer', 'sejowoo')
					),

				Field::make('checkbox', 'sejowoo_debug_enable', __('Tampilkan debug log', 'sejowoo')),
			)
		);

		return $fields;
	}

	/**
	 * Setup custom fields for product
	 * Hooked via action carbon_fields_register_fields, priority 10
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function setup_carbon_fields() {

		global $sejowoo;

		if( ! sejowoo_is_woocommerce_active() || false === sejowoo_check_own_license() ) :
			return;
		endif;


		$fields = apply_filters( 'sejowoo/general/fields', []);

		if(is_array($fields) && 0 < count($fields)) :

			$this->container = Container::make('theme_options', __('Sejoli', 'sejowoo'))
									->set_icon( ! defined('zshop') ? plugin_dir_url( __FILE__ ) . 'images/icon.png' : NULL )
									->set_page_menu_position( 2 )
									->set_classes('sejowoo-metabox');

			foreach($fields as $field) :
				$this->container->add_tab($field['title'], $field['fields']);
			endforeach;

		endif;
	}

    /**
     * Check current admin page
     * Hooked via action admin_init, priority 999
     * @return void
     */
    public function check_page_request() {
        if(
            isset($_GET['page']) &&
            in_array($_GET['page'],[
                'sejoli-orders',
				'sejoli-commissions',
				'sejoli-affiliates',
				'sejoli-coupons',
				'sejoli-subscriptions',
				'sejoli-licenses',
				'sejoli-leaderboard',
				'sejoli-confirmation',
				'sejoli-reminder-log'
            ])
        ) :
            $this->is_sejowoo_page = true;
        endif;
    }

    /**
     * Check if current admin page is a sejowoo
     * Hooked via filter sejowoo/admin/is-sejowoo-page, priority 999
     * @param  boolean $is_sejowoo_page
     * @return boolean
     */
    public function is_sejowoo_page($is_sejowoo_page = false) {
        return $this->is_sejowoo_page;
    }

	/*
	* Notify admin to check if WooCommerce installed
	* Hooked via action admin_notices, priority 100
	* @since 	1.0.0
	* @return 	void
	*/
   public function notify_check_woocommerce() {

	   if( ! class_exists('woocommerce') ) :
		   require_once ( plugin_dir_path( __FILE__) . '/partials/admin/notice-woocommerce.php' );
	   else :
		   $guest_checkout = get_option('woocommerce_enable_guest_checkout');
		   $login_reminder = get_option('woocommerce_enable_checkout_login_reminder');
		   $enable_signup  = get_option('woocommerce_enable_signup_and_login_from_checkout');

		   if(
			   'no' !== $guest_checkout ||
			   'yes' !== $login_reminder ||
			   'yes' !== $enable_signup
		   ) :
		   		require_once ( plugin_dir_path( __FILE__) . '/partials/admin/notice-woocommerce-setting.php' );
	   	   endif;

	   endif;

   }
}
