<?php

namespace Sejowoo\Admin;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

class Wallet {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Wallet fee name in carts
	 * @since 	1.0.0
	 * @var 	string
	 */
	protected $wallet_fee_name = 'Penggunaan Dana';

	/**
	 * Set woocommerce log $context
	 * @since 	1.0.0
	 * @var		array
	 */
	protected $log = array(
		'source' => 'sejowoo-wallet'
	);

	/**
     * Display wallet setting fields
     * Hooked via filter sejowoo/general/fields, priority 90
     * @since   1.0.0
     * @since 	1.1.0	Add minimum request fund
     * @param 	array 	$fields
     * @return  array
     */
    public function setup_setting_fields( array $fields ) {

		$fields['wallet'] = array(
			'title'  => __('Wallet', 'sejowoo'),
            'fields' => array(
				// Checkout
				Field::make( 'separator', 'sep_sejowoo_wallet_checkout', __('Halaman Checkout', 'sejowoo'))
					->set_classes('sejoli-with-help'),

				Field::make( 'checkbox', 'sejowoo_wallet_activate_on_checkout', __('Aktifkan penggunaan dana wallet ketika checkout', 'sejowoo')),

				// Request fund
				Field::make( 'separator', 'sep_sejowoo_wallet_request_fund', __('Halaman Pencairan Dana', 'sejowoo'))
					->set_classes('sejoli-with-help'),

				Field::make( 'text', 'sejowoo_wallet_minimum_reqeust_fund', __('Minimal dana yang bisa dicairkan', 'sejowoo'))
					->set_attribute('type', 'number')
					->set_default_value(0),

				Field::make( 'rich_text', 'sejowoo_wallet_request_fund_message', __('Pesan pada halaman pencairan dana', 'sejowoo'))
					->set_help_text( __('Bisa diisi dengan pesan seperti kapan waktu jadwal pencairan komisi.', 'sejowoo')),
			)
		);

		return $fields;
	}

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

    /**
     * Register wallet in main admin menu
     * Hooked via action admin_menu, priority 10
     * @since   1.0.0
     * @return  void
     */
    public function register_admin_menu() {

		if( ! sejowoo_is_woocommerce_active() || false === sejowoo_check_own_license() ) :
			return;
		endif;

        add_menu_page(
            __('Wallet', 'sejowoo'),
            __('Wallet', 'sejowoo'),
            'manage_sejoli_wallet',
            'sejowoo-wallet-management',
            array( $this, 'display_management' ),
            ! defined('zshop') ? plugin_dir_url( __FILE__ ) . 'images/icon.png' : NULL,
            38
        );

    }

	/**
	 * Set if current page is all related wallet page
	 * Hooked via filter sejowoo/admin/is-sejowoo-page, priority 10s
	 * @since 	1.0.0
	 * @param 	boolean 	$is_sejowoo_page 	Set if current page is sejowoo page
	 * @return 	boolean
	 */
	public function set_needed_scripts( $is_sejowoo_page ) {

		global $pagenow;

		if(
			'admin.php' === $pagenow &&
			isset( $_GET['page'] ) &&
			in_array(
				$_GET['page'],
				array( 'sejowoo-wallet-management' )
			)
		) :
			return true;
		endif;

		return $is_sejowoo_page;

	}

	/**
	 * Set local JS variables
	 * Hooked via filter sejowoo/admin/js-localize-data, priority 10
	 * @since 	1.0.0
	 * @param 	array 	$js_vars 	An array of javascript variables
	 * @return 	array
	 */
	public function set_localize_js_var( array $js_vars ) {

		$js_vars['wallet'] = array(
			'table'	=> array(
				'ajaxurl'	=> add_query_arg(array(
						'action' => 'sejowoo-wallet-table'
					), admin_url('admin-ajax.php')
				),
				'nonce'	=> wp_create_nonce('sejowoo-render-wallet-table')
			),
			'export' => array(
				'ajaxurl'	=> add_query_arg(array(
						'action' => 'sejowoo-wallet-export-csv'
					), admin_url('admin-ajax.php')
				),
				'nonce'	=> wp_create_nonce('sejowoo-wallet-export-csv')
			),
			'single_table'	=> array(
				'ajaxurl'	=> add_query_arg(array(
						'action' => 'sejowoo-single-wallet-table'
					), admin_url('admin-ajax.php')
				),
				'nonce'   => wp_create_nonce('sejowoo-render-single-wallet-table'),
				'user_id' => (isset($_GET['user_id'])) ? intval($_GET['user_id']) : get_current_user_id()
			),
			'single_export' => array(
				'ajaxurl'	=> add_query_arg(array(
						'action' => 'sejowoo-single-wallet-export-csv'
					), admin_url('admin-ajax.php')
				),
				'nonce'	=> wp_create_nonce('sejowoo-single-wallet-export-csv')
			),
			'request_table' => array(
				'ajaxurl'	=> add_query_arg(array(
						'action' => 'sejowoo-request-fund-table'
					), admin_url('admin-ajax.php')
				),
				'nonce'	=> wp_create_nonce('sejowoo-render-request-fund-table')
			),
			'update-request'	=> array(
				'ajaxurl'	=> add_query_arg(array(
						'action' => 'sejowoo-update-request-fund'
					), admin_url('admin-ajax.php')
				),
				'nonce'   => wp_create_nonce('sejowoo-update-request-fund')
			),
		);

		return $js_vars;
	}

    /**
     * Display wallet management page
     * Called internally from register_admin_menu
     * @since   1.0.0
     * @return  void
     */
    public function display_management() {

		if( isset($_GET['user_id']) && current_user_can('manage_sejoli_wallet')) :

			$user = new \WC_Customer( intval( $_GET['user_id'] ) ) ;
			require_once( plugin_dir_path( __FILE__ ) . 'partials/wallet/single-user-page.php' );

		else :
        	require_once( plugin_dir_path( __FILE__ ) . 'partials/wallet/page.php' );
		endif;

    }

	/**
     * Check if order uses wallet data in fee
     * Hooked vi action woocommerce_checkout_update_order_meta, priority 100
     * @since   1.0.0
     * @param   integer     $order_id
     */
	public function check_if_order_use_wallet( int $order_id) {

		$post_data = wp_parse_args($_POST, array(
			'sejowoo-use-wallet-point' => false
		));

		$order = wc_get_order( $order_id );

		if(
			is_a($order, 'WC_Order') &&
			false !== boolval($post_data['sejowoo-use-wallet-point'])
		) :

			$wallet_data = sejowoo_get_single_user_wallet();
			$available_total = (isset($wallet_data['available_total'])) ? $wallet_data['available_total'] : 0;

			if( 0 < floatval($available_total)) :

				$order_total = $order->calculate_totals();
				$wallet_use  = $wallet_available = floatval( $available_total );

				if( $wallet_available > $order_total ) :
					$wallet_use = $order_total;
				endif;

				$item_fee = new \WC_Order_Item_Fee();

				$item_fee->set_name( $this->wallet_fee_name );
				$item_fee->set_amount( -$wallet_use );
				$item_fee->set_total( -$wallet_use );

				$order->add_item( $item_fee );
				$order->calculate_totals();
				$order->save();

				$respond = sejowoo_add_wallet_value(array(
					'order_id'    => $order->get_id(),
					'user_id'     => $order->get_user_id(),
					'valid_point' => true,
					'value'		  => $wallet_use,
					'label'		  => 'wallet-use',
					'type'		  => 'out'
				));

				$logger  = wc_get_logger();

		        if( is_wp_error( $respond) ) :

		            foreach( $respond->get_error_messages() as $message ) :
		                $logger->error( $message, $this->log );
		            endforeach;

		        else :

		            foreach( $respond as $wallet ) :

		                $logger->info(
		                    sprintf(
		                        __('Wallet used with amount %s for order_id %s, user_id %s and wallet_id %s', 'sejowoo'),
		                        $wallet_use,
		                        $order->get_id(),
		                        $order->get_user_id(),
		                        $respond['ID']
		                    ),
		                    $this->log
		                );

		            endforeach;
		        endif;

			endif;

		endif;

	}

	/**
	 * Update wallet_point status to invalid when requested fund rejected
	 * Hooked via action sejowoo/fund/update-request, priority 10s
	 * @since 	1.0.0
	 * @param  	WP_User $admin
	 * @param  	array   $request_data
	 * @return 	void
	 */
	public function update_point_status_when_request_fund_processed( \WP_User $admin, array $request_data ) {

		if( 'rejected' === $request_data['status'] ) :

			$respond = sejowoo_update_wallet_point_valid_status_by_meta(
							$request_data['ID'],
							false,
							'request-fund'
					   );

			if( is_wp_error($respond) ) :

				$logger  = wc_get_logger();

				$logger->error(
					$respond->get_error_message(),
					$this->log
				);

			endif;

		endif;

	}

	/**
	 * Update commission order status and wallet point valid status to invalid
	 * Hooked via action woocommerce_order_status_failed, priority 299
	 * Hooked via action woocommerce_order_status_refunded, priority 299
	 * Hooked via action woocommerce_order_status_cancelled, priority 299
	 * @since 	1.0.0
	 * @param 	integer 	$order_id
	 */
	public function set_wallet_use_status_invalid( int $order_id ) {

		sejowoo_update_wallet_point_valid_status( $order_id, false, 'wallet-use' );
	}
}
