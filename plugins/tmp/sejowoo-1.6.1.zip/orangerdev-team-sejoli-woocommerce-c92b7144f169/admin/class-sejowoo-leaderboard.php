<?php

namespace Sejowoo\Admin;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

class Leaderboard {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Set woocommerce log $context
	 * @since 	1.0.0
	 * @var		array
	 */
	protected $log = array(
		'source' => 'sejowoo-commission'
	);

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

    /**
	 * Add JS Vars for localization
	 * Hooked via sejowoo/admin/js-localize-data, priority 1
	 * @since 	1.0.0
	 * @param 	array 	$js_vars 	Array of js vars
	 * @return 	array
	 */
	public function set_localize_js_var(array $js_vars) {

		$js_vars['leaderboard'] = array(
			'table'	=> array(
				'ajaxurl'	=> home_url('sejowoo-ajax/get-table-list'),
				'nonce'		=> wp_create_nonce('sejowoo-render-table-list'),
				'header'	=> array(
					'commission' => __('Total Komisi', 'sejowoo'),
					'quantity'   => __('Total Item', 'sejowoo'),
					'omset'      => __('Total Omset', 'sejowoo')
				)
			)
		);

		return $js_vars;
	}

	/**
	 * Set if current page is all related wallet page
	 * Hooked via filter sejowoo/admin/is-sejowoo-page, priority 10s
	 * @since 	1.0.0
	 * @param 	boolean 	$is_sejowoo_page 	Set if current page is sejowoo page
	 * @return 	boolean
	 */
	public function set_needed_scripts( $is_sejowoo_page ) {

		global $pagenow;

		if(
			'admin.php' === $pagenow &&
			isset( $_GET['page'] ) &&
			in_array(
				$_GET['page'],
				array( 'sejowoo-leaderboard' )
			)
		) :
			return true;
		endif;

		return $is_sejowoo_page;

	}

    /**
     * Register leaderboard menu under sejoli main menu
     * Hooked via action admin_menu, priority 105
     * @since 1.0.0
     * @return void
     */
    public function register_leaderboard_menu() {

        if( ! sejowoo_is_woocommerce_active() || false === sejowoo_check_own_license() ) :
			return;
		endif;

		add_submenu_page(
			'crb_carbon_fields_container_sejoli.php',
			__('Leaderboard', 'sejowoo'),
			__('Leaderboard', 'sejowoo'),
			'manage_sejoli_sejoli',
			'sejoli-leaderboard',
			[$this, 'display_leaderboard_page']
		);
    }

    /**
     * Display leaderboard page
     * @since   1.0.0
     * @return  void
     */
    public function display_leaderboard_page() {
        require_once ( plugin_dir_path( __FILE__ ) ) . 'partials/leaderboard/page.php';
    }

}
