jQuery( document ).ready( function( $ ) {

    $( 'input#_user_group_buy_permission' ).change( function() {
        var is_user_group_buy_permission = $( 'input#_user_group_buy_permission:checked' ).size();

        $( '._user_group_buy_list_field' ).hide();
        $( '._user_group_buy_restricted_message_field' ).hide();

        if ( is_user_group_buy_permission ) {
            $( '._user_group_buy_list_field' ).show();
            $( '._user_group_buy_restricted_message_field' ).show();
        }
    });

    $( 'input#_user_group_update_check' ).change( function() {
        var is_user_group_update_check = $( 'input#_user_group_update_check:checked' ).size();

        $( '._user_group_update_field' ).hide();

        if ( is_user_group_update_check ) {
            $( '._user_group_update_field' ).show();
        }
    });

    $( 'input#_user_group_update_condition' ).change( function() {
        var is_user_group_update_condition = $( 'input#_user_group_update_condition:checked' ).size();

        $( '._user_group_update_list_field' ).hide();

        if ( is_user_group_update_condition ) {
            $( '._user_group_update_list_field' ).show();
        }
    });

    $( 'input#_user_group_buy_permission' ).trigger( 'change' );
    $( 'input#_user_group_update_check' ).trigger( 'change' );
    $( 'input#_user_group_update_condition' ).trigger( 'change' );

});