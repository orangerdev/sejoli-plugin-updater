<div class="wrap">
    <h1 class="wp-heading-inline">
        <?php _e('Data Wallet', 'sejowoo'); ?>
	</h1>

    <div class="notice notice-info sejoli-help-message">
        <h2><?php _e('Penjelasan Data Wallet', 'sejowoo'); ?></h2>
        <p>
            <ul>
                <li>
                    <strong style='display:inline-block;width:120px'>CASH IN</strong> : <?php _e('Total keseluruhan nilai yang masuk melalui cashback atau komisi dengan tipe yang bisa <u>dicairkan</u> dan bisa <u>digunakan untuk pembelajaan</u>', 'sejowoo'); ?>
                </li>
                <li>
                    <strong style='display:inline-block;width:120px'>POINT IN</strong> : <?php _e('Total keseluruhan nilai yang masuk melalui cashback atau komisi dengan tipe yang tidak bisa <u>dicairkan</u> namun bisa <u>digunakan untuk pembelanjaan</u>', 'sejowoo'); ?>
                </li>
                <li>
                    <strong style='display:inline-block;width:120px'>USED</strong> : <?php _e('Total nilai yang sudah digunakan setelah pembelanjakn atau setelah proses pencarian dana', 'sejowoo'); ?>
                </li>
                <li>
                    <strong style='display:inline-block;width:120px'>AVAILABLE CASH</strong>: <?php _e('Total nilai yang TERSEDIA saat ini yang bisa <u>dicairkan</u> atau <u>digunakan untuk pembelanjaan</u>. Rumus : CASH IN - USED', 'sejowoo'); ?>
                </li>
                <li>
                    <strong style='display:inline-block;width:120px'>ALL AVAILABLE </strong>: <?php _e('Total nilai yang TESEDIA saat ini yang HANYA <u>bisa digunakan untuk pembelanjaan saja</u>. Rumus : CASH IN + POINT IN - USED', 'sejowoo'); ?>
                </li>
            </ul>
        </p>
    <button type="button" class="notice-dismiss"><span class="screen-reader-text">Dismiss this notice.</span></button></div>

    <div class="sejowoo-table-wrapper">
        <div class='sejowoo-form-action-holder'>

            <div class="sejowoo-form-filter box" style='float:right;'>
                <button type="button" name="button" class='export-csv button'><?php _e('Export CSV', 'sejowoo'); ?></button>
                <button type="button" name="button" class='button toggle-search'><?php _e('Filter Data', 'sejowoo'); ?></button>
                <div class="sejowoo-form-filter-holder sejowoo-form-float">
                    <select class="autosuggest filter" name="user_id"></select>
                    <?php wp_nonce_field('search-user', 'sejowoo-nonce'); ?>
                    <button type="button" name="button" class='button button-primary do-search'><?php _e('Cari Data', 'sejowoo'); ?></button>
                    <!-- <button type="button" name="button" class='button button-primary reset-search'><?php _e('Reset Pencarian', 'sejowoo'); ?></button> -->
                </div>
            </div>
        </div>
        <div class="sejowoo-table-holder">
            <table id="sejowoo-wallet" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th><?php _e('User', 'sejowoo'); ?></th>
                        <th><?php _e('Cash In', 'sejowoo'); ?></th>
                        <th><?php _e('Point In', 'sejowoo'); ?></th>
                        <th><?php _e('Used', 'sejowoo'); ?></th>
                        <th><?php _e('Available Cash', 'sejowoo'); ?></th>
                        <th><?php _e('All Available', 'sejowoo'); ?></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
                <tfoot>
                    <tr>
                        <th><?php _e('User', 'sejowoo'); ?></th>
                        <th><?php _e('Cash In', 'sejowoo'); ?></th>
                        <th><?php _e('Point In', 'sejowoo'); ?></th>
                        <th><?php _e('Used', 'sejowoo'); ?></th>
                        <th><?php _e('Available Cash', 'sejowoo'); ?></th>
                        <th><?php _e('All Available', 'sejowoo'); ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<script type="text/javascript">

let sejowoo_table;

(function( $ ) {
	'use strict';
    $(document).ready(function() {

        sejowoo.helper.select_2(
            "select[name='user_id']",
            sejowoo_admin.user.select.ajaxurl,
            sejowoo_admin.user.placeholder
        );

        sejowoo.helper.filterData();

        sejowoo_table = $('#sejowoo-wallet').DataTable({
            language: dataTableTranslation,
            searching: false,
            processing: true,
            serverSide: false,
            info: false,
            paging: false,
            ajax: {
                type: 'POST',
                url: sejowoo_admin.wallet.table.ajaxurl,
                data: function(data) {
                    data.filter = sejowoo.var.search;
                    data.action = 'sejowoo-wallet-table';
                    data.nonce = sejowoo_admin.wallet.table.nonce
                    data.backend  = true;
                }
            },
            pageLength : 50,
            lengthMenu : [
                [10, 50, 100, 200],
                [10, 50, 100, 200],
            ],
            order: [
                [ 5, "desc" ]
            ],
            columnDefs: [
                {
                    targets: [0],
                    orderable: false
                },{
                    targets: 0,
                    data : 'display_name',
                    render: function(data, type, full) {

                        let tmpl = $.templates('#user-detail');

                        return tmpl.render({
                            id : full.user_id,
                            display_name : full.display_name,
                            email : full.user_email,
                            detail_url: full.detail_url,
                        })
                    }
                },{
                    targets: 1,
                    width: '100px',
                    data: 'cash_value',
                    className: 'price'
                },{
                    targets: 2,
                    width: '100px',
                    data : 'point_value',
                    className: 'price'
                },{
                    targets: 3,
                    width:  '100px',
                    data: 'used_value',
                    className: 'price'
                },{
                    targets: 4,
                    width:  '100px',
                    data: 'available_cash',
                    className: 'price'
                },{
                    targets: 5,
                    width:  '100px',
                    data: 'available_total',
                    className: 'price'
                }
            ]
        });

        sejowoo_table.on('preXhr',function(){
            sejowoo.helper.blockUI('.sejowoo-table-holder');
        });

        sejowoo_table.on('xhr',function(){
            sejowoo.helper.unblockUI('.sejowoo-table-holder');
        });

        $(document).on('click', '.toggle-search', function(){
            $('.sejowoo-form-filter-holder').toggle();
        });

        $(document).on('click', '.do-search', function(){
            sejowoo.helper.filterData();
            sejowoo_table.ajax.reload();
            $('.sejowoo-form-filter-holder').hide();
        });

        $(document).on('click', '.export-csv', function(){

            sejowoo.helper.filterData();
            $('<form action="' + sejowoo_admin.wallet.export.ajaxurl + '" method="POST">')
                .append($('<input />').attr('type', 'hidden').attr('name', 'filter').val(sejowoo.var.search))
                .append($('<input />').attr('type', 'hidden').attr('name', 'nonce').val(sejowoo_admin.wallet.export.nonce))
                .appendTo($(document.body))
                .submit()
        });

    });
})(jQuery);
</script>
<script id='user-detail' type="text/x-jsrender">
<a type='button' class='ui mini button' href='{{:detail_url}}' target='_blank'><?php _e('DETAIL', 'sejowoo'); ?></a> {{:display_name}}
<div style='line-height:220%'>
    <span class="ui purple label"><i class="envelope icon"></i>{{:email}}</span>
</div>
</script>
