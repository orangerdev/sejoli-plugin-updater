<?php
    $date = date('Y-m-d', strtotime('-30day')) . ' - ' . date('Y-m-d');
?>
<div class="wrap">
    <h1 class="wp-heading-inline">
        <?php printf(__('Detil Wallet User : %s', 'sejowoo'), $user->get_display_name()); ?>
	</h1>
    <div class="sejowoo-table-wrapper">
        <div class='sejowoo-form-action-holder'>

            <div class="sejowoo-form-filter box" style='float:right;'>
                <button type="button" name="button" class='export-csv button'><?php _e('Export CSV', 'sejowoo'); ?></button>
                <button type="button" name="button" class='button toggle-search'><?php _e('Filter Data', 'sejowoo'); ?></button>
                <div class="sejowoo-form-filter-holder sejowoo-form-float">
                    <input type="text" class='filter' name="date-range" value="<?php echo $date; ?>" placeholder="<?php _e('Pencarian berdasarkan tanggal', 'sejowoo'); ?>">
                    <!--<select class="autosuggest filter" name="product_id"></select>-->
                    <select class="autosuggest filter" name='type'>
                        <option value=''><?php _e('Pilih tipe poin', 'sejowoo'); ?></option>
                        <option value='in'><?php _e('Poin masuk', 'sejowoo'); ?></option>
                        <option value='out'><?php _e('Poin keluar', 'sejowoo'); ?></option>
                    </select>
                    <button type="button" name="button" class='button button-primary do-search'><?php _e('Cari Data', 'sejowoo'); ?></button>
                    <!-- <button type="button" name="button" class='button button-primary reset-search'><?php _e('Reset Pencarian', 'sejowoo'); ?></button> -->
                </div>
            </div>
        </div>
        <div class="sejowoo-table-holder">
            <table id="sejowoo-wallet" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th><?php _e('Tgl', 'sejowoo'); ?></th>
                        <th><?php _e('Detil', 'sejowoo'); ?></th>
                        <th><?php _e('Poin', 'sejowoo'); ?></th>
                        <th><?php _e('Tipe', 'sejowoo'); ?></th>
                        <th><?php _e('Status', 'sejowoo'); ?></th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
                <tfoot>
                    <tr>
                        <th><?php _e('Tgl', 'sejowoo'); ?></th>
                        <th><?php _e('Detil', 'sejowoo'); ?></th>
                        <th><?php _e('Poin', 'sejowoo'); ?></th>
                        <th><?php _e('Tipe', 'sejowoo'); ?></th>
                        <th><?php _e('Status', 'sejowoo'); ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
<script type="text/javascript">

let sejowoo_table;

(function( $ ) {
	'use strict';
    $(document).ready(function() {

        /**
        sejowoo.helper.select_2(
            "select[name='product_id']",
            sejowoo_admin.product.select.ajaxurl,
            sejowoo_admin.product.placeholder
        );**/

        sejowoo.helper.daterangepicker("input[name='date-range']");

        sejowoo.helper.filterData();

        sejowoo_table = $('#sejowoo-wallet').DataTable({
            language: dataTableTranslation,
            searching: false,
            processing: false,
            serverSide: true,
            ajax: {
                type: 'POST',
                url: sejowoo_admin.wallet.single_table.ajaxurl,
                data: function(data) {

                    data.__sejowoo_ajax = 'single-wallet-table';
                    data.nonce = sejowoo_admin.wallet.single_table.nonce;
                    data.user_id = sejowoo_admin.wallet.single_table.user_id;
                    data.backend  = true;
                }
            },
            pageLength : 50,
            lengthMenu : [
                [50, 100, 200],
                [50, 100, 200],
            ],
            order: [
                [ 0, "desc" ]
            ],
            columnDefs: [
                {
                    targets: [1, 2, 3],
                    orderable: false
                },{
                    targets: 0,
                    width: '80px',
                    data : 'created_at',
                    className: 'center'
                },{
                    targets: 1,
                    data: 'detail',
                },{
                    targets: 2,
                    width: '80px',
                    data : 'point',
                    className: 'center'
                },{
                    targets: 3,
                    width: '80px',
                    data : 'refundable',
                    className: 'center',
                    render: function(data, meta, full) {
                        if('out' === full.type) {
                            return '-';
                        } else if( true === data ) {
                            return '<label class="ui blue label"><?php _e('Cash', 'sejowoo'); ?></label>';
                        } else {
                            return '<label class="ui purple label"><?php _e('Poin', 'sejowoo'); ?></label>';
                        }
                    }
                },{
                    targets: 4,
                    width:  '80px',
                    data: 'type',
                    className: 'center',
                    render: function(data) {
                        if('in' === data) {
                            return '<label class="ui green label"><?php _e('Tambah', 'sejowoo'); ?></label>';
                        } else {
                            return '<label class="ui yellow label"><?php _e('Kurang', 'sejowoo'); ?></label>';
                        }
                    }
                }
            ]
        });

        sejowoo_table.on('preXhr',function(){
            sejowoo.helper.blockUI('.sejowoo-table-holder');
        });

        sejowoo_table.on('xhr',function(){
            sejowoo.helper.unblockUI('.sejowoo-table-holder');
        });

        $(document).on('click', '.toggle-search', function(){
            $('.sejowoo-form-filter-holder').toggle();
        });

        $(document).on('click', '.do-search', function(){
            sejowoo.helper.filterData();
            sejowoo_table.ajax.reload();
            $('.sejowoo-form-filter-holder').hide();
        });


        $(document).on('click', '.export-csv', function(){
            sejowoo.helper.filterData();

            $('<form action="' + sejowoo_admin.wallet.single_export.ajaxurl + '" method="POST">')
                .append($('<input />').attr('type', 'hidden').attr('name', 'filter').val(sejowoo.var.search))
                .append($('<input />').attr('type', 'hidden').attr('name', 'user_id').val(sejowoo_admin.wallet.single_table.user_id))
                .append($('<input />').attr('type', 'hidden').attr('name', 'nonce').val(sejowoo_admin.wallet.single_export.nonce))
                .appendTo($(document.body))
                .submit()
        });

    });
})(jQuery);
</script>
