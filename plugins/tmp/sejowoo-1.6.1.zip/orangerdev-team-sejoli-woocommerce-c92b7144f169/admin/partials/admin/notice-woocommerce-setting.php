<div class="notice notice-error">
    <h2><?php _e('Harap dicek kembali pengaturan pada WooCommerce', 'sejowoo'); ?></h2>

    <?php if( 'no' !== $guest_checkout ) : ?>
    <p><?php _e('Nonaktifkan pengaturan pada <i>Allow customers to place orders without an account</i>', 'sejowoo'); ?></p>
    <?php endif; ?>

    <?php if( 'yes' !== $login_reminder ) : ?>
    <p><?php _e('Aktifkan pengaturan pada <i>Allow customers to log into an existing account during checkout</i>', 'sejowoo'); ?></p>
    <?php endif; ?>

    <?php if( 'yes' !== $enable_signup ) : ?>
        <p><?php _e('Aktifkan pengaturan pada <i>Allow customers to create an account during checkout</i>', 'sejowoo'); ?></p>
    <?php endif; ?>

    <p>
        <a href="<?php echo admin_url('admin.php?page=wc-settings&tab=account'); ?>" class='button'><?php _e('Cek Pengaturan', 'sejowoo'); ?></a>
    </p>
</div>
