<div class="notice notice-error">
    <h2><?php _e('WooCommerce belum terinstall', 'sejowoo'); ?></h2>
    <p>
        <?php _e('Agar plugin <strong>Sejoli</strong> bisa bekerja, anda harus menginstall plugin WooCommerce.', 'sejowoo'); ?>
    </p>
</div>
