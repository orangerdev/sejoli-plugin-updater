<?php

    echo woocommerce_wp_checkbox( array(
        'id'            => 'enable_shipping_cost_reduction',
        'wrapper_class' => '',
        'label'         => __('Subsidi ongkos kirim', 'sejowoo' ),
        'description'   => __('Dengan mengaktifkan fitur ini, maka buyer akan mendapatkan subsidi ongkos kirim', 'sejowoo' ),
    ), $coupon->get_meta('enable_shipping_cost_reduction', true));

    echo woocommerce_wp_text_input(
        array(
            'id'          => 'shipping_cost_reduction_percentage',
            'label'       => __( 'Persentasi subsidi', 'sejowoo' ),
            'placeholder' => wc_format_localized_price( 0 ),
            'data_type'   => 'decimal',
            'value'       => $coupon,
            'description' => __('Nilai subsidi dari ongkos kirim berupa persentase', 'sejowoo' ),
            'value'       => absint( $coupon->get_meta("shipping_cost_reduction_percentage", true))
        )
    );

    echo woocommerce_wp_text_input(
        array(
            'id'          => 'shipping_cost_reduction_amount',
            'label'       => __( 'Maksimal subsidi', 'sejowoo' ),
            'placeholder' => wc_format_localized_price( 0 ),
            'data_type'   => 'price',
            'value'       => absint( $coupon->get_meta("shipping_cost_reduction_amount", true)),
            'description' => __('Nilai subsidi dari ongkos kirim', 'sejowoo' )
        )
    );

    echo woocommerce_wp_text_input(
        array(
            'id'          => 'shipping_cost_reduction_term',
            'label'       => __( 'Minimal Belanja', 'sejowoo' ),
            'placeholder' => wc_format_localized_price( 0 ),
            'data_type'   => 'price',
            'value'       => absint( $coupon->get_meta("shipping_cost_reduction_term", true)),
            'description' => __('Nilai minimal pembelanjaan untuk klaim subsidi ongkos kirim. Jika nilainya 0, maka subsidi ongkos kirim tidak aktif', 'sejowoo' )
        )
    );
