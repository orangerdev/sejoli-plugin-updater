<div id="sejowoo_affiliate_fields" class="panel woocommerce_options_panel">
    <div class="options_group">
    <?php
        if( 0 === $post->post_parent ) :
            echo woocommerce_wp_checkbox( array(
            		'id'            => 'enable_affiliate_use',
            		'wrapper_class' => '',
            		'label'         => __('Kupon Affiliasi', 'sejowoo' ),
            		'description'   => __('Dengan mengaktifkan fitur ini, maka affiliasi bisa membuat kupon turunan dari kupon ini', 'sejowoo' )
            ), $coupon->get_meta('enable_affiliate_use', true));
        else :
            $coupon_code = wc_get_coupon_code_by_id( $post->post_parent );
        ?>
        <p>
            <?php
                printf(
                    __("Kupon ini merupakan kupon affiliasi dari <a href=\"%s\">%s</a>", "sejowoo"),
                    admin_url(
                        add_query_arg(
                            array(
                                "post"   => $post->post_parent,
                                "action" => "edit"
                            ),
                            "post.php"
                        )
                    ),
                    $coupon_code
                );
            ?>
        </p>
        <?php
        endif;
    ?>
    </div>
</div>
