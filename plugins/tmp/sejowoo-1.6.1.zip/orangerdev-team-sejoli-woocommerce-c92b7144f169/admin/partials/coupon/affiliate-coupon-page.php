<div class="wrap">
    <h1><?php _e("Tambah Kupon Affiliasi Baru", "sejowoo"); ?></h1>
    <form id="createuser" method="post">
        <table class="form-table" role="presentation">
            <tbody>
                <tr class="form-field form-required">
                    <th scope="row">
                        <label for="parent-coupon">
                            <?php _e("Kupon Utama", "sejowoo"); ?>
                        </label>
                    </th>
                    <td>
                        <?php
                            echo woocommerce_form_field(
                                'parent-coupon',
                                array(
                                    'type'     => 'select',
                                    'label'    => false,
                                    'required' => true,
                                    'options'  => array(
                                                    ''  => __('Sistem sedang mengambil kupon yang tersedia...', 'sejowoo')
                                                 )
                                )
                            );
                        ?>
                    </td>
                </tr>
                <tr class="form-field form-required">
                    <th scope="row">
                        <label for="affiliate-user">
                            <?php _e("Affiliasi", "sejowoo"); ?>
                        </label>
                    </th>
                    <td>
                        <?php
                            echo woocommerce_form_field(
                                'affiliate-user',
                                array(
                                    'type'     => 'select',
                                    'label'    => false,
                                    'required' => true,
                                    'options'  => array(
                                                    ''  => __('Ketik beberapa huruf untuk mencari user', 'sejowoo')
                                                 )
                                )
                            );
                        ?>
                    </td>
                </tr>
                <tr class="form-field form-required">
                    <th scope="row">
                        <label for="affiliate-coupon">
                            <?php _e("Kupon", "sejowoo"); ?>
                        </label>
                    </th>
                    <td>
                        <input name="affiliate-coupon" type="text" id="affiliate-coupon" value="" required />
                    </td>
                </tr>
            </tbody>
        </table>
        <p class="submit">
            <?php wp_nonce_field( "sejowoo-create-affiliate-coupon", "sejoli-nonce"); ?>
            <button type="submit" class="button button-primary">
                <?php _e("Tambah Kupon", "sejowoo"); ?>
            </button>
        </p>
    </form>
</div>
<script type="text/javascript">
(function( $ ) {

	'use strict';

    let sejowoo_coupon, sejowoo_affiliate;

    let updateCouponOptions = function() {

        $.ajax({
            url:      "<?php echo $get_main_coupon_url ?>",
            type:     'GET',
            dataType: 'json',
            success:  function(response) {

                response.forEach(function(i, el){
                    let option = new Option( response[el].text, response[el].id, true, true);
                    sejowoo_coupon.append(option).trigger('change');
                });

            }
        });
    }

    let updateAffiliateOptions = function() {

        $.ajax({
            url:      "<?php echo $get_affiliate_menu_url ?>",
            type:     'GET',
            dataType: 'json',
            success:  function(response) {

                response.forEach(function(i, el){
                    let option = new Option( response[el].text, response[el].id, true, true);
                    sejowoo_affiliate.append(option).trigger('change');
                });

            }
        });
    }

    $(document).ready(function() {

        sejowoo_coupon = $('#parent-coupon').select2();
        sejowoo_affiliate = $('#affiliate-user').select2({
            ajax: {
                url: "<?php echo $get_affiliate_menu_url ?>",
                dataType: 'json',
                minimumInputLength: 2,
                data: function(params) {
                    var query = {
                        search: params.term,
                        type: 'public'
                    }

                    return query
                }
            }
        });

        updateCouponOptions();

    });

})( jQuery );
</script>
