<script type="text/javascript">

    jQuery(document).on('click', '.update-affiliate-coupon', function(){

        let button = jQuery(this),
            couponID = button.val();

        jQuery.ajax({
            url:      '<?php echo admin_url('admin-ajax.php'); ?>',
            type:     'POST',
            dataType: 'json',
            data:     {
                id:     couponID,
                action: 'sejowoo-update-affiliate-coupons',
                nonce:  '<?php echo wp_create_nonce('sejowoo-update-affiliate-coupons'); ?>'
            },
            beforeSend: function() {
                button.attr('disabled', true).text('Updating...');
            },
            success: function(response) {
                alert(response.message);
                location.reload();
            }

        });

        return false;
    });


</script>
