<script type="text/javascript">
(function( $ ){

    'use strict';

    $(document).ready(function(){
        let code = 	"<script type='text/javascript' src='<?php echo home_url('sejowoo-social-proof/'); ?>'>";

        $("textarea[name='carbon_fields_compact_input[_social_proof_code]']").val(code + "<\/script>");
    });
})(jQuery);
</script>
