<!-- REQUEST-MODAL-CONTENT -->
<script id='request-data-modal-content' type="text/x-jsrender">
<i class="close icon"></i>
<div class="header">
    <?php _e('Detil Permintaaan Pencairan Dana', 'sejowoo'); ?>
</div>
<div class="content">
    <div class="ui divided selection list">
        <div class="item">
            <span class="ui large main blue horizontal label"><?php _e('Tanggal', 'sejowoo'); ?></span>
            {{:date}}
        </div>
        <div class="item">
            <span class="ui large main blue horizontal label"><?php _e('User', 'sejowoo'); ?></span>
            {{:user_name}}
            <span class='ui grey label'><i class="mobile icon"></i>{{:user_phone}}</span>
            <span class='ui grey label'><i class="phone icon"></i>{{:user_email}}</span>
        </div>
        <div class="item">
            <span class="ui large main blue horizontal label"><?php _e('Jumlah Pencairan', 'sejowoo'); ?></span>
            {{:amount}}
        </div>
        <div class="item">
            <span class="ui large main blue horizontal label"><?php _e('Bank Pencairan', 'sejowoo'); ?></span>
            {{:bank_name}}
        </div>
        <div class="item">
            <span class="ui large main blue horizontal label"><?php _e('Nomor Rekening', 'sejowoo'); ?></span>
            {{:bank_account}}
        </div>
        <div class="item">
            <span class="ui large main blue horizontal label"><?php _e('Pemilik Rekening', 'sejowoo'); ?></span>
            {{:bank_account_name}}
        </div>
        <div class="item">
            <span class="ui large main blue horizontal label"><?php _e('KTP / SIM Card', 'sejowoo'); ?></span>
            <a href='{{:id_url}}' target='_blank'>{{:id_url}}</a>
        </div>
        {{if admin }}
        <div class="item">
            <span class="ui large main blue horizontal label"><?php _e('Diproses oleh', 'sejowoo'); ?></span>
            {{:admin}}
        </div>
        <div class="item">
            <span class="ui large main blue horizontal label"><?php _e('Tanggal Proses', 'sejowoo'); ?></span>
            {{:updated_date}}
        </div>
        {{/if}}
        {{if proof}}
        <div class="item">
            <span class="ui large main blue horizontal label"><?php _e('Bukti', 'sejowoo'); ?></span>
            <a href='{{:proof}}' target='_blank'>{{:proof}}</a>
        </div>
        {{/if}}
        {{if note}}
        <div class="item">
            <span class="ui large main blue horizontal label"><?php _e('Catatan', 'sejowoo'); ?></span>
            {{:note}}
        </div>
        {{/if}}
    </div>
</div>
{{if form}}
<div class="content">
    <form class="ui divided selection list" id='update-request-data-form' type='POST' action=''>
        <div class="item field">
            <span class="ui large main blue horizontal label"><?php _e('Bukti Transfer', 'sejowoo'); ?></span>
            <input id='proof' type="file" name='proof' />
        </div>
        <div class="item field">
            <span class="ui large main blue horizontal label"><?php _e('Status', 'sejowoo'); ?></span>
            <select id='status' name='status'>
                <option value=""><?php _e('Pilihan status', 'sejowoo'); ?></option>
                <option value='rejected'><?php _e('Permintaan ditolak', 'sejowoo'); ?></option>
                <option value='approved'><?php _e('Permintaan dikirim', 'sejowoo'); ?></option>
            </select>
        </div>
        <div class="item field">
            <span class="ui large main blue horizontal label"><?php _e('Catatan', 'sejowoo'); ?></span>
            <textarea name='note' placeholder='<?php _e('Bisa diisi dengan informasi pengiriman dan lain-lain', 'sejowoo'); ?>'></textarea>
        </div>
        <div class="item field action">
            <input type='hidden' name='ID' value='{{:id}}' />
            <?php wp_nonce_field( 'sejowoo-update-request-fund-status', 'nonce' ); ?>
            <button type='submit' class='ui button' data-id='{{:id}}'><?php _e('Update Permintaan Pencairan', 'sejowoo'); ?></button>
        </div>
    </form>
</div>
<div id='request-data-message' class="ui message" style='display:none;'>
    <div class="header"><?php _e('You must register before you can do that!', 'sejowoo'); ?></div>
    <div class="content"><?php _e('Visit our registration page, then try again', 'sejowoo'); ?></div>
</div>
{{/if}}
</script>

<script type="text/javascript">
(function($){

    'use strict';

    $(document).on('submit', '#update-request-data-form', function(){
        let confirmed = confirm(sejowoo_admin.request_fund.update.confirm);

        if(confirmed) {

            let formData = new FormData($(this)[0]),
                message = $('#request-data-message');

            $.ajax({
                url:         sejowoo_admin.request_fund.update.ajaxurl,
                data:        formData,
                cache:       false,
                contentType: false,
                processData: false,
                dataType:    'json',
                type:        'POST',
                beforeSend: function() {
                    sejowoo.helper.blockUI('#update-request-data-form')
                    $('#request-data-message').removeClass('error success').hide();
                },
                success:    function(response) {

                    if( false != response.valid ) {
                        message.addClass('success').show();
                        message.find('.header').html('<?php _e('Permintaan Pencarian Berhasil Diupdate', 'sejowoo'); ?>');
                        message.find('.content').html(response.message);

                        setTimeout( function(){
                            sejowoo.helper.filterData();
                            sejowoo_table.ajax.reload();
                            sejowoo.helper.unblockUI('#update-request-data-form');
                        }, 100);

                        setTimeout( function(){
                            $('.modal-holder').modal('hide').html('');
                        }, 1000);
                    } else {
                        message.addClass('error').show();
                        message.find('.header').html('<?php _e('Ada kesalahan', 'sejowoo'); ?>');
                        message.find('.content').html(response.message);
                        sejowoo.helper.unblockUI('#update-request-data-form');
                    }
                }
            });

        }

        return false;
    });

})(jQuery);
</script>
