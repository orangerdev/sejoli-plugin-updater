<div class="wrap">
    <h1 class="wp-heading-inline">
        <?php _e('Permintaan Pencairan Dana', 'sejowoo'); ?>
	</h1>
    <div class="sejowoo-table-wrapper">
        <div class='sejowoo-form-action-holder'>

            <div class="sejowoo-form-filter box" style='float:right;'>
                <button type="button" name="button" class='export-csv button'><?php _e('Export CSV', 'sejowoo'); ?></button>
                <button type="button" name="button" class='button toggle-search'><?php _e('Filter Data', 'sejowoo'); ?></button>
                <div class="sejowoo-form-filter-holder sejowoo-form-float">
                    <select class="autosuggest filter" name="user_id"></select>
                    <select class="filter" name="status">
                        <option value=''><?php _e('Pilih status permintaan',    'sejowoo'); ?></option>
                        <option value='requested'><?php _e('Request',           'sejowoo'); ?></option>
                        <option value='rejected'><?php _e('Permintaan ditolak', 'sejowoo'); ?></option>
                        <option value='approved'><?php _e('Permintaan dikirim', 'sejowoo'); ?></option>
                    </select>
                    <?php wp_nonce_field('search-user', 'sejowoo-nonce'); ?>
                    <button type="button" name="button" class='button button-primary do-search'><?php _e('Cari Data', 'sejowoo'); ?></button>
                    <!-- <button type="button" name="button" class='button button-primary reset-search'><?php _e('Reset Pencarian', 'sejowoo'); ?></button> -->
                </div>
            </div>
        </div>
        <div class="sejowoo-table-holder">
            <table id="sejowoo-request-fund" class="display" style="width:100%">
                <thead>
                    <tr>
                        <th><?php _e('Tgl', 'sejowoo'); ?></th>
                        <th><?php _e('User', 'sejowoo'); ?></th>
                        <th><?php _e('Jumlah', 'sejowoo'); ?></th>
                        <th><?php _e('Status', 'sejowoo'); ?></th>
                        <th>&nbsp;</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
                <tfoot>
                    <tr>
                        <th><?php _e('Tgl', 'sejowoo'); ?></th>
                        <th><?php _e('User', 'sejowoo'); ?></th>
                        <th><?php _e('Jumlah', 'sejowoo'); ?></th>
                        <th><?php _e('Status', 'sejowoo'); ?></th>
                        <th>&nbsp;</th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>

<div class="modal-holder ui modal"></div>

<script type="text/javascript">

let sejowoo_table;

(function( $ ) {
	'use strict';
    $(document).ready(function() {

        sejowoo.helper.select_2(
            "select[name='user_id']",
            sejowoo_admin.user.select.ajaxurl,
            sejowoo_admin.user.placeholder
        );

        sejowoo.helper.filterData();

        sejowoo_table = $('#sejowoo-request-fund').DataTable({
            language: dataTableTranslation,
            searching: false,
            processing: true,
            serverSide: false,
            info: false,
            paging: false,
            ajax: {
                type: 'POST',
                url: sejowoo_admin.request_fund.table.ajaxurl,
                data: function(data) {
                    data.filter = sejowoo.var.search;
                    data.action = 'sejowoo-request-fund-table';
                    data.nonce = sejowoo_admin.request_fund.table.nonce
                    data.backend  = true;
                }
            },
            pageLength : 50,
            lengthMenu : [
                [10, 50, 100, 200],
                [10, 50, 100, 200],
            ],
            order: [
                [ 0, "desc" ]
            ],
            columnDefs: [
                {
                    targets: [1,2,4],
                    orderable: false
                },{
                    targets: 0,
                    width: '100px',
                    data : 'created_at'
                },{
                    targets: 1,
                    data: 'display_name',
                },{
                    targets: 2,
                    width: '100px',
                    data : 'amount',
                    className: 'price'
                },{
                    targets: 3,
                    width:  '100px',
                    data:   'status',
                    class:  'center',
                    render: function(data, type, full) {
                        let tmpl = $.templates('#label-status');
                        return tmpl.render({
                                label:  sejowoo_admin.request_fund.status[full.status].text,
                                color:  sejowoo_admin.request_fund.status[full.status].color
                            });
                    }
                },{
                    targets: 4,
                    width:  '64px',
                    className: 'price',
                    render: function(data, type, full) {
                        return '<button type="button" class="request-detail-trigger ui mini button" data-id="' + full.ID + '"><?php _e('Detil', 'sejowoo'); ?></button>';
                    }
                }
            ]
        });

        sejowoo_table.on('preXhr',function(){
            sejowoo.helper.blockUI('.sejowoo-table-holder');
        });

        sejowoo_table.on('xhr',function(){
            sejowoo.helper.unblockUI('.sejowoo-table-holder');
        });

        $(document).on('click', '.toggle-search', function(){
            $('.sejowoo-form-filter-holder').toggle();
        });

        $(document).on('click', '.do-search', function(){
            sejowoo.helper.filterData();
            sejowoo_table.ajax.reload();
            $('.sejowoo-form-filter-holder').hide();
        });

        $(document).on('click', '.export-csv', function(){

            sejowoo.helper.filterData();
            $('<form action="' + sejowoo_admin.request_fund.export.ajaxurl + '" method="POST">')
                .append($('<input />').attr('type', 'hidden').attr('name', 'filter').val(sejowoo.var.search))
                .append($('<input />').attr('type', 'hidden').attr('name', 'nonce').val(sejowoo_admin.request_fund.export.nonce))
                .appendTo($(document.body))
                .submit()
        });


        $(document).on('click', '.request-detail-trigger', function(){

            let id = $(this).data('id');

            $.ajax({
                url : sejowoo_admin.request_fund.detail.ajaxurl,
                type : 'GET',
                data : {
                    ID:     id,
                    nonce:  sejowoo_admin.request_fund.detail.nonce
                },
                beforeSend: function() {
                    sejowoo.helper.blockUI('.sejowoo-table-holder');
                },
                success : function(response) {
                    console.log(response);
                    sejowoo.helper.unblockUI('.sejowoo-table-holder');
                    let tmpl = $.templates('#request-data-modal-content'),
                        content = tmpl.render({
                            'id':                response.data.ID,
                            'date':              response.data.created_date,
                            'amount':            response.data.amount,
                            'user_name':         response.data.user_name,
                            'user_phone':        response.data.user_phone,
                            'user_email':        response.data.user_email,
                            'bank_name':         response.data.meta_data.bank_name,
                            'bank_account':      response.data.meta_data.bank_account,
                            'bank_account_name': response.data.meta_data.bank_account_owner,
                            'id_url':            response.data.meta_data.id_card,
                            'status':            response.data.status,
                            'admin':             response.data.admin,
                            'form':              response.data.form,
                            'updated_date':      response.data.updated_date,
                            'proof':             response.data.meta_data.proof,
                            'note':              response.data.meta_data.note
                        });

                    $('.modal-holder').html(content).modal('show');

                }
            });

            return false;
        });
    });
})(jQuery);
</script>

<!-- LABEL STATUS -->
<script id='label-status' type="text/x-jsrender">
<div class="ui horizontal label boxed" style="background-color:{{:color}};">{{:label}}</div>
</script>

<?php

require 'update-form.php';
