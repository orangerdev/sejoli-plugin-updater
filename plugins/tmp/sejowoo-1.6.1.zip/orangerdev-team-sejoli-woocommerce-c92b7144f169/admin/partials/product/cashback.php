<div id="sejowoo-cashback-holder">
    <div class="buttons">
        <button id='sejowoo-cashback-update-button' type="button" class="button button-primary"><?php _e('Update Cashback Produk', 'sejowoo'); ?></button>
    </div>
    <div id='sejowoo-cashback-update-message' class="sejoli-html-message info" style="display:none;">

    </div>
</div>
