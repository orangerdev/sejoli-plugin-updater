<div id="sejowoo-product-price-holder">
    <div class="buttons">
        <button id='sejowoo-product-price-update-button' type="button" class="button button-primary"><?php _e('Update Cashback Produk', 'sejowoo'); ?></button>
    </div>
    <div id='sejowoo-product-price-update-message' class="sejoli-html-message info" style="display:none;">

    </div>
</div>
