<script type="text/javascript">
(function($){

    'use strict';

    $(document).ready(function(){

        let button  = $('#sejowoo-commission-update-button'),
            message = $('#sejowoo-commission-update-message'),
            holder  = $('#sejowoo-commission-holder').parent().parent().parent().parent();

        $(document).on('click', '#sejowoo-commission-update-button', function(){

            $.ajax({
                url:      sejowoo_admin.bulk_update.commission.ajaxurl,
                type:     'POST',
                dataType: 'json',
                data: {
                    nonce:      sejowoo_admin.bulk_update.commission.nonce,
                    categories: $('input[name="carbon_fields_compact_input[_commission_categories]"]').val(),
                    commission: $('select[name="carbon_fields_compact_input[_commission]"]').val()
                },
                beforeSend: function() {
                    message.hide();
                    sejowoo.helper.blockUI( holder );
                },
                success:    function( response ) {

                    message.removeClass('info success error')
                        .html( '<p>' + response.message + '</p>' )

                    if( response.valid ) {
                        message.addClass('success');
                    } else {
                        message.addClass('error');
                    }

                    message.fadeIn();

                    sejowoo.helper.unblockUI( holder );
                }
            });

        });
    });
})(jQuery);
</script>
