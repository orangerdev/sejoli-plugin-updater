<?php
defined('ABSPATH') || exit;


$pad        = str_repeat( '&#8212; ', 0);
$title      = _draft_or_post_title();
$commission = sejowoo_get_commission_product( $post_id );
$cashback   = sejowoo_get_cashback_product( $post_id )

?>
<div class="sejowoo-product-table-management">
    <strong>
    <?php
    if ( current_user_can( 'edit_post', $post->ID ) && 'trash' !== $post->post_status ) :
        printf(
            '<a class="row-title" href="%s" aria-label="%s">%s%s</a>',
            get_edit_post_link( $post->ID ),
            /* translators: %s: Post title. */
            esc_attr( sprintf( __( '&#8220;%s&#8221; (Edit)' ), $title ) ),
            $pad,
            $title
        );
    else :
        printf(
            '<span>%s%s</span>',
            $pad,
            $title
        );
    endif;
    ?>
    </strong>
    <div class="sejowoo-product-detail">

        <?php if( $commission ) : ?>
        <span class='sejowoo label commission'>
        <?php
            printf(
                __('Komisi : <a href="%s">%s</a>', 'sejowoo'),
                get_edit_post_link( $commission->ID ),
                $commission->post_title
            );
        ?>
        </span>
        <?php endif; ?>

        <?php if($cashback) : ?>
        <span class='sejowoo label cashback'>
        <?php
            printf(
                __('Cashback : %s', 'sejowoo'),
                $cashback['label']
            );
        ?>
        </span>
        <?php endif; ?>
    </div>
</div><!-- .sejowoo-product-table-management -->
