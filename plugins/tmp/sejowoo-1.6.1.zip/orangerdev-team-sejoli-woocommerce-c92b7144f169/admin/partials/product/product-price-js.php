<script type="text/javascript">
(function($){

    'use strict';

    $(document).ready(function(){

        let button  = $('#sejowoo-product-price-update-button'),
            message = $('#sejowoo-product-price-update-message'),
            holder  = $('#sejowoo-product-price-holder').parent().parent().parent().parent();

        $(document).on('click', '#sejowoo-product-price-update-button', function(){

            let confirmed = confirm('<?php _e('Anda yakin akan mengubah harga produk? Pastikan anda yakin untuk melakukan hal ini karena tidak akan bisa dikembalikan lagi.', 'sejowoo'); ?>');

            if( !confirmed ) { return; }

            $.ajax({
                url:      sejowoo_admin.bulk_update.product_price.ajaxurl,
                type:     'POST',
                dataType: 'json',
                data: {
                    nonce:         sejowoo_admin.bulk_update.product_price.nonce,
                    categories:    $('input[name="carbon_fields_compact_input[_product_price_categories]"]').val(),
                    product_price: {
                        calculation: $('select[name="carbon_fields_compact_input[_product_price_calculation]"]').val(),
                        value:       $('input[name="carbon_fields_compact_input[_product_price_value]"]').val(),
                        type:        $('select[name="carbon_fields_compact_input[_price_calculation_type]"]').val()
                    },
                },
                beforeSend: function() {
                    message.hide();
                    sejowoo.helper.blockUI( holder );
                },
                success:    function( response ) {

                    message.removeClass('info success error')
                        .html( '<p>' + response.message + '</p>' )

                    if( response.valid ) {
                        message.addClass('success');
                    } else {
                        message.addClass('error');
                    }

                    message.fadeIn();

                    sejowoo.helper.unblockUI( holder );
                }
            });

        });
    });
})(jQuery);
</script>
