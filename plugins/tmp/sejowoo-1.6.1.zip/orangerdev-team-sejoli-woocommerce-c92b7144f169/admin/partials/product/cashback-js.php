<script type="text/javascript">
(function($){

    'use strict';

    $(document).ready(function(){

        let button  = $('#sejowoo-cashback-update-button'),
            message = $('#sejowoo-cashback-update-message'),
            holder  = $('#sejowoo-cashback-holder').parent().parent().parent().parent();

        $(document).on('click', '#sejowoo-cashback-update-button', function(){

            $.ajax({
                url:      sejowoo_admin.bulk_update.cashback.ajaxurl,
                type:     'POST',
                dataType: 'json',
                data: {
                    nonce:      sejowoo_admin.bulk_update.cashback.nonce,
                    categories: $('input[name="carbon_fields_compact_input[_cashback_categories]"]').val(),
                    cashback:   {
                        enabled:    $('input[name="carbon_fields_compact_input[_cashback_enable]"]').is(':checked'),
                        value:      $('input[name="carbon_fields_compact_input[_cashback_value]"]').val(),
                        type:       $('select[name="carbon_fields_compact_input[_cashback_type]"]').val(),
                        refundable: $('input[name="carbon_fields_compact_input[_cashback_refundable]"]').is(':checked'),
                    }
                },
                beforeSend: function() {
                    message.hide();
                    sejowoo.helper.blockUI( holder );
                },
                success:    function( response ) {

                    message.removeClass('info success error')
                        .html( '<p>' + response.message + '</p>' )

                    if( response.valid ) {
                        message.addClass('success');
                    } else {
                        message.addClass('error');
                    }

                    message.fadeIn();

                    sejowoo.helper.unblockUI( holder );
                }
            });

        });
    });
})(jQuery);
</script>
