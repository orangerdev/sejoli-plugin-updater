<div id="sejowoo-commission-holder">
    <div class="buttons">
        <button id='sejowoo-commission-update-button' type="button" class="button button-primary"><?php _e('Update Komisi Produk', 'sejowoo'); ?></button>
    </div>
    <div id='sejowoo-commission-update-message' class="sejoli-html-message info" style="display:none;">

    </div>
</div>
