<?php

namespace Sejowoo\Admin;

/**
 */
class RequestFund {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Set woocommerce log $context
	 * @since 	1.0.0
	 * @var		array
	 */
	protected $log = array(
		'source' => 'sejowoo-request-fund'
	);

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Set local JS variables
	 * Hooked via filter sejowoo/admin/js-localize-data, priority 122
	 * @since 	1.0.0
	 * @param 	array 	$js_vars 	An array of javascript variables
	 * @return 	array
	 */
	public function set_localize_js_var( array $js_vars ) {

		$js_vars['request_fund'] = array(
			'table'	=> array(
				'ajaxurl'	=> add_query_arg(array(
						'action' => 'sejowoo-request-table'
					), admin_url('admin-ajax.php')
				),
				'nonce'	=> wp_create_nonce('sejowoo-render-request-table')
			),
			'detail' => array(
				'ajaxurl'	=> add_query_arg(array(
						'action' => 'sejowoo-get-request-fund-detail'
					), admin_url('admin-ajax.php')
				),
				'nonce'   => wp_create_nonce('sejowoo-get-request-fund-detail')
			),
			'update'	=> array(
				'confirm' 	=> __('Anda yakin akan mengubah status permintaan pencairan dana ini? Aksi tidak akan bisa diubah', 'sejowoo'),
				'ajaxurl'	=> add_query_arg(array(
						'action' => 'sejowoo-update-request-fund'
					), admin_url('admin-ajax.php')
				)
			),
			'status'	=> array(
				'requested'	=> array(
					'text'	=> __('Request', 'sejowoo'),
					'color' => '#f1c40f'
				),
				'rejected'	=> array(
					'text'	=> __('Ditolak', 'sejowoo'),
					'color' => '#e74c3c'
				),
				'approved'	=> array(
					'text'	=> __('Dikirim', 'sejowoo'),
					'color' => '#3498db'
				)
			),
		);

		return $js_vars;
	}

	/**
	 * Register email-handling classes
	 * Hooked via filter woocommerce_email_classes, priority 122
	 * @since 	1.0.0
	 * @param  	array  $email_classes
	 * @return 	array
	 */
	public function register_emails( array $email_classes ) {

		require( SEJOWOO_DIR . 'emails/admin-request-fund.php' );
		require( SEJOWOO_DIR . 'emails/admin-request-fund-processed.php' );
		require( SEJOWOO_DIR . 'emails/user-request-fund.php' );
		require( SEJOWOO_DIR . 'emails/user-request-fund-processed.php' );

		$email_classes['sejowoo-admin-request-fund']           = new \Sejowoo\Email\AdminRequestFund;
		$email_classes['sejowoo-admin-request-fund-processed'] = new \Sejowoo\Email\AdminRequestFundProcessed;
		$email_classes['sejowoo-user-request-fund']            = new \Sejowoo\Email\UserRequestFund;
		$email_classes['sejowoo-user-request-fund-processed']  = new \Sejowoo\Email\UserRequestFundProcessed;

		return $email_classes;
	}

	/**
	 * Set if current page is all related wallet page
	 * Hooked via filter sejowoo/admin/is-sejowoo-page, priority 122
	 * @since 	1.0.0
	 * @param 	boolean 	$is_sejowoo_page 	Set if current page is sejowoo page
	 * @return 	boolean
	 */
	public function set_needed_scripts( $is_sejowoo_page ) {

		global $pagenow;

		if(
			'admin.php' === $pagenow &&
			isset( $_GET['page'] ) &&
			in_array(
				$_GET['page'],
				array( 'sejowoo-request-fund-management' )
			)
		) :
			return true;
		endif;

		return $is_sejowoo_page;

	}

	/**
	 * Add requet-fund submenu under wallet
	 * Hooked via action admin_menu, priority 122
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function register_admin_menu() {

		add_submenu_page(
			'sejowoo-wallet-management',
			__('Sejowoo Wallet - Permintaan Pencairan Dana', 'sejowoo'),
			__('Pencairan Dana', 'sejowoo'),
			'manage_sejoli_wallet',
            'sejowoo-request-fund-management',
			array($this, 'display_request_fund')
		);

	}

	/**
	 * Display request fund page, called internally
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function display_request_fund() {
		require_once( plugin_dir_path( __FILE__ ) . 'partials/request-fund/page.php' );
	}

	/**
	 * Set data to wallet and request_data table
	 * Hooked via action sejowoo/fund/send-request, priority 5
	 * @since 	1.0.0
	 * @param  	WC_Customer 	$user
	 * @param  	array       	$request_data
	 * @return 	void
	 */
	public function do_request( \WC_Customer $user, array $request_data ) {

		$request_data = sejowoo_add_request_fund_data(array(
			'user_id'   => $user->get_id(),
			'amount'    => $request_data['amount'],
			'meta_data' => $request_data
		));

		$logger = wc_get_logger();

		if( is_wp_error( $request_data ) ) :

			$logger->error(
				sprintf(
					__('Unable to process add request fund data. Messages: %s', 'sejowoo'),
					implode('<br />', $request_data->get_error_messages())
				)
			);

		else :

			$wallet_data = sejowoo_add_wallet_value(array(
				'meta_id'	  => $request_data['ID'],
				'user_id'     => $user->get_id(),
				'refundable'  => true,
				'valid_point' => true,
				'value'       => $request_data['amount'],
				'type'        => 'out',
				'label'       => 'request-fund',
				)
			);

			if( is_wp_error( $wallet_data ) ) :

				$logger->error(
					sprintf(
						__('Unable to process add wallet data for request. Messages: %s', 'sejowoo'),
						implode('<br />', $wallet_data->get_error_messages())
					)
				);

			endif;

		endif;
	}

	/**
	 * Update request fund data
	 * Hooked via action sejowoo/fund/update-request, priority 5
	 * @since 	1.0.0
	 * @param  	WP_User 	$admin
	 * @param  	array   	$request_data
	 * @return 	void
	 */
	public function update_request( \WP_User $admin, array $request_data ) {

		$logger = wc_get_logger();

		$respond = sejowoo_update_request_fund_status( $request_data );

		if( is_wp_error($respond) ) :

			$logger->error(
				sprintf(
					__('Cant update request fund status %s. Reason(s) : %s', 'sejowoo'),
					$request_data['ID'],
					implode(', ', $request_data->get_error_messages() )
				),
				$this->log
			);

		else :

			$logger->info(
				sprintf(
					__('Request fund ID %s status updated to %s by %s', 'sejowoo'),
					$request_data['ID'],
					$request_data['status'],
					$admin->display_name
				),
				$this->log
			);

		endif;

	}

	/**
	 * Set detail info for request fund email
	 * Hooked via action sejowoo/email-content/request-fund, priority 1
	 * @since 	1.0.0
	 * @param 	array 	$request
	 */
	public function set_detail_email_content( array $request ) {

		wc_get_template(
			'request-fund-detail.php',
			array(
				'request'	=> $request
			),
			SEJOWOO_DIR . 'templates/emails/',
			SEJOWOO_DIR . 'templates/emails/'
		);

	}

	/**
	 * Set detail information process for request fund
	 * Hooked via action sejowoo/email-content/info-request-fund, priority 1
	 * @since 	1.0.0
	 * @param 	array 	$request
	 */
	public function set_detail_email_content_for_information_process( array $request ) {

		wc_get_template(
			'request-fund-process-detail.php',
			array(
				'request'	=> $request
			),
			SEJOWOO_DIR . 'templates/emails/',
			SEJOWOO_DIR . 'templates/emails/'
		);

	}

}
