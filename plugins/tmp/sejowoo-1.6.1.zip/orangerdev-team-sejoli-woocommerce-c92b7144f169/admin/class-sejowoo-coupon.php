<?php

namespace Sejowoo\Admin;

class Coupon {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Message keys
	 *
	 * @since	1.0.0
	 * @access 	protected
	 * @var 	array
	 */
	protected $keys;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version     = $version;

		$this->keys = array(
			"no-parent-coupon"    => __("Anda belum memilih kupon utama", "sejowoo"),
			"no-user"             => __("Anda belum memilih affiliasi", "sejowoo"),
			"no-affiliate-coupon" => __("Anda belum mengisi kupon affiliasi", "sejowoo"),
			"coupon-exists"       => __("Kupon affiliasi sudah terdaftar", "sejowoo"),
			"cant-create"		  => __("Tidak bisa membuat kupon", "sejowoo")
		);
	}

	/**
	 * Validate and save new coupon
	 * Hooked via action admin_init, priority 199
	 * @since 	1.6.0
	 * @return	void
	 */
	public function save_new_coupon() {

		global $pagenow;

		$success = 1;

		if(
			"admin.php" === $pagenow &&
			"affiliate-coupon" === $_GET['page'] &&
			isset( $_POST["sejoli-nonce"] ) &&
			wp_verify_nonce( $_POST["sejoli-nonce"], "sejowoo-create-affiliate-coupon" )
		) :
			$keys = array();
			$code = "";

			$post_data = wp_parse_args( $_POST, array(
				"parent-coupon"    => 0,
				"affiliate-user"   => 0,
				"affiliate-coupon" => "",
			));

			if( 0 === absint( $post_data["parent-coupon"] ) ) :
				$success = 0;
				$keys[]  = 'no-parent-coupon';
			endif;

			if( 0 === absint( $post_data["affiliate-user"] ) ) :
				$success = 0;
				$keys[]	 = 'no-user';
			endif;

			if( empty( $post_data["affiliate-coupon"] ) ) :
				$success = 0;
				$keys[]	 = 'no-affiliate-coupon';
			else :

				$coupon_id = wc_get_coupon_id_by_code( $post_data["affiliate-coupon"] );

				if( 0 < $coupon_id) :
					$success = 0;
					$keys[]  = 'coupon-exists';
				endif;

			endif;

			if( 1 === $success ) :

				$new_coupon = sejowoo_create_affiliate_coupon(
					$post_data["affiliate-coupon"],
					absint( $post_data["affiliate-user"] ),
					absint( $post_data["parent-coupon"] )
				);

				wp_update_post( array(
					'ID'          => $new_coupon->get_id(),
					'post_author' => absint( $post_data["affiliate-user"] )
				) );

				if( is_wp_error($new_coupon) ) :
					$success = 0;
					$keys[]  = "cant-create";
				else :
					$code = $post_data["affiliate-coupon"];
				endif;

			endif;

			wp_redirect(
				add_query_arg(
					array(
						"page"    => "affiliate-coupon",
						"success" => $success,
						"keys"    => $keys,
						"code"	  => $code
					),
					admin_url("admin.php")
				)
			);
			exit;
		endif;
	}

	/**
	 * Add affilite coupon creation menu in admin
	 * Hooked via action admin_menu, priority 100
	 * @since 	1.6.0
	 * @return 	void
	 */
	public function add_affiliate_coupon_menu() {

		add_submenu_page(
			"woocommerce-marketing",
			__("Kupon Affiliasi", "sejowoo"),
			__("Kupon Affiliasi", "sejowoo"),
			"manage_sejoli_coupons",
			"affiliate-coupon",
			array( $this, "display_affiliate_coupon")
		);
	}

	/**
	 * Display notice
	 * Hooked via action admin_notices, priority 199
	 *
	 * @since 	1.6.0
	 * @return 	void
	 */
	public function display_notice() {

		global $pagenow, $hook_suffix;

		if(
			"admin.php" === $pagenow &&
			"marketing_page_affiliate-coupon" === $hook_suffix
		) :
			$get_data = wp_parse_args( $_GET, array(
							"success" => "",
							"keys"	  => [],
							"code"	  => ""
						));

			if( "0" === $get_data["success"] ) :

				?>
				<div class="notice notice-error">
					<p>
					<?php
						foreach( $get_data["keys"] as $key ) :
							echo $this->keys[$key] . "<br />";
						endforeach;
					?>
					</p>
				</div>
				<?php

			elseif( "1" === $get_data["success"] ) :

				?>
				<div class="notice notice-success">
					<p>
					<?php
						printf(
							__("Kupon %s telah berhasil dibuat", "sejowoo"),
							strtoupper( $get_data["code"] )
						); ?>
					</p>
				</div>
				<?php

			endif;

		endif;

	}

    /**
     * Add custom field tabs to coupon editor
     * Hooked via filter woocommerce_coupon_data_tabs, priority 100
     * @since 1.0.0
     * @param array $tabs
     */
    public function set_tab_fields( array $tabs ) {
        $tabs['sejowoo-affiliate'] = array(
            'label'  => __( 'Affiliasi', 'sejowoo' ),
            'target' => 'sejowoo_affiliate_fields',
            'class'  => 'sejowoo_affiliate_fields',
        );
        return $tabs;
    }

	/**
	 * Add shipping cost reduction field setting
	 * Hooked via action woocommerce_coupon_options, priority 100
	 * @since 	1.6.0
	 * @param 	integer 	$coupon_id
	 * @param 	WC_Coupon 	$coupon
	 */
	public function add_shipping_cost_reduction_options( $coupon_id, $coupon ) {

		require_once ( SEJOWOO_DIR . 'admin/partials/coupon/shipping-cost-reduction-fields.php' );

	}

    /**
     * Add affiliate setup option for coupon editor
     * Hooked via action woocommerce_coupon_data_panels, priority 100
     * @since   1.0.0
     * @param   integer     $coupon_id
     * @param   WC_Coupon   $coupon
     */
    public function add_affiliate_setup_options( $coupon_id, $coupon ) {

		global $post;

        require_once ( SEJOWOO_DIR . 'admin/partials/coupon/affiliate-fields.php' );

    }

    /**
     * Save coupon meta data
     * Hooked via action woocommerce_coupon_options_save, priority 100
     * @since   1.0.0
     * @since 	1.6.0 		Add shipping cost reduction
     * @param   integer     $post_id
     * @param   WC_Coupon   $coupon
     */
    public function save_meta_data( $post_id, $coupon ) {

        $enable_affiliate_use = ( isset( $_POST['enable_affiliate_use'] ) ) ? sanitize_text_field( $_POST['enable_affiliate_use'] ) : 'no';
		$enable_shipping_cost_reduction = ( isset( $_POST['enable_shipping_cost_reduction'] ) ) ? sanitize_text_field( $_POST['enable_shipping_cost_reduction'] ) : 'no';

        $coupon->update_meta_data( 'enable_affiliate_use', $enable_affiliate_use );
		$coupon->update_meta_data( 'enable_shipping_cost_reduction', $enable_shipping_cost_reduction );
		$coupon->update_meta_data( 'shipping_cost_reduction_percentage', absint( $_POST["shipping_cost_reduction_percentage"] ) );
		$coupon->update_meta_data( 'shipping_cost_reduction_amount', 	 absint( $_POST["shipping_cost_reduction_amount"] ) );
		$coupon->update_meta_data( 'shipping_cost_reduction_term', 	 floatval( $_POST["shipping_cost_reduction_term"] ) );
        $coupon->save();

    }

	/**
	 * Add custom columns to shop_coupon columns
	 * Hooked via filter manage_edit-shop_coupon_columns, priority 100
	 * @since 	1.0.0
	 * @param 	array 	$columns
	 * @return 	array
	 */
	public function add_custom_columns( $columns ) {

		$columns['affiliate'] = __('Affiliasi', 'sejowoo');

		return $columns;
	}

	/**
	 * Display custom columns value to shop_coupon
	 * Hooked via action manage_shop_coupon_posts_custom_column, priority 100
	 * @since 	1.0.0
	 * @param  	string 	$column
	 * @param  	integer $post_id
	 */
	public function display_custom_column_values( $column, $post_id ) {

		global $post;

		switch( $column ) :

			case 'affiliate' :

				if(0 === $post->post_parent) :
					?><button type='button' class='button update-affiliate-coupon' value='<?php echo $post_id; ?>'><?php _e('Update', 'sejowoo'); ?></button<?php
				else :
					$user = get_user_by('id', $post->post_author);
					echo $user->display_name;
				endif;
				break;

		endswitch;
	}

	/**
	 * Register needed CSS and JS files
	 * Hooked via action admin_enqueue_scripts, priority 199
	 * @since 	1.6.0
	 * @return 	void
	 */
	public function register_needed_css_and_js_files() {

		global $pagenow, $hook_suffix;

		if(
			"admin.php" === $pagenow &&
			"marketing_page_affiliate-coupon" === $hook_suffix
		) :

			wp_enqueue_style ( "select2" );
			wp_enqueue_script( "selectWoo" );

		endif;
	}

	/**
	 * Display affiliate coupon creation page
	 * Called internally from
	 * @since 	1.6.0
	 * @return 	void
	 */
	public function display_affiliate_coupon() {

		$get_main_coupon_url = add_query_arg(array(
								'nonce' => wp_create_nonce('sejowoo-get-parent-coupon-list'),
							   ), site_url('sejowoo-ajax/get-parent-coupon-list'));

	   	$get_affiliate_menu_url = add_query_arg(array(
								'nonce' => wp_create_nonce('sejowoo-get-affiliate-user-list'),
							), admin_url('admin-ajax.php?action=sejowoo-get-affiliate-user-list'));

		require_once ( SEJOWOO_DIR . 'admin/partials/coupon/affiliate-coupon-page.php' );

	}

	/**
	 * Add custom JS script in shop_coupon page
	 * Hooked via action admin_footer, priority 100
	 * @since 1.0.0
	 */
	public function add_js_script() {

		global $pagenow, $typenow;

		if( 'edit.php' === $pagenow && SEJOWOO_COUPON_CPT === $typenow ) :
			require_once SEJOWOO_DIR . 'admin/partials/coupon/manage-js-script.php';
		endif;
	}
}
