<?php

namespace Sejowoo\Admin;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

class Commission {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Commission options
	 * @since 	1.1.2.1
	 * @var 	false|array
	 */
	protected $options = false;

	/**
	 * Setup a silent mode, without any effect to database
	 * @since	1.1.3
	 * @var 	boolean
	 */
	protected $is_silenced = false;

	/**
	 * Set woocommerce log $context
	 * @since 	1.0.0
	 * @var		array
	 */
	protected $log = array(
		'source' => 'sejowoo-commission'
	);

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

    /**
     * Register commission post type
     * Hooked via action init, priority 100
     * @since   0.1.0
     * @return  void
     */
    public function register_post_type() {

		if( ! sejowoo_is_woocommerce_active() || false === sejowoo_check_own_license() ) :
			return;
		endif;

        $labels = [
    		'name'               => _x( 'Commission', 'post type general name', 'sejowoo' ),
    		'singular_name'      => _x( 'Commission', 'post type singular name', 'sejowoo' ),
    		'menu_name'          => _x( 'Commission', 'admin menu', 'sejowoo' ),
    		'name_admin_bar'     => _x( 'Commission Setup', 'add new on admin bar', 'sejowoo' ),
    		'add_new'            => _x( 'Add New Commission Setup', 'commission', 'sejowoo' ),
    		'add_new_item'       => __( 'Add New Commission Setup', 'sejowoo' ),
    		'new_item'           => __( 'New Commission Setup', 'sejowoo' ),
    		'edit_item'          => __( 'Edit Commission Setup', 'sejowoo' ),
    		'view_item'          => __( 'View Commission Setup', 'sejowoo' ),
    		'all_items'          => __( 'All Commission Setup', 'sejowoo' ),
    		'search_items'       => __( 'Search Commission', 'sejowoo' ),
    		'parent_item_colon'  => __( 'Parent Commission:', 'sejowoo' ),
    		'not_found'          => __( 'No commission setup found.', 'sejowoo' ),
    		'not_found_in_trash' => __( 'No commission setup found in Trash.', 'sejowoo' )
    	];

    	$args = [
    		'labels'             => $labels,
            'description'        => __( 'Description.', 'sejowoo' ),
    		'public'             => true,
    		'publicly_queryable' => false,
    		'show_ui'            => true,
    		'show_in_menu'       => true,
			'rewrite'            => [ 'slug' => 'sejowoo-commission' ],
    		'query_var'          => true,
    		'capability_type'    => 'post',
			'capabilities'		 => array(
				'publish_posts'      => 'publish_sejowoo_commissions',
				'edit_posts'         => 'edit_sejowoo_commissions',
				'edit_others_posts'  => 'edit_others_sejowoo_commissions',
				'read_private_posts' => 'read_private_sejowoo_commissions',
				'edit_post'          => 'edit_sejowoo_commission',
				'delete_posts'       => 'delete_sejowoo_commission',
				'read_post'          => 'read_sejowoo_commission'
			),
    		'has_archive'        => false,
    		'hierarchical'       => false,
    		'menu_position'      => 36,
    		'supports'           => [ 'title' ],
			'menu_icon'			 => ! defined('zshop') ? plugin_dir_url( __FILE__ ) . 'images/icon.png' : NULL
    	];

    	register_post_type( SEJOWOO_COMMISSION_CPT, $args );
    }

    /**
     * Modify admin column for commission table
     * Hooked via filter manage_sejowoo-commission_posts_columns, priority 100
     * @since   0.1.0
     * @param   array   $columns
     * @return  array
     */
    public function modify_admin_columns($columns) {

        unset($columns['date']);

		$columns['sejowoo-tier']        = __('Jumlah Tier', 'sejowoo');
        $columns['sejowoo-commission']  = __('Komisi', 'sejowoo');

		return $columns;
    }

    /**
	 * Display commission setup data
	 * Hooked via manage_posts_custom_column, priority 100
	 * @since 	1.0.0
	 * @param  	string 		$column
	 * @param  	integer 	$post_id
	 * @return 	void
	 */
	public function display_setup_data($column, $post_id) {

		switch ( $column ) :

			case 'sejowoo-tier' :

                $tiers = count(carbon_get_post_meta($post_id, 'commission'));
                printf( __('%d tier(s)', 'sejowoo'), $tiers);

                break;

            case 'sejowoo-commission' :

                $commissions = carbon_get_post_meta($post_id, 'commission');

                foreach($commissions as $i => $commission) :

                    if('fixed' === $commission['type']) :
                        $value = wc_price($commission['number']);
                    else :
                        $value = $commission['number'] . '%';
                    endif;

                    printf(
                        "<span class='label green'>Tier %s</span> : %s <br />",
                        $i + 1,
                        $value
                    );
                endforeach;

                break;

		endswitch;
	}

    /**
     * Register commission fields
     * Hooked via action carbon_fields_register_fields, priority 100
     * @since   0.1.0
     * @return  void
     */
    public function register_commission_fields() {

		if( ! sejowoo_is_woocommerce_active() ) :
			return;
		endif;

        Container::make('post_meta', __('Commission Setup', 'sejowoo'))
            ->where('post_type', '=', SEJOWOO_COMMISSION_CPT)
            ->add_fields(array(
                Field::make('complex', 'commission', __('Commission', 'sejowoo'))
                    ->add_fields(
                        apply_filters('sejowoo/commission/fields', array())

                    )
                    ->set_layout('tabbed-vertical')
                    ->set_header_template(__('Tier', 'sejowoo').' <%- $_index+1 %>'),
            ));

    }

    /**
	 * Setup commission tier fields
	 * Hooked via filter sejoli/commission/fields, priority 1
	 * @since 	0.1.0
	 * @return 	array
	 */
	public function setup_commission_tier_fields() {

		return array(
			'number' => Field::make('text',	'number', sprintf(__('Value (%s)', 'sejowoo'), get_woocommerce_currency_symbol()))
				->set_width(50)
				->set_attribute('type', 'number')
				->set_default_value(0),

			'type' => Field::make('select',	'type',__('Type', 'sejowoo'))
				->set_width(50)
				->set_options([
					'percentage'	=> __('Percentage', 'sejowoo'),
                    'fixed' 		=> __('Value', 'sejowoo'),
				])
		);
	}

	/**
	 * Get all commission as options
	 * Hooked via filter sejowoo/commission/options, priority 100
	 * @since 	0.1.0
	 * @param  	array  $options
	 * @return 	array
	 */
	public function get_as_options($options = array(), $null_options = true) {

		if( false !== $this->options ) :
			return $this->options;
		endif;

		if($null_options) :
			$options[]	= __('No commission', 'sejowoo');
		endif;

		$commissions = \SejoWoo\Database\Post::set_args([
	                    'status'         => 'publish',
	                    'post_type'      => SEJOWOO_COMMISSION_CPT
	                ])
	                ->set_total( 1000 )
	                ->get();

		foreach( (array) $commissions as $commission) :
			$options[$commission->ID]	= $commission->post_title;
		endforeach;

		$this->options = $options;

		return $options;
	}

	/**
	 * Calculate product commission
	 * @since 	1.0.0
	 * @param  	WC_Order_Item_Product  	$item      			Order item
	 * @param  	array  					$commission_setup 	Product ommission setup
	 * @param  	int    					$affiliate_id		Order affiliate ID
	 * @param  	array  					$uplines			An array of uplines based on current order affiliate
	 * @return 	array
	 */
	protected function calculate_product_commission( \WC_Order_Item_Product $item, array $commission_setup, int $affiliate_id, array $uplines ) {

		$commissions = array();


		foreach( $commission_setup as $i => $setup ) :

			$tier = $i + 1;
			$user_id = 0;

			if( 1 === $tier ) :

				$user_id = $affiliate_id;

			elseif( isset( $uplines[$tier - 1] ) ) :

				$user_id = $uplines[$tier - 1];

			endif;

			if( 0 !== $user_id ) :

				if( 'percentage' === $setup['type']) :
					$value = ( floatval( $setup['value'] ) * $item->get_total() ) / 100;
				else :
					$value = floatval( $setup['value'] ) * $item->get_quantity() ;
				endif;

				$commissions[$tier] = array(
					'user_id'    => $user_id,
					'value'      => apply_filters( 'sejowoo/commission/value', $value, $item, $user_id, $tier ),
					'line_total' => $item->get_total()
				);

			endif;

		endforeach;

		return $commissions;
	}

	/**
	 * Calculate commission based on order
	 * Hooked via action woocommerce_checkout_order_created, priority 11
	 * @since 	1.0.0
	 * @since 	1.1.2.1 	Change hook and any parameters
	 * @param  	integer 	$order
	 * @param 	array  		$post_data
	 * @param 	WC_Order 	$order
	 * @return
	 */
	public function calculate_order_commission( \WC_Order $order ) {

		$affiliate_id = intval( $order->get_meta( sejowoo_get_affiliate_key(), true ) );
		$logger       = wc_get_logger();

		if( 0 < $affiliate_id ) :

			$uplines  = sejowoo_user_get_uplines( $affiliate_id );
			$max_tier = absint( apply_filters('sejowoo/commission/max-tier', NULL, $order, $affiliate_id ) );

			// Calculate commission per item
			foreach( (array) $order->get_items() as $item ) :

				$product_id = ( 0 < $item->get_variation_id() ) ? $item->get_variation_id() : $item->get_product_id();

				$product_commission_setup = sejowoo_get_product_commission_setup( $product_id );

				// Ignore if there is no commission setup
				if( !is_array($product_commission_setup) ) :
					continue;
				endif;

				$commissions = $this->calculate_product_commission(
								$item,
								$product_commission_setup,
								$affiliate_id,
								$uplines
							  );

				$commissions = apply_filters( 'sejowoo/commission/data', $commissions, $item, $order, $product_commission_setup, $affiliate_id, $uplines );

				foreach( $commissions as $tier => $data ) :

					$data = wp_parse_args($data, array(
						'value'     => 0,
						'user_id'   => 0,
						'meta_data' => array()
					));

					// ignore with commission 0
					if( 0 >= $data['value'] ) :
						continue;
					endif;

					if(
						0 !== $max_tier &&
						intval($tier) > $max_tier
					) :
						break;
					endif;

					if( true === $this->is_silenced ) :

						__debug(array(
							'order_id'     => $order->get_id(),
							'item_id'      => $item->get_id(),
							'product_id'   => $product_id,
							'buyer_id'     => $order->get_user_id(),
							'affiliate_id' => $data['user_id'],
							'tier'         => $tier,
							'quantity'     => $item->get_quantity(),
							'commission'   => $data['value'],
							'order_status' => $order->get_status(),
							'paid_status'  => false
						));

						continue;
					endif;

					$commission = sejowoo_add_commission_data(array(
						'order_id'     => $order->get_id(),
						'item_id'      => $item->get_id(),
						'product_id'   => $product_id,
						'buyer_id'     => $order->get_user_id(),
						'affiliate_id' => $data['user_id'],
						'tier'         => $tier,
						'quantity'     => $item->get_quantity(),
						'commission'   => $data['value'],
						'order_status' => $order->get_status(),
						'paid_status'  => false
					));

					if( ! is_wp_error($commission) && array_key_exists( 'ID', $commission ) ):

						// add commission value to wallet
						$wallet = sejowoo_add_wallet_value(array(
							'order_id'    => $order->get_id(),
							'item_id'     => $item->get_id(),
							'product_id'  => $product_id,
							'user_id'     => $data['user_id'],
							'refundable'  => true,
							'valid_point' => ( in_array( $order->get_status(), array( 'processing', 'completed' ) ) ) ? true : false,
							'value'       => $data['value'],
							'type'        => 'in',
							'label'       => 'commission',
							'meta_data'   => wp_parse_args($data['meta_data'], array(
								'tier'     => $tier,
								'quantity' => $item->get_quantity()
							))
						));

						if( is_wp_error($wallet) ) :

							$logger->error(
								sprintf(
									__('Cant add wallet data based on commission. Reason(s) : %s', 'sejowoo'),
									$wallet->get_error_message()
								),
								$this->log
							);

						else :

							$logger->info(
								sprintf(
									__('New commission for user ID %s, amount %s based on order ID %s, item ID %s, product ID %s, tier %s, quantity %s', 'sejowoo'),
									$data['user_id'],
									$data['value'],
									$order->get_id(),
									$item->get_id(),
									$product_id,
									$tier,
									$item->get_quantity()
								),
								$this->log
							);

						endif;

					else :

						$logger->error(
							implode(PHP_EOL, $commission->get_error_messages()),
							$this->log
						);

					endif;

				endforeach;

			endforeach;

			$logger->info(
				sprintf(
					__('Calculate commission for order %s and max tier %s done', 'sejowoo'),
					$order->get_id(),
					$max_tier
				),
				$this->log
			);

		else :

			$logger->info(
				sprintf(
					__('Order %s doesn\'t have affiliate value', 'sejowoo'),
					$order->get_id()
				),
				$this->log
			);

		endif;
	}

	/**
	 * Update commission order status and wallet point valid status to invalid
	 * Hooked via action woocommerce_order_status_pending, priority 299
	 * Hooked via action woocommerce_order_status_on-hold, priority 299
	 * Hooked via action woocommerce_order_status_failed, priority 299
	 * Hooked via action woocommerce_order_status_refunded, priority 299
	 * Hooked via action woocommerce_order_status_cancelled, priority 299
	 * Hooked via action woocommerce_order_status_processing, priority 299
	 * @since 	1.0.0
	 * @param 	integer 	$order_id
	 */
	public function set_commission_status_invalid( int $order_id ) {

		$order = wc_get_order( $order_id );

		sejowoo_update_commission_order_status( $order_id, $order->get_status() );
		sejowoo_update_wallet_point_valid_status( $order_id, false, 'commission' );
	}

	/**
	 * Update commission order status and wallet point valid status to valid
	 * Hooked via action woocommerce_order_status_completed, priority 299
	 * @since 	1.0.0
	 * @param 	integer 	$order_id
	 */
	public function set_commission_status_valid( int $order_id ) {

		$order = wc_get_order( $order_id );

		sejowoo_update_commission_order_status	( $order_id, $order->get_status() );
		sejowoo_update_wallet_point_valid_status( $order_id, true, 'commission' );

		$commissions = sejowoo_get_commissions_from_order($order);

        if( is_array($commissions) && 0 < count($commissions) ) :
            do_action('sejowoo/commission/update-status-valid', $order, $commissions);
        endif;
	}

	/**
	 * Register email for commission notification
	 * Hooked via filter woocommerce_email_classes, priority 100
	 * @since 	1.0.0
	 * @param  	array  $email_classes
	 * @return 	array
	 */
	public function register_email( array $email_classes ) {

		require( SEJOWOO_DIR . 'emails/commission.php' );

		$email_classes['sejowoo-commission-email'] = new \Sejowoo\Email\Commission;

		return $email_classes;
	}

	/**
	 * Simulation a product commission and display it on query monitor only
	 * Hooked via action admin_init, priority 989
	 * @since 	1.1.3
	 * @return 	void
	 */
	public function check_product_commission() {

		if( current_user_can('manage_options') ) :

			$get_data = wp_parse_args($_GET, array(
				'sejoli-action' => NULL,
				'product'       => 0,
				'user-group'    => 0
			));

			if(
				'check-product-commission' === $get_data['sejoli-action'] &&
				!empty($get_data['product'])
			) :

				$product                  = wc_get_product( $get_data['product'] );
				$product_commission_setup = sejowoo_get_product_commission_setup( $product->get_id() );
				$group_commission_setup   = array();

				if(!empty($get_data['user-group'])) :

					$group_detail = sejowoo_get_group_detail($get_data['user-group']);

					$product_id      = $product->get_id();
					$commission_data = array();

					// Check group commission set
					if(
						is_array($group_detail['per_product']) &&
						array_key_exists($product_id, $group_detail['per_product'])
					) :

						$group_commission_setup = array(
							'from'		 => 'per-product',
							'commission' => $group_detail['per_product'][$product_id]['commissions']
						);

					else :

						$group_commission_setup = array(
							'from'       => 'general',
							'commission' => $group_detail['commissions']
						);

					endif;

				endif;

				__debug( array(
					'ID'         => $product->get_id(),
					'name'       => $product->get_name(),
					'commission' => $product_commission_setup,
					'group'		 => $group_commission_setup
				));

			endif;

		endif;

	}

	/**
	 * Simulation an order commission and display it on query monitor only
	 * Hooked via action admin_init, priority 989
	 * @since 	1.1.3
	 * @return 	void
	 */
	public function check_order_commission() {

		if( current_user_can('manage_options') ) :

			$get_data = wp_parse_args($_GET, array(
				'sejoli-action' => NULL,
				'order'         => 0
			));

			if(
				'check-order-commission' === $get_data['sejoli-action'] &&
				!empty($get_data['order'])
			) :

				$this->is_silenced = true;

				$order = wc_get_order( $get_data['order'] );
				$this->calculate_order_commission( $order );

			endif;

		endif;

	}

	/**
	 * Register komisi and affiliasi submenu under Commission menu
	 * Hooked via action admin_menu, priority 100
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function register_admin_submenu() {

		// Register sub menu data komisi
		add_submenu_page(
			'edit.php?post_type=' . SEJOWOO_COMMISSION_CPT,
			__('Data Komisi Per Order', 'sejowoo'),
			__('Data Komisi', 'sejowoo'),
			'manage_sejoli_commissions',
			'sejowoo-commission-data-per-order',
			array($this, 'display_commission_data_per_order'),
			10
		);

	}

	/**
	 * Display commission data per order
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function display_commission_data_per_order() {

	}
}
