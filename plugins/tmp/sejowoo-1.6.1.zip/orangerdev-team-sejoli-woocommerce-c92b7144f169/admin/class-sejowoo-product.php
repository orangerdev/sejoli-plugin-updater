<?php

namespace Sejowoo\Admin;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://ridwan-arifandi.com
 * @since      1.0.0
 *
 * @package    Sejoli
 * @subpackage Sejoli/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Sejoli
 * @subpackage Sejoli/admin
 * @author     Ridwan Arifandi <orangerdigiart@gmail.com>
 */
class Product {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Set local javascript variables
	 * Hooked via filter sejowoo/admin/js-localize-data, priority 1
	 * @since 	1.1.0
	 * @param 	array 	$js_vars
	 * @return 	array
	 */
	public function set_localize_js_var( $js_vars ) {

		$js_vars['product'] = array(
			'options' 	=> array(
				'ajaxurl'     => site_url('sejowoo-ajax/get-product-list'),
				'nonce'       => wp_create_nonce('sejowoo-render-product-options'),
				'placeholder' => __('Pilih produk', 'sejowoo')
			)
		);

		$js_vars['bulk_update'] = array(
			'commission'	=> array(
				'ajaxurl'	=> add_query_arg(array(
									'action'	=> 'bulk-update-commission-product'
							   ),'admin-ajax.php'),
				'nonce'		=> wp_create_nonce( 'bulk-update-commission-product' )
			),
			'cashback'	=> array(
				'ajaxurl'	=> add_query_arg(array(
									'action'	=> 'bulk-update-cashback-product'
							   ),'admin-ajax.php'),
				'nonce'		=> wp_create_nonce( 'bulk-update-cashback-product' )
			),
			'product_price'	=> array(
				'ajaxurl'	=> add_query_arg(array(
									'action'	=> 'bulk-update-product-price'
							   ),'admin-ajax.php'),
				'nonce'		=> wp_create_nonce( 'bulk-update-product-price' )
			)
		);

		return $js_vars;
	}

	/**
	 * Set product categories as array dropdown
	 * @since 	1.1.0
	 * @return 	array
	 */
	public function set_product_categories() {

		$options = array();

		$product_cats = get_terms( 'product_cat', array(
							'hide_empty'	=> false
						));

		foreach( $product_cats as $product_cat ) :
			$options[ $product_cat->term_id ] = $product_cat->name;
		endforeach;

		return $options;
	}

	/**
	 * Set if current product needs to load all sejowoo css and js scripts
	 * Hooked via filter admin_enqueue_scripts. priority 1001
	 * @since	1.0.0
	 * @return 	void
	 */
	public function register_css_and_js_files( ) {

		global $pagenow, $typenow;

		if(
			'edit.php' === $pagenow &&
			'product' === $typenow &&
			isset($_GET['page']) &&
			'crb_carbon_fields_container_update_produk_massal.php' === $_GET['page']
		) :
			wp_enqueue_script 	( 'jquery-blockUI' );
			wp_enqueue_script 	( $this->plugin_name );
			wp_enqueue_style 	( $this->plugin_name.'-carbonfields');
		endif;

		if(
			'edit.php' === $pagenow &&
			'product' === $typenow &&
			isset($_GET['post_type']) &&
			'product' === $_GET['post_type']
		) :
			wp_enqueue_style 	( $this->plugin_name . '-product-table', SEJOWOO_URL . 'admin/css/product-table.css' );

		endif;
	}

    /**
     * Setup carbon field for bulk product options
     * Hooked via action carbon_fields_register_fields, priority 100
     * @since 	1.1.0
     * @return 	void
     */
    public function register_bulk_product_options() {

		ob_start();
		require SEJOWOO_DIR . 'admin/partials/product/commission.php';
		$commission = ob_get_contents();
		ob_end_clean();

		ob_start();
		require SEJOWOO_DIR . 'admin/partials/product/cashback.php';
		$cashback = ob_get_contents();
		ob_end_clean();

		ob_start();
		require SEJOWOO_DIR . 'admin/partials/product/product-price.php';
		$product_price = ob_get_contents();
		ob_end_clean();

		Container::make('theme_options', __('Update Produk Massal', 'sejowoo'))
			->set_page_parent( 'edit.php?post_type=product' )
			->add_tab( __('Komisi', 'sejowoo'), array(

				Field::make('separator', 'sep_bulk_update_commission', __('Update Tipe Komisi', 'sejowoo')),

				Field::make('multiselect', 'commission_categories', __('Pilih Kategori', 'sejowoo'))
					->add_options( array($this, 'set_product_categories') ),

				Field::make('select', 'commission', __('Pilih Tipe Komisi', 'sejowoo'))
					->add_options( apply_filters( 'sejowoo/commission/options', array() ) ),

				Field::make('html', 'commission_update')
					->set_classes( 'button-holder')
					->set_html( $commission )

			))
			->add_tab( __('Cashback', 'sejowoo'), array(

				Field::make('separator', 'sep_bulk_update_cashback', __('Update Nilai Cashback', 'sejowoo')),

				Field::make('multiselect', 'cashback_categories', __('Pilih Kategori', 'sejowoo'))
					->add_options( array($this, 'set_product_categories') ),

				Field::make('checkbox', 'cashback_enable', __('Aktifkan cashback?', 'sejowoo')),

				Field::make('text', 'cashback_value', __('Nilai cashback', 'sejowoo'))
					->set_attribute('type', 'number')
					->set_attribute('min', 0)
					->set_width(50),

				Field::make('select', 'cashback_type', __('Tipe nilai cashback', 'sejowoo'))
					->set_options(array(
						'fixed'      => __('Nilai tetap', 'sejowoo'),
						'percentage' => __('Persentase', 'sejowoo')
					))
					->set_width(50),

				Field::make('checkbox', 'cashback_refundable', __('Cashback bisa dicairkan?', 'sejowoo')),

				Field::make('html', 'cashback_update')
					->set_classes( 'button-holder')
					->set_html( $cashback )

			))
			->add_tab( __('Harga', 'sejowoo'), array(

				Field::make('separator', 'sep_bulk_update_product_price', __('Update Harga Produk', 'sejowoo')),

				Field::make('multiselect', 'product_price_categories', __('Pilih Kategori', 'sejowoo'))
					->add_options( array($this, 'set_product_categories') ),

				Field::make('select', 'product_price_calculation', __('Tipe perubahan harga', 'sejowoo'))
					->add_options( array(
						'reduce'   => __('Kurangi harga', 'sejowoo'),
						'increase' => __('Tambah harga', 'sejowoo')
					)),

				Field::make('text', 'product_price_value', __('Nilai perubahan harga', 'sejowoo'))
					->set_attribute('type', 'number')
					->set_attribute('min', 0)
					->set_default_value(0)
					->set_width( 50 ),

				Field::make('select', 'price_calculation_type', __('Tipe nilai perubahan', 'sejowoo'))
					->set_options(array(
						'fixed'      => __('Nilai tetap', 'sejowoo'),
						'percentage' => __('Persentase', 'sejowoo')
					))
					->set_width( 50 ),

				Field::make('html', 'product_price_update')
					->set_classes( 'button-holder')
					->set_html( $product_price )

			));
    }

    /**
     * Display produk setting fields
     * Hooked via filter sejowoo/general/fields, priority 90
     * @since   1.0.0
     * @param 	array 	$fields
     * @return  array
     */
    public function setup_setting_fields( array $fields ) {

		$fields['product-settings'] = array(
			'title'  => __('Produk', 'sejowoo'),
            'fields' => array(

                Field::make('separator', 'sep_product_settings',    __('Pengaturan Produk', 'sejowoo'))
					->set_classes('sejoli-with-help'),

				Field::make( 'text', 'badge_text', __('Teks yang ditampilkan pada badge', 'sejowoo') )
					->set_default_value('Discount'),

                Field::make( 'select', 'badge_show_precentage', __('Tampilkan nominal persentase (%)', 'sejowoo'))
                    ->set_options(array(
                        0    => __('Tidak', 'sejowoo'),
                        1    => __('Ya', 'sejowoo')
                    ))
                    ->set_width( 34 )
                    ->set_default_value('1'),

            )
        );

		return $fields;
    }

	/**
	 * Set javascript code for bulk update editor
	 * Hooked via action admin_footer, priority 1
	 * @since 	1.0.0
	 */
	public function set_javascript_code() {

		global $pagenow, $typenow;

		if(
			'edit.php' === $pagenow &&
			'product' === $typenow &&
			isset($_GET['page']) &&
			'crb_carbon_fields_container_update_produk_massal.php' === $_GET['page']
		) :
			require SEJOWOO_DIR . 'admin/partials/product/cashback-js.php';
			require SEJOWOO_DIR . 'admin/partials/product/commission-js.php';
			require SEJOWOO_DIR . 'admin/partials/product/product-price-js.php';
		endif;

	}

	/**
	 * Display all-related sejoli product data
	 * Hooked via action manage_posts_custom_column, priority 10
	 * @since 	1.1.0
	 * @param  	string 		$column
	 * @param  	integer 	$post_id
	 * @return 	void
	 */
	public function display_product_detail( $column, $post_id ) {

		global $post;

		if( SEJOWOO_PRODUCT_CPT === $post->post_type && 'name' === $column ) :
			require SEJOWOO_DIR . 'admin/partials/product/product-detail.php';
		endif;
	}

	/**
	 * Add commission field to product setup
	 * Hooked via action woocommerce_product_options_general_product_data, priority 100
	 * @since 	0.1.0
	 * @return 	void
	 */
	public function add_commission_field() {

		woocommerce_wp_select(array(
			'id'            => 'sejowoo_commission',
			'name'          => 'sejowoo_commission',
			'label'         => __('Commission Setup', 'sejowoo'),
			'options'       => apply_filters( 'sejowoo/commission/options', array()),
			'wrapper_class' => 'form-row form-row-full',
		));
	}

	/**
	 * Add commission field to product setup
	 * Hooked via action woocommerce_product_after_variable_attributes, priority 100
	 * @since 	1.1.0
	 * @since 	1.1.1		Fixing issue with variation save data
	 * @return 	void
	 */
	public function add_commission_field_for_variation( $loop, $variation_data, $variation) {

		woocommerce_wp_select(array(
			'id'            => 'sejowoo_commission-' . $loop,
			'name'          => 'sejowoo_commission[' . $loop . ']',
			'label'         => __('Commission Setup', 'sejowoo'),
			'options'       => apply_filters( 'sejowoo/commission/options', array()),
			'value'			=> get_post_meta( $variation->ID, 'sejowoo_commission', true),
			'wrapper_class' => 'form-row form-row-full',
		));
	}

	/**
	 * Save commission field data
	 * Hooked via action woocommerce_process_product_meta, priority 100
	 * @since 	0.1.0
	 * @since 	1.1.0 	Make it simpler without set the product first
	 * @param  	integer $post_id
	 * @return 	void
	 */
	public function save_product_meta( $post_id ) {

		if(isset($_POST['sejowoo_commission'])) :
			update_post_meta($post_id, 'sejowoo_commission', intval($_POST['sejowoo_commission']) );
		endif;

	}

	/**
	 * Save commission field data
	 * Hooked via action woocommerce_save_product_variation, priority 100
	 * @since 	1.1.0 	Fixing with variation issue
	 * @since 	1.1.1 		Fixing issue with variation save
	 * @param  	integer $variation_id
	 * @return 	void
	 */
	public function save_product_variation( $variation_id, $i ) {

		if(isset($_POST['sejowoo_commission'][$i])) :
			update_post_meta($variation_id, 'sejowoo_commission', intval($_POST['sejowoo_commission'][$i]) );
		endif;

	}
}
