<?php

namespace Sejowoo\Admin;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

final class SocialProof {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.5.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.5.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.5.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

    /**
     * Display social proof setting fields
     * Hooked via filter sejowoo/general/fields, priority 90
     * @since   1.0.0
     * @param 	array 	$fields
     * @return  array
     */
    public function setup_setting_fields( array $fields ) {

		$fields['social-proof'] = array(
			'title'  => __('Social Proof', 'sejowoo'),
            'fields' => array(

                Field::make('separator', 'sep_social_proof',    __('Pengaturan Social Proof', 'sejowoo'))
					->set_classes('sejoli-with-help'),

                Field::make('html', 'social_proof_info')
                    ->set_html( __('Fitur social proof ini akan menampilkan popup terkait informasi pembeli produk', 'sejowoo')),

                Field::make( 'checkbox',    'social_proof_enable',              __('Aktifkan social proof', 'sejowoo')),

                Field::make( 'checkbox',    'social_proof_sensor_buyer_name',   __('Rahasiakan nama pembeli', 'sejowoo'))
                    ->set_help_text( __('Nama pembeli akan disensor jika opsi ini diaktifkan', 'sejowoo') ),

                Field::make( 'checkbox',    'social_proof_display_avatar',      __('Tampilkan avatar pembeli', 'sejowoo'))
                    ->set_help_text( __('Jika pembeli sudah pernah mengupload photo di <a href="https://gravatar.com" target="_blank">gravatar.com</a>, maka photo tersebut akan ditampilkan', 'sejowoo') ),

				Field::make( 'checkbox', 	'social_proof_display_product',		__('Tampilkan photo produk', 'sejowoo'))
					->set_help_text( __('Tampilkan photo produk daripada avatar pembeli. Jika mengaktifkan fitur ini, pastikan anda sudah mengupload photo produk pada FEATURED IMAGE', 'sejowoo'))
					->set_conditional_logic(array(
						array(
							'field'	=> 'social_proof_display_avatar',
							'value'	=> false
						)
					)),

				Field::make( 'text',		'social_proof_text',				__('Teks yang ditampilkan pada popup', 'sejowoo') )
					->set_default_value('{{buyer_name}} telah membeli {{product_name}}'),

				Field::make( 'select', 		'social_proof_order_status',		__('Tampilkan data berdasarkan status order', 'sejowoo'))
					->set_options(array(
						'on-hold'	=> __('Menunggu pembayaran', 'sejowoo'),
						'completed'	=> __('Order selesai', 'sejowoo'),
						'both'		=> __('Menunggu pembayaran dan order selesai', 'sejowoo')
					)),

				Field::make( 'select',		'social_proof_position',		__('Posisi social proof popup', 'sejowoo'))
					->set_options(array(
						'top left'      => __('Pojok kiri atas', 'sejowoo'),
						'top center'    => __('Tengah atas', 'sejowoo'),
						'top right'     => __('Pojok kanan atas', 'sejowoo'),
						'bottom left'   => __('Pojok kiri bawah', 'sejowoo'),
						'bottom center' => __('Tengah bawah', 'sejowoo'),
						'bottom right'  => __('Pojok kanan bawah', 'sejowoo')
					)),

                Field::make( 'select',      'social_proof_first',             __('Jeda popup pertama', 'sejowoo'))
                    ->set_options(array(
                        0     => __('Langsung tampil', 'sejowoo'),
                        1000  => __('2 Detik', 'sejowoo'),
                        5000  => __('5 Detik', 'sejowoo'),
                        10000 => __('10 Detik', 'sejowoo')
                    ))
                    ->set_width( 33 ),

                Field::make( 'select',      'social_proof_display',         __('Waktu popup tampil', 'sejowoo'))
                    ->set_options(array(
                        2000    => __('2 Detik', 'sejowoo'),
                        5000    => __('5 Detik', 'sejowoo'),
                        10000   => __('10 Detik', 'sejowoo'),
                    ))
                    ->set_width( 34 ),

				Field::make( 'select',      'social_proof_delay',         __('Jeda antar popup', 'sejowoo'))
                    ->set_options(array(
                        2000    => __('2 Detik', 'sejowoo'),
                        5000    => __('5 Detik', 'sejowoo'),
                        10000   => __('10 Detik', 'sejowoo'),
                    ))
                    ->set_width( 33 ),

				Field::make('textarea',		'social_proof_code',		 __('Kode untuk integrasi dengan web lain', 'sejowoo'))
					->set_default_value('')
					->set_attribute( 'readOnly', true)
					->set_help_text( __('Anda bisa copy code yang diatas dan letakkan di web yang anda gunakan tanpa sejoli. Untuk bisa mendapatkan kode ini, anda sudah SAVE halaman ini terlebih dahulu.', 'sejowoo')),

            )
        );

		return $fields;
    }

	/**
	 * Add JS Code in product editor page
	 * Hooked via action admin_footer, priority 90
	 * @since 	1.5.2
	 * @return 	void
	 */
	public function add_js_code() {

		global $pagenow;

		if(
			'admin.php' === $pagenow &&
			isset($_GET['page']) &&
			'crb_carbon_fields_container_sejoli.php' === $_GET['page']
		) :

			require_once( SEJOWOO_DIR . 'admin/partials/social-proof/js-code.php' );

		endif;

	}

}
