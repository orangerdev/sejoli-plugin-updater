<?php

namespace Sejowoo\Admin;

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://ridwan-arifandi.com
 * @since      1.0.0
 *
 * @package    Sejoli
 * @subpackage Sejoli/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Sejoli
 * @subpackage Sejoli/admin
 * @author     Ridwan Arifandi <orangerdigiart@gmail.com>
 */
class Cashback {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Set woocommerce log $context
	 * @since 	1.0.0
	 * @var		array
	 */
	protected $log = array(
		'source' => 'sejowoo-cashback'
	);

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

	/**
	 * Set cashback configuration setting
	 * Hooked via filter sejowoo/cashback/setting, priority 10
	 * @since 	1.0.0
	 * @param  	array|false 				$cashback_setting
	 * @param  	WC_Order_Item_Product 	$item
	 * @return 	array|false
	 */
	public function set_cashback_setting( $cashback_setting, $item ) {

		if( false === $cashback_setting ) :

			$product = ( is_a( $item, 'WC_Order_Item_Product') ) ? $item->get_product() : $item['data'];

			if( method_exists( $product, 'get_meta' ) ) :

				$cashback_setting = array(
					'enabled'      => 'yes' === $product->get_meta( 'cashback_enable', true ) ? true : false,
					'type'         => $product->get_meta('cashback_type', true),
					'value'        => floatval( $product->get_meta('cashback_value', true) ),
					'refundable'   => 'yes' === $product->get_meta( 'cashback_refundable', true ) ? true : false,
					'calculate_by' => 'product'
				);

			endif;

		endif;

		return $cashback_setting;
	}

	/**
	 * Add group tab to product data tabs
	 * Hooked via filter woocommerce_product_data_tabs, priority 10
	 * @since 	0.1.0
	 * @param  array $product_data_tabs
	 * @return 	void
	 */
	public function add_product_tab( $product_data_tabs  ) {

		// Adds the new tab

		$product_data_tabs ['cashback-tab'] = array(
			'label'    => __( 'Cashback', 'sejowoo' ),
			'target'   => 'cashback_product_data',
			'priority' => 11,
			'class'    => array('show_if_simple')
		);

		return $product_data_tabs ;

	}

	/**
	 * Add custom product data tab
	 * Hooked via action woocommerce_product_data_panels, priority 10
	 * @since 	0.1.0
	 * @return 	void
	 */
	public function set_cashback_fields() {

		global $post;

		?><div id='cashback_product_data' class='panel woocommerce_options_panel'><?php

			?><div class='options_group'>
				<h4 style="padding:0 1em"><?php _e('Pengaturan Cashback', 'sejowoo'); ?></h4><?php

				woocommerce_wp_checkbox( array(
					'id'    => 'cashback_enable',
					'label' => __('Aktifkan cashback', 'sejowoo'),
				) );

				woocommerce_wp_text_input( array(
					'id'                => 'cashback_value',
					'label'             => __('Nilai cashback', 'sejowoo'),
					'type'              => 'number',
					'custom_attributes' => array(
						'step' 	=> 'any',
						'min' => 0
					)
				) );

				woocommerce_wp_select( array(
					'id'      => 'cashback_type',
					'label'   => __('Tipe nilai cashback', 'sejowoo'),
					'options' => array(
						'fixed'      => __('Nilai tetap', 'sejowoo'),
						'percentage' => __('Persentase', 'sejowoo')
					)
				));

				woocommerce_wp_checkbox( array(
					'id'    => 'cashback_refundable',
					'label' => __('Apakah cashback bisa dicairkan?', 'sejowoo'),
				) );
				?>

			</div>

		</div><?php

	}

	/**
	 * Set cashback setting for variation
	 * Hooked via action woocommerce_product_after_variable_attributes, priority 100
	 * @since 	1.1.0
	 * @since 	1.1.1		Fixing issue with variation save data
	 * @param 	integer 	$loop
	 * @param 	array 		$variation_data
	 * @param 	array 		$variation
	 * @return 	void
	 */
	public function set_cashback_fields_for_variation( $loop, $variation_data, $variation) {

		?><div class='variation-cashback-setting'><?php

		woocommerce_wp_checkbox( array(
			'id'            => 'cashback-enable-' . $loop,
			'name'          => 'cashback_enable[' . $loop . ']',
			'label'         => __('Aktifkan cashback', 'sejowoo'),
			'wrapper_class' => 'form-row form-row-full',
			'value'         => 'yes' === get_post_meta( $variation->ID, 'cashback_enable', true) ? 'yes' : NULL,
		) );

		woocommerce_wp_text_input( array(
			'id'            => 'cashback_value-' . $loop,
			'name'          => 'cashback_value[' . $loop . ']',
			'label'         => __('Nilai cashback', 'sejowoo'),
			'type'          => 'number',
			'wrapper_class' => 'form-row form-row-first',
			'value'         => get_post_meta( $variation->ID, 'cashback_value', true),
			'custom_attributes' => array(
				'step' 	=> 'any',
				'min' => 0
			)
		) );

		woocommerce_wp_select( array(
			'id'            => 'cashback_type-' . $loop,
			'name'          => 'cashback_type[' . $loop . ']',
			'label'         => __('Tipe nilai cashback', 'sejowoo'),
			'value'         => get_post_meta( $variation->ID, 'cashback_type', true),
			'wrapper_class' => 'form-row form-row-last',
			'options'       => array(
				'fixed'      => __('Nilai tetap', 'sejowoo'),
				'percentage' => __('Persentase', 'sejowoo')
			)
		));

		woocommerce_wp_checkbox( array(
			'id'            => 'cashback_refundable-' . $loop,
			'name'          => 'cashback_refundable[' . $loop . ']',
			'value'         => 'yes' === get_post_meta( $variation->ID, 'cashback_refundable', true) ? 'yes' : NULL,
			'wrapper_class' => 'form-row form-row-full',
			'label'         => __('Apakah cashback bisa dicairkan?', 'sejowoo'),
		) );

		?></div><?php
	}

	/**
	 * Save custom product data
	 * Hooked via action woocommerce_process_product_meta, priority 10
	 * @since 	1.0.0
	 * @return 	void
	 */
	public function save_product_options( $post_id ) {

		$cashback_enable = isset( $_POST['cashback_enable'] ) ? 'yes' : NULL;
		update_post_meta( $post_id, 'cashback_enable', $cashback_enable );

		$cashback_value = floatval( $_POST['cashback_value'] );
		update_post_meta( $post_id, 'cashback_value', $cashback_value );

		$cashback_type = $_POST['cashback_type'];
		update_post_meta( $post_id, 'cashback_type', $cashback_type );

		$cashback_refundable = isset( $_POST['cashback_refundable'] ) ? 'yes' : NULL;
		update_post_meta( $post_id, 'cashback_refundable', $cashback_refundable );

	}

	/**
	 * Save custom product variation data
	 * Hooked via action woocommerce_save_product_variation, priority 10
	 * @since 	1.0.0
	 * @since 	1.1.1 		Fixing issue with variation save
	 * @param 	integer 	$variation_id
	 * @param 	integer 	$i
	 * @return 	void
	 */
	public function save_product_variation( $variation_id, $i ) {

		$cashback_enable = isset( $_POST['cashback_enable'][$i] ) ? 'yes' : 'no';
		update_post_meta( $variation_id, 'cashback_enable', $cashback_enable );

		$cashback_value = floatval( $_POST['cashback_value'][$i] );
		update_post_meta( $variation_id, 'cashback_value', $cashback_value );

		$cashback_type = $_POST['cashback_type'][$i];
		update_post_meta( $variation_id, 'cashback_type', $cashback_type );

		$cashback_refundable = isset( $_POST['cashback_refundable'][$i] ) ? 'yes' : 'no';
		update_post_meta( $variation_id, 'cashback_refundable', $cashback_refundable );

	}

    /**
     * Add cashback data when an order created
     * Hooked vi action woocommerce_checkout_order_created, priority 200
     * @since   1.0.0
     * @param   integer     $order_id
     * @param 	array 		$post_data
     * @param 	WC_Order 	$order
     */
    public function add_cashback_in_order( \WC_Order $order ) {

		$add_cashback  = apply_filters( 'sejowoo/cashback/add', true );

		if( false !== $add_cashback ) :

	        $respond 	   = sejowoo_add_cashback( $order );
	        $logger  	   = wc_get_logger();

	        if( is_wp_error( $respond) ) :

	            foreach( $respond->get_error_messages() as $message ) :
	                $logger->error( $message, $this->log );
	            endforeach;

	        else :

	            foreach( $respond as $wallet ) :

	                $logger->info(
	                    sprintf(
	                        __('New wallet data added for order_id %s, item_id %s, user_id %s, value %s', 'sejowoo'),
	                        $wallet['order_id'],
	                        $wallet['item_id'],
	                        $wallet['user_id'],
	                        wc_price( $wallet['value'] )
	                    ),
	                    $this->log
	                );

	            endforeach;

	        endif;

		endif;
    }

	/**
	 * Update wallet point valid status to invalid
	 * Hooked via action woocommerce_order_status_pending, priority 200
	 * Hooked via action woocommerce_order_status_on-hold, priority 200
	 * Hooked via action woocommerce_order_status_failed, priority 200
	 * Hooked via action woocommerce_order_status_refunded, priority 200
	 * Hooked via action woocommerce_order_status_cancelled, priority 200
	 * Hooked via action woocommerce_order_status_processing, priority 200
	 * @since 	1.0.0
	 * @param 	integer 	$order_id
	 */
	public function set_cashback_status_invalid( int $order_id ) {

		$respond = sejowoo_update_wallet_point_valid_status( $order_id, false, 'cashback' );
		$logger  = wc_get_logger();

		if( true === $respond ) :

			$logger->info(
				sprintf(
					__('All wallet point in order %s updated to %s', 'sejowoo'),
					$order_id,
					'false'
				),
				$this->log
			);

		else :

			foreach( $respond->get_error_messages() as $message ) :
                $logger->error( $message, $this->log );
            endforeach;

		endif;
	}

	/**
	 * Update wallet point valid status to valid
	 * Hooked via action woocommerce_order_status_completed, priority 200
	 * @since 	1.0.0
	 * @param 	integer 	$order_id
	 */
	public function set_cashback_status_valid( int $order_id ) {

		$respond = sejowoo_update_wallet_point_valid_status( $order_id, true, 'cashback' );
		$logger  = wc_get_logger();

		if( true === $respond ) :

			$logger->info(
				sprintf(
					__('All wallet point in order %s updated to %s', 'sejowoo'),
					$order_id,
					'true'
				),
				$this->log
			);

		else :

			foreach( $respond->get_error_messages() as $message ) :
                $logger->error( $message, $this->log );
            endforeach;

		endif;
	}

}
