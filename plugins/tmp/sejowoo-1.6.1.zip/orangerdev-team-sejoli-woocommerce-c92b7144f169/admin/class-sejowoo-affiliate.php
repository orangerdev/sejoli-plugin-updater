<?php

namespace Sejowoo\Admin;

use Carbon_Fields\Container;
use Carbon_Fields\Field;

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       https://sejowoo.co.id
 * @since      1.0.0
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/admin
 * @author     sejowoo <orangerdigiart@gmail.com>
 */
class Affiliate {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;

	}

    /**
     * Register affiliate post type
     * Hooked via action init, priority 999
     * @return void
     */
    public function register_post_type() {

		if( ! sejowoo_is_woocommerce_active() || false === sejowoo_check_own_license() ) :
			return;
		endif;

		$labels = [
    		'name'               => _x( 'Affiliate', 'post type general name', 'sejowoo' ),
    		'singular_name'      => _x( 'Affiliate', 'post type singular name', 'sejowoo' ),
    		'menu_name'          => _x( 'Affiliate', 'admin menu', 'sejowoo' ),
    		'name_admin_bar'     => _x( 'Affiliate', 'add new on admin bar', 'sejowoo' ),
    		'add_new'            => _x( 'Add New', 'affiliate', 'sejowoo' ),
    		'add_new_item'       => __( 'Add New Affiliate', 'sejowoo' ),
    		'new_item'           => __( 'New Affiliate', 'sejowoo' ),
    		'edit_item'          => __( 'Edit Affiliate', 'sejowoo' ),
    		'view_item'          => __( 'View Affiliate', 'sejowoo' ),
    		'all_items'          => __( 'All Affiliate', 'sejowoo' ),
    		'search_items'       => __( 'Search Affiliate', 'sejowoo' ),
    		'parent_item_colon'  => __( 'Parent Affiliate:', 'sejowoo' ),
    		'not_found'          => __( 'No affiliate found.', 'sejowoo' ),
    		'not_found_in_trash' => __( 'No affiliate found in Trash.', 'sejowoo' )
    	];

    	$args = [
    		'labels'             => $labels,
            'description'        => __( 'Description.', 'sejowoo' ),
    		'public'             => true,
    		'publicly_queryable' => true,
    		'show_ui'            => true,
    		'show_in_menu'       => true,
    		'query_var'          => true,
			'exclude_from_search'=> true,
    		// 'rewrite'            => [ 'slug' => 'aff' ],
    		'has_archive'        => false,
    		'hierarchical'       => false,
    		'menu_position'      => null,
    		'supports'           => [ 'title', 'editor' ],
			'menu_icon'			 => ! defined('zshop') ? plugin_dir_url( __FILE__ ) . 'images/icon.png' : NULL,
			'menu_position'		 => 35,
    	];

    	register_post_type( SEJOWOO_AFFILIATE_CPT, $args );
    }

	/**
	 * Add JS Vars for localization
	 * Hooked via sejowoo/admin/js-localize-data, priority 1
	 * @since 	1.0.0
	 * @param 	array 	$js_vars 	Array of js vars
	 * @return 	array
	 */
	public function set_localize_js_var(array $js_vars) {

		$js_vars['commission'] = [
			'table' => [
				'ajaxurl' => add_query_arg([
					'action' => 'sejoli-commission-table'
				], admin_url('admin-ajax.php')),
				'nonce' => wp_create_nonce('sejoli-render-commission-table')
			],
			'chart' => [
				'ajaxurl' => add_query_arg([
					'action' => 'sejoli-commission-chart'
				], admin_url('admin-ajax.php')),
				'nonce' => wp_create_nonce('sejoli-render-commission-chart')
			],
			'confirm' => [
				'ajaxurl' => add_query_arg([
					'action' => 'sejoli-commission-confirm'
				], admin_url('admin-ajax.php')),
				'nonce' => wp_create_nonce('sejoli-commission-confirm')
			],
			'update' => [
				'ajaxurl' => add_query_arg([
					'action' => 'sejoli-commission-update'
				], admin_url('admin-ajax.php')),
				'nonce' => wp_create_nonce('sejoli-commission-update')
			],
			'status' => [
				'pending'	=> __('Order belum selesai', 'sejowoo'),
				'added'		=> __('Belum dibayar', 'sejowoo'),
				'cancelled' => __('Dibatalkan', 'sejowoo'),
				'paid'		=> __('Sudah dibayar', 'sejowoo')
			],
			'transfer'	=> [
				'ajaxurl' => add_query_arg([
					'action' => 'sejoli-confirm-commission-transfer'
				], admin_url('admin-ajax.php')),
				'nonce' => wp_create_nonce('sejoli-confirm_commission_transfer')
			]
		];

		$js_vars['affiliate_commission'] = [
			'table' => [
				'ajaxurl' => add_query_arg([
					'action' => 'sejoli-affiliate-commission-table'
				], admin_url('admin-ajax.php')),
				'nonce' => wp_create_nonce('sejoli-render-affiliate-commission-table')
			],
			'confirm' => [
				'ajaxurl' => add_query_arg([
					'action' => 'sejoli-affiliate-commission-detail'
				], admin_url('admin-ajax.php')),
				'nonce' => wp_create_nonce('sejoli-affiliate-commission-detail')
			],
			'pay'	=> [
				'ajaxurl' => add_query_arg([
					'action' => 'sejoli-pay-single-affiliate-commission'
				], admin_url('admin-ajax.php')),
			]
		];

		$js_vars['affiliate'] = [
			'placeholder' => __('Pencarian affiliasi', 'sejowoo')
		];

		return $js_vars;
	}

    /**
     * Setup custom fields for affiliate
     * Hooked via action carbon_fields_register_fields, priority 1009
     * @since 	1.0.0
     * @return 	void
     */
    public function setup_carbon_fields() {

        $container = Container::make('post_meta', __('Affiliate Details', 'sejowoo'))
            ->where( 'post_type', '=', SEJOWOO_AFFILIATE_CPT)
            ->add_fields( [
				Field::make( 'text',		'link_redirect', __('Link Redirect', 'sejowoo'))
					->set_required(true)
					->set_attribute('placeholder', 'https://')
					->set_help_text(
						__('Pastikan menggunakan https:// atau http:/ pada awalan link. Link ini bebas anda isi kemanapun anda ingin calon pembeli diarahkan. Bisa diarahkan keluar website', 'sejowoo')
					)
			]);
	}

	/**
	 * Add affiliate general fields
	 * Hooked via filter sejowoo/general/fields, priority 20
	 * @since 	1.0.0
	 * @param 	array $fields
	 * @return 	array
	 */
	public function set_sejowoo_general_fields( array $fields ) {

		$fields['affiliate'] = [
			'title'		=> __('Affiliasi', 'sejowoo'),
			'fields'	=> [
				// Member Area Setting
				Field::make('separator', 'sep_sejowoo_affiliate_member_area', __('Pengaturan Member Menu', 'sejowoo'))
					->set_classes('sejoli-with-help'),

				Field::make('checkbox', 'sejowoo_member_area_hide_affiliate_link', __('Sembunyikan menu Link Affiliasi', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_member_area_hide_affiliate_order', __('Sembunyikan menu Order Affiliasi', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_member_area_hide_affiliate_coupon', __('Sembunyikan menu Kupon Affiliasi', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_member_area_hide_affiliate_network', __('Sembunyikan menu Jaringan Affiliasi', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_member_area_hide_leaderboard', __('Sembunyikan menu Leaderboard', 'sejowoo')),

				// Commission Setting
				Field::make('separator', 'sep_sejowoo_leaderboard', __('Leaderboard', 'sejowoo'))
					->set_classes('sejoli-with-help')
					->set_conditional_logic(array(
						array(
							'field'	=> 'sejowoo_member_area_hide_leaderboard',
							'value'	=> false
						)
					)),

				Field::make('checkbox', 'sejowoo_display_leaderboard_point',	__('Tampilkan nilai perncapaian affiliasi', 'sejowoo'))
					->set_conditional_logic(array(
						array(
							'field'	=> 'sejowoo_member_area_hide_leaderboard',
							'value'	=> false
						)
					))
					->set_width(50)
					->set_help_text( __('Dengan mengaktifkan opsi ini, maka leaderboard akan menampilkan nilai total omset, total komisi dan jumlah produk', 'sejowoo')),

				Field::make('text', 'sejowoo_limit_leaderboard_data', __('Total data yang akan ditampilkan', 'sejowoo'))
					->set_attribute('type', 'number')
					->set_default_value(10)
					->set_conditional_logic(array(
						array(
							'field'	=> 'sejowoo_member_area_hide_leaderboard',
							'value'	=> false
						)
					))
					->set_width(50),

				// Commission Setting
				Field::make('separator', 'sep_sejowoo_affiliate_permission', __('Pembatasan', 'sejowoo'))
					->set_classes('sejoli-with-help'),

				Field::make('checkbox', 'sejowoo_no_access_affiliate', __('Fitur affiliasi tidak diaktifkan', 'sejowoo'))
					->set_help_text( __('Dengan mengaktifkan fitur ini maka semua user tidak bisa mengakses ke menu affiliasi. <br />Anda bisa mengaktifkan affiliasi untuk user tertentu menggunakan <strong>User Groups</strong', 'sejowoo')),

				Field::make('rich_text', 'sejowoo_no_access_affiliate_text', __('Pesan untuk user tanpa fitur affiliasi', 'sejowoo'))
					->set_help_text( __('Pesan ini akan ditampilkan di semua halaman affiliasi untuk user yang tidak memiliki fitur affilias.', 'sejowoo'))
					->set_default_value('
						<p>Halaman ini hanya bisa diakses jika anda memiliki fitur affiliasi.</p>
			        	<p>Anda bisa menghubungi admin untuk hal ini.</p>
					'),

				Field::make('separator', 'sep_sejowoo_cookie',	__('Cookie', 'sejowoo'))
					->set_classes('sejoli-with-help'),

				Field::make('text', 'sejowoo_cookie_age',	__('Umur Cookie', 'sejowoo'))
					->set_attribute('type', 'number')
					->set_default_value(90)
					->set_required()
					->set_help_text(__('Umur cookie dalam satuan hari', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_permanent_affiliate', __('Kaitkan affiliasi', 'sejowoo'))
					->set_option_value('yes')
					->set_default_value(false)
					->set_help_text(__('Dengan mengaktifkan ini, pembeli yang sudah pernah terdaftar atas seorang affiliasi maka untuk pembelian selanjutnya akan selalu berdasarkan affiliasi tersebut. <br />Penggunaan link affiliasi maupun kupon affiliasi tidak akan berpengaruh lagi', 'sejowoo')),

				// Field::make('separator', 'sep_sejowoo_affiliate_tool', __('Tool', 'sejowoo')),
				//
				// Field::make('checkbox', 'sejowoo_affiliate_tool_bonus', __('Bonus Editor', 'sejowoo'))
				// 	->set_option_value('yes')
				// 	->set_default_value('yes')
				// 	->set_help_text(__('Memunculkan editor pada masing-masing affiliate yang isinya akan ditampilkan kepada pembeli sesuai affiliatenya', 'sejowoo')),
				//
				// Field::make('checkbox', 'sejowoo_affiliate_tool_fb_pixel', __('Facebook Pixel', 'sejowoo'))
				// 	->set_option_value('yes')
				// 	->set_help_text(__('Memunculkan isian ID facebook pixel pada masing-masing affiliate', 'sejowoo')),

				Field::make('separator', 'sep_sejowoo_affiliate_coupon', __('Kupon', 'sejowoo')),

				Field::make('checkbox', 'sejowoo_affiliate_coupon_active', __('Kupon affiliasi langsung aktif', 'sejowoo'))
					->set_option_value('yes')
					->set_default_value(true)
					->set_help_text(__('Dengan mengaktifkan kupon ini, maka semua permintaan kupon affiliasi akan langsung aktif', 'sejowoo')),

				Field::make('text', 'sejowoo_max_affiliate_coupon', __('Maksimal kupon affiliasi', 'sejowoo'))
					->set_attribute('type', 'number')
					->set_default_value(1)
					->set_required(true)
					->set_help_text(__('Batasan maksimal affiliasi bisa membuat kupon per kupon utama', 'sejowoo')),

				Field::make('separator', 'sep_sejowoo_affiliate_network', __('Jaringan Affiliasi', 'sejowoo')),

				Field::make('text',	'sejowoo_affiliate_network_limit', __('Batasan maksimal tampilan kedalaman jaringan affiliasi', 'sejowoo'))
					->set_attribute( 'type', 'number')
					->set_default_value( 1 )
					->set_help_text( __('Tentukan maksimal kedalaman jaringan affiliasi di menu Jaringan Affiliasi pada halaman member area', 'sejowoo'))


			]
		];

		return $fields;
	}

	/**
	 * Add custom columns to affiliate columns
	 * Hooked via filter manage_edit-SEJOWOO_AFFILIATE_CPT_columns, priority 119
	 * @since 	1.0.0
	 * @param 	array 	$columns
	 * @return 	array
	 */
	public function add_custom_columns( $columns ) {

		unset($columns['date']);

		$columns['link-redirect'] = __('Link Redirect', 'sejowoo');
		$columns['description']	  = __('Deskripsi', 'sejowoo');

		return $columns;
	}

	/**
	 * Display custom columns value to affiliate
	 * Hooked via action manage_SEJOWOO_AFFILIATE_CPT_posts_custom_column, priority 119
	 * @since 	1.0.0
	 * @param  	string 	$column
	 * @param  	integer $post_id
	 */
	public function display_custom_column_values( $column, $post_id ) {

		global $post;

		switch( $column ) :

			case 'link-redirect' :

				?><a href='<?php echo $post->_link_redirect; ?>' target='_blank'><?php echo $post->_link_redirect; ?></a><?php ;

				break;

			case 'description' :
				echo wpautop($post->post_content);
				break;

		endswitch;
	}

	/**
	 * Get affiliate list by AJAX
	 * Hooked via action wp_ajax_sejowoo-get-affiliate-user-list, priority 1
	 *
	 * @return 	json
	 */
	public function get_affiliate_list() {

		$response = array(
			"results" => array(),
			"pagination" => array(
				"more" => true,
			)
		);

		$get_data = wp_parse_args( $_GET, array(
						'nonce' => '',
						'search' => ''
					));

		if ( wp_verify_nonce( $get_data['nonce'], 'sejowoo-get-affiliate-user-list') &&  !empty( $get_data['search'])) :
			$user_query = new \WP_User_Query(array(
				"search" => "*" . $get_data['search'] . "*"
			));

			$users = $user_query->get_results();

			if( !empty($users) ) :
				foreach($users as $user) :
					$response["results"][] = array(
						"id"   => $user->ID,
						"text" => sprintf(
									__("#%s - %s - %s ", "sejowoo"),
									$user->ID,
									$user->display_name,
									$user->user_email
								  ),
					);
				endforeach;
			endif;
		endif;

		echo wp_send_json( $response );
	}
}
