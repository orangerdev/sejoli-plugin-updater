<?php
namespace SejoWoo\Database;

use Illuminate\Database\Capsule\Manager as Capsule;

Class Coupon extends \SejoWoo\Database {

    /**
     * WC_Coupon data
     * @since   1.0.0
     * @var     WC_Coupon
     */
    static protected $coupon;

    /**
     * Ignore post meta keys
     * @since   1.0.0
     * @var     array
     */
    static protected $ignore_keys = array(
        'usage_count',
        '_used_by',
        'enable_affiliate_use',
        '_edit_lock',
        '_edit_last'
    );

    /**
     * Default properties values
     * @since   1.0.0
     * @var     array
     */
    static protected $props = array(
        'id'               => 0,
        'parent_coupon_id' => 0,
        'coupon_code'      => '',
        'affiliate_id'     => 0
    );

    /**
     * Get ignore keys
     * @since   1.0.0
     * @return  array
     */
    static protected function get_ignore_keys() {

        return apply_filters(
                    'sejowoo/coupon/ignore-fields',
                    self::$ignore_keys
                );

    }

    /**
     * Reset all data
     * @since   1.0.0
     */
    static public function reset() {

        parent::reset();
        self::$data = self::$props;

        return new static;
    }

    /**
     * Set default data
     * @since   1.0.0
     */
    static public function set_data( array $data ) {

        $data = wp_parse_args($data, self::$props );

        self::$data['id']               = absint( $data['id'] );
        self::$data['coupon_code']      = sanitize_title( $data['coupon_code'] );
        self::$data['parent_coupon_id'] = absint( $data['parent_coupon_id'] );
        self::$data['affiliate_id']     = absint( $data['affiliate_id'] );

        parent::$data = self::$data;

        return new static;

    }

    /**
     * Get all available affiliated coupons
     * @since 1.0.0
     */
    static public function get_affiliated_coupons() {

        $query = new \WP_Query(array(
            'post_type'      => SEJOWOO_COUPON_CPT,
            'posts_per_page' => -1,
            'post_status'    => 'publish',
            'post_parent'    => 0,
            'order'          => 'title',
            'meta_query'     => array(
                array(
                    'key'   => 'enable_affiliate_use',
                    'value' => 'yes'
                )
            ),
            'no_found_rows'          => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false
        ));

        if(
            is_array($query->posts) &&
            0 < count($query->posts)
        ) :

            $coupons = array();

            foreach( $query->posts as $post ) :
                $coupons[$post->ID] = $post->post_title;
            endforeach;

            self::set_valid     ( true );
            self::set_respond   ( 'coupons', $coupons);

        else :

            self::set_valid     ( false );
            self::set_message   ( __('No affiliate-use coupon available', 'sejowoo'));

        endif;

        return new static;

    }

    /**
     * Get total affiliate coupon
     * @since 1.0.0
     */
    static public function get_total_affiliate_coupon() {

        $query = new \WP_Query(array(
            'post_type'              => SEJOWOO_COUPON_CPT,
            'posts_per_page'         => 10,
            'post_status'            => 'publish',
            'post_parent'            => self::$data['parent_coupon_id'],
            'author'                 => self::$data['affiliate_id'],
            'no_found_rows'          => true,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false
        ));

        self::set_valid     ( true );
        self::set_respond   ( 'total_coupons', absint($query->post_count));

        return new static;

    }

    /**
     * Create affiliate coupon
     * @since   1.0.0
     */
    static public function create_affiliate_coupon() {

        self::$data['id'] = wp_insert_post(array(
            'post_title'   => strtoupper(self::$data['coupon_code']),
            'post_content' => '',
            'post_status'  => carbon_get_theme_option('sejowoo_affiliate_coupon_active') ? 'publish' : 'draft',
            'post_type'    => SEJOWOO_COUPON_CPT,
            'author'       => self::$data['affiliate_id'],
            'post_parent'  => self::$data['parent_coupon_id']
        ));

        if( self::$data['id'] ) :

            self::duplicate_coupon_data();

            self::set_valid     ( true );
            self::set_respond   ( 'coupon', new \WC_Coupon( self::$data['id'] ) );
        else :
            self::set_valid     ( false );
        endif;

        return new static;
    }

    /**
     * Duplicate coupon meta data from parent coupon;
     * @since   1.0.0
     */
    static public function duplicate_coupon_data( ) {

        $parent_post_metas = get_post_meta(self::$data['parent_coupon_id']);
        $ignore_keys       = self::get_ignore_keys();

        foreach( $parent_post_metas as $meta_key => $values ) :

            if( in_array($meta_key, $ignore_keys ) ) :
                continue;
            endif;

            foreach($values as $value) :
                update_post_meta( self::$data['id'], $meta_key, $value );
            endforeach;

        endforeach;
    }

    /**
     * Get list
     * @since 1.0.0
     */
    static public function get() {

        global $wpdb;

        $query        = Capsule::table( $wpdb->posts )
                        ->select(
                            'ID', 'post_author', 'post_parent'
                        )
                        ->where( 'post_status', 'publish' )
                        ->where( 'post_type',   SEJOWOO_COUPON_CPT )
                        ->where( function($query){
                            $query->where('post_parent', 0)
                                ->orWhere('post_author', self::$data['affiliate_id']);
                        });

        $query        = self::set_filter_query( $query );

        $recordsTotal = $query->count();
        $query        = self::set_length_query($query);
        $coupons      = $query->get()->toArray();

        if ( $coupons ) :
            self::set_respond('valid',           true);
            self::set_respond('coupons',         $coupons);
            self::set_respond('recordsTotal',    $recordsTotal);
            self::set_respond('recordsFiltered', $recordsTotal);
        else:
            self::set_respond('valid',           false);
            self::set_respond('coupons',         []);
            self::set_respond('recordsTotal',    0);
            self::set_respond('recordsFiltered', 0);
        endif;

        return new static;
    }

    /**
     * Update affiliated coupons based on parent coupon
     * @since   1.0.0
     */
    public function update_affiliate_coupons() {

        global $wpdb;

        $coupons = Capsule::table( $wpdb->posts )
                    ->select('ID')
                    ->where( 'post_type',  SEJOWOO_COUPON_CPT )
                    ->where( 'post_parent', self::$data['parent_coupon_id'])
                    ->get();

        $coupon_ids = array();

        foreach( $coupons as $coupon ) :
            $coupon_ids[] = $coupon->ID;
        endforeach;

        Capsule::table( $wpdb->postmeta )
            ->whereIn( 'post_id', $coupon_ids)
            ->whereNotIn( 'meta_key', self::get_ignore_keys() )
            ->delete();

        foreach( $coupon_ids as $coupon_id ) :

            self::$data['id'] = $coupon_id;
            self::duplicate_coupon_data();

        endforeach;

        self::set_respond( 'total', count($coupons) );

        return new static;

    }
}
