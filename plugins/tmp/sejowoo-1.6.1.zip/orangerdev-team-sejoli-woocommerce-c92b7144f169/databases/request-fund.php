<?php
namespace SejoWoo\Database;

use Illuminate\Database\Capsule\Manager as Capsule;

Class RequestFund extends \SejoWoo\Database
{
    static protected $ids         = [];
    static protected $statuses    = array('requested', 'rejected', 'approved');
    static protected $table       = 'sejowoo_request_funds';
    static protected $props = array(
        'ID'        => 0,
        'user_id'   => 0,
        'admin_id'  => 0,
        'amount'    => 0.0,
        'status'    => 'requested',
        'meta_data' => array()
    );

    /**
     * Create table if not exists
     * @return void
     */
    static public function create_table()
    {
        parent::$table = self::$table;

        if(!Capsule::schema()->hasTable( self::table() )):
            Capsule::schema()->create( self::table(), function($table){
                $table->increments('ID');
                $table->datetime('created_at');
                $table->datetime('updated_at')->default('0000-00-00 00:00:00');
                $table->datetime('deleted_at')->default('0000-00-00 00:00:00');
                $table->datetime('approved_at')->default('0000-00-00 00:00:00');
                $table->integer('user_id');
                $table->integer('admin_id')->default(0);
                $table->float('amount', 10, 2);
                $table->enum('status', self::$statuses);
                $table->text('meta_data');
            });
        endif;
    }

    /**
     * Reset all data
     * @since   1.0.0
     */
    static public function reset() {

        parent::reset();
        self::$data = self::$props;

        return new static;
    }

    /**
     * Set default data
     * @since   1.0.0
     */
    static public function set_data( array $data ) {

        $data = wp_parse_args($data, self::$props );

        self::$data['ID']        = absint( $data['ID'] );
        self::$data['user_id']   = absint( $data['user_id'] );
        self::$data['admin_id']  = absint( $data['admin_id'] );
        self::$data['status']    = $data['status'];
        self::$data['amount']    = floatval( $data['amount'] );
        self::$data['meta_data'] = (array) $data['meta_data'];

        parent::$data = self::$data;

        return new static;

    }

    /**
     * Validate request status
     * @since 1.0.0
     */
    static public function validate_status() {

        if( !in_array( self::$data['status'], self::$statuses ) ) :

            self::set_valid     ( false );
            self::set_message   ( __('Request status is not valid', 'sejowoo') );
            self::set_respond   ( 'error', 'invalid-data' );

        endif;

    }

    /**
     * Validate amount request
     * @since   1.0.0
     */
    static public function validate_amount() {

        if ( 0 >= self::$data['amount'] ) :

            self::set_valid     ( false );
            self::set_message   ( __('Request amount must be over 0', 'sejowoo') );
            self::set_respond   ( 'error', 'invalid-data' );

        endif;

    }

    /**
     * Validate method
     * @since   1.0.0
     */
    static public function validate() {

        if( 'add' === self::$action ) :

            self::validate_user();
            self::validate_amount();

        elseif( 'update-status' === self::$action ) :

            self::validate_id();
            self::validate_admin();

        elseif( 'single' === self::$action ) :

            self::validate_id();

        endif;

    }

    /**
     * Add request fund
     * @since   1.0.0
     */
    static public function add() {

        self::set_action( 'add' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $request = [
                'created_at' => current_time('mysql'),
                'user_id'    => self::$data['user_id'],
                'amount'     => self::$data['amount'],
                'status'     => 'requested',
                'meta_data'  => serialize(self::$data['meta_data'])
            ];

            $request['ID'] = Capsule::table(self::table())
                            ->insertGetId($request);

            self::set_valid     ( true );
            self::set_respond   ( 'request', $request );

        endif;

        return new static;

    }

    /**
     * Reject request
     * @since   1.0.0
     */
    static public function reject() {

        self::set_action( 'update-status' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $valid = Capsule::table(self::table())
                        ->where('ID', self::$data['ID'])
                        ->update(array(
                            'updated_at'    => current_time('mysql'),
                            'admin_id'      => self::$data['admin_id'],
                            'status'        => 'rejected',
                            'meta_data'     => serialize(self::$data['meta_data'])
                        ));

            self::set_valid( boolval($valid) );

        endif;

        return new static;

    }

    /**
     * Approve request
     * @since   1.0.0
     */
    static public function approve() {

        self::set_action( 'update-status' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $valid = Capsule::table(self::table())
                        ->where('ID', self::$data['ID'])
                        ->update(array(
                            'updated_at'  => current_time('mysql'),
                            'approved_at' => current_time('mysql'),
                            'admin_id'    => self::$data['admin_id'],
                            'status'      => 'approved',
                            'meta_data'   => serialize(self::$data['meta_data'])
                        ));

            self::set_valid( boolval($valid) );

        endif;

        return new static;

    }

    /**
     * Get all request list
     * @since   1.0.0
     */
    static public function get() {

        global $wpdb;

        parent::$table = self::$table;

        $query        = Capsule::table( Capsule::raw( self::table() . ' AS request_fund' ))
                        ->select(
                            'request_fund.*',
                            'user.display_name',
                            'user.user_email'
                        )
                        ->join(
                            $wpdb->users . ' AS user', 'user.ID', '=', 'request_fund.user_id'
                        )
                        ->join(
                            $wpdb->prefix . 'sejowoo_wallets AS wallet', 'wallet.meta_id', '=', 'request_fund.ID'
                        )
                        ->where('wallet.type',  'out')
                        ->where('wallet.label', 'request-fund');

        $query        = self::set_filter_query( $query );

        $recordsTotal = $query->count();
        $query        = self::set_length_query($query);
        $request_funds = $query->get()->toArray();

        if ( $request_funds ) :
            self::set_respond('valid', true);
            self::set_respond('request_funds', $request_funds);
            self::set_respond('recordsTotal', $recordsTotal);
            self::set_respond('recordsFiltered', $recordsTotal);
        else:
            self::set_respond('valid', false);
            self::set_respond('request_funds', []);
            self::set_respond('recordsTotal', 0);
            self::set_respond('recordsFiltered', 0);
        endif;

        return new static;

    }

    /**
     * Get single request data
     * @since   1.0.0
     */
    static public function single() {

        global $wpdb;

        self::set_action( 'single' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $data = Capsule::table( Capsule::raw( self::table() . ' AS request_fund' ))
                            ->select(
                                'request_fund.*',
                                'user.display_name',
                                'user.user_email'
                            )
                            ->join(
                                $wpdb->users . ' AS user', 'user.ID', '=', 'request_fund.user_id'
                            )
                        ->where('request_fund.ID', self::$data['ID'] )
                        ->first();

            if( $data ) :
                self::set_valid     ( true );
                self::set_respond   ( 'request_data', $data );
            else :
                self::set_valid     ( false );
                self::set_message   ( __('Data not found', 'sejowoo') );
            endif;

        endif;

        return new static;

    }
}
