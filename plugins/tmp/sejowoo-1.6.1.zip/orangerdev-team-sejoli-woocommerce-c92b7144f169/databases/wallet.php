<?php
namespace SejoWoo\Database;

use Illuminate\Database\Capsule\Manager as Capsule;

/**
 * Class responsible for Wallet database
 * @since   1.0.0
 */
Class Wallet extends \SejoWoo\Database
{
    /**
     * Store multiple ID data
     * @since  1.0.0
     * @var    array
     */
    static protected $ids   = [];

    /**
     * Table name
     * @since   1.0.0
     * @var     string
     */
    static protected $table = 'sejowoo_wallets';

    /**
     * Store request data
     * @since   1.0.0
     * @var     array
     */

    static protected $data  = array();

    /**
     * Default property value
     * @since   1.0.0
     * @var     string
     */
    static protected $props = array(
        'order_id'    => 0,
        'order'       => NULL,
        'item_id'     => 0,
        'product_id'  => 0,
        'product'     => NULL,
        'user_id'     => 0,
        'meta_id'     => 0, // it will used beside order
        'user'        => NULL,
        'value'       => 0.0,
        'type'        => 'out',
        'label'       => '',
        'refundable'  => false,
        'valid_point' => false,
        'meta_data'   => array()
    );

    /**
     * Create table if not exists
     * @since   1.0.0
     * @return  void
     */
    static public function create_table()
    {
        parent::$table = self::$table;

        if( ! Capsule::schema()->hasTable( self::table() ) ):

            Capsule::schema()->create( self::table() , function($table){
                $table->increments  ('ID');
                $table->datetime    ('created_at');
                $table->integer     ('order_id');
                $table->integer     ('item_id');
                $table->integer     ('product_id');
                $table->integer     ('meta_id')->default(0);
                $table->integer     ('user_id');
                $table->float       ('value', 15, 2);
                $table->enum        ('type', array('in', 'out'));
				$table->string 		('label');
				$table->boolean     ('refundable');
				$table->boolean		('valid_point');
                $table->text        ('meta_data')->nullable();
            });

        endif;
    }

    /**
     * Reset all data
     * @since   1.0.0
     */
    static public function reset() {

        parent::reset();
        self::$data = self::$props;

        return new static;
    }

    /**
     * Set default data
     * @since   1.0.0
     */
    static public function set_data( array $data ) {

        $data = wp_parse_args($data, self::$props );

        self::$data['order_id']    = intval( $data['order_id'] );
        self::$data['item_id']     = intval( $data['item_id'] );
        self::$data['product_id']  = intval( $data['product_id'] );
        self::$data['user_id']     = intval( $data['user_id'] );
        self::$data['meta_id']     = intval( $data['meta_id'] );
        self::$data['value']       = floatval( $data['value'] );
        self::$data['type']        = ( 'in' === $data['type'] ) ? 'in' : 'out';
        self::$data['label']       = $data['label'];
        self::$data['refundable']  = boolval( $data['refundable'] );
        self::$data['valid_point'] = boolval( $data['valid_point'] );
        self::$data['meta_data']   = (array) $data['meta_data'];

        parent::$data = self::$data;

        return new static;

    }

    /**
     * Validate wallet value
     * @since   1.0.0
     */
    static public function validate_value() {

        if( 0.0 === self::$data['value'] ) :
            self::set_valid     ( false );
            self::set_message   ( __('Wallet value must not be 0', 'sejowoo') );
            self::set_respond   ( 'error', 'invalid-data' );
        endif;

    }

    /**
     * Validate wallet value
     * @since   1.0.0
     */
    static public function validate_type() {

        if( !in_array( self::$data['type'], array('in', 'out') ) ) :
            self::set_valid     ( false );
            self::set_message   ( __('Wallet type only accept in or out', 'sejowoo') );
            self::set_respond   ( 'error', 'invalid-data' );
        endif;

    }

    /**
     * Validate wallet label
     * @since   1.0.0
     */
    static public function validate_label() {

        if( empty( self::$data['label']) ) :
            self::set_valid     ( false );
            self::set_message   ( __('Wallet label must be not empty', 'sejowoo') );
            self::set_respond   ( 'error', 'invalid-data' );
        endif;

    }

    /**
     * Validate wallet refundable status
     * @since   1.0.0
     */
    static public function validate_refundable() {

        if( ! is_bool( self::$data['refundable']) ) :
            self::set_valid     ( false );
            self::set_message   ( __('Wallet refundable must be valid boolean', 'sejowoo') );
            self::set_respond   ( 'error', 'invalid-data' );
        endif;

    }

    /**
     * Validate wallet valid_point status
     * @since   1.0.0
     */
    static public function validate_valid_point() {

        if( ! is_bool( self::$data['valid_point']) ) :
            self::set_valid     ( false );
            self::set_message   ( __('Wallet valid point must be valid boolean', 'sejowoo') );
            self::set_respond   ( 'error', 'invalid-data' );
        endif;

    }

    /**
     * Validate data
     * @since   1.0.0
     */
    static public function validate() {

        if( 'add' === self::$action ) :

            self::validate_user();
            // self::validate_order();
            // self::validate_item();
            // self::validate_product();
            self::validate_type();
            self::validate_label();
            self::validate_refundable();
            self::validate_valid_point();

        elseif( 'get-detail' === self::$action ) :

            self::validate_user();
            // self::validate_order();
            // self::validate_item();
            self::validate_type();
            self::validate_label();

        elseif( 'update-valid-point' === self::$action ) :

            self::validate_order();
            self::validate_label();

        elseif( 'update-valid-point-by-meta' === self::$action ) :

            self::validate_absint( 'meta_id' );
            self::validate_label();

        elseif( 'get-user-wallet' === self::$action ) :

            self::validate_user();

        endif;

    }

    /**
     * Add mew wallet data
     * @since   1.0.0
     */
    static public function add() {

        self::set_action( 'add' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $wallet = [
                'created_at'  => current_time('mysql'),
                'order_id'    => self::$data['order_id'],
                'product_id'  => self::$data['product_id'],
                'item_id'     => self::$data['item_id'],
                'user_id'     => self::$data['user_id'],
                'meta_id'     => self::$data['meta_id'],
                'value'       => self::$data['value'],
                'type'        => self::$data['type'],
                'label'       => self::$data['label'],
                'refundable'  => self::$data['refundable'],
                'valid_point' => self::$data['valid_point'],
                'meta_data'   => serialize(self::$data['meta_data'])
            ];

            $wallet['ID'] = Capsule::table(self::table())
                            ->insertGetId($wallet);

            self::set_valid     ( true );
            self::set_respond   ( 'wallet', $wallet );

        endif;

        return new static;

    }

    /**
     * Get wallet detail data
     * @since 1.0.0
     */
    static public function get_detail() {

        self::set_action( 'get-detail' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $query = Capsule::table( self::table() );

            if( 0 === absint(self::$data['meta_id']) ) :
                $query = $query->where( 'order_id', self::$data['order_id'] )
                                ->where( 'item_id',  self::$data['item_id'] );
            else :
                $query = $query->where( 'meta_id', self::$data['meta_id'] );
            endif;

            $data = $query->where('user_id',  self::$data['user_id'] )
                        ->where('label',    self::$data['label'] )
                        ->first();

            if($data) :
                self::set_valid     ( true );
                self::set_respond   ('wallet', (array) $data);
            else :
                self::set_valid     ( false );
                self::set_respond   ( 'error', 'data-not-found' );
                self::set_message   ( __('Data not found', 'sejowoo') );
            endif;

        endif;

        return new static;
    }

    /**
     * Get available all user wallet
     * @since   1.0.0
     */
    static public function get_all_user_wallet() {

        global $wpdb;

        parent::$table = self::$table;

        $query  = Capsule::table( Capsule::raw( self::table() . ' AS wallet' ))
                    ->select(
                        'wallet.user_id',
                        'user.display_name',
                        'user.user_email',
                        Capsule::raw(
                            'SUM(CASE WHEN type = "in" AND refundable = 1 THEN value ELSE 0 END) AS cash_value'
                        ),
                        Capsule::raw(
                            'SUM(CASE WHEN type = "in" AND refundable = 0 THEN value ELSE 0 END) AS point_value' // Non refundable
                        ),
                        Capsule::raw(
                            'SUM(CASE WHEN type = "out" THEN value ELSE 0 END) AS used_value'
                        ),
                        Capsule::raw(
                            'SUM(
                                CASE
                                    WHEN type = "in" AND refundable = 1 THEN value
                                    WHEN type = "in" AND refundable = 0 THEN 0
                                    ELSE -value
                                END
                             ) AS available_cash'
                        ),
                        Capsule::raw(
                            'SUM(CASE WHEN type = "in" THEN value ELSE -value END) AS available_total'
                        )
                    )
                    ->join(
                        $wpdb->users . ' AS user', 'user.ID', '=', 'wallet.user_id'
                    )
                    ->where('valid_point', true)
                    ->orderBy('available_total', 'DESC')
                    ->groupBy('user_id');

        $query  = self::set_filter_query( $query );

        $result = $query->get();

        if($result) :

            self::set_valid(true);
            self::set_respond('wallet', $result);

        else :

            self::set_valid(false);
            self::set_message( __('No point data', 'sejowoo'));

        endif;

        return new static;
    }

    /**
     * Get all wallet details filtered
     * @since   1.0.0
     * @return  void
     */
    static public function get() {

        global $wpdb;

        parent::$table = self::$table;

        $query        = Capsule::table( Capsule::raw( self::table() . ' AS wallet' ))
                        ->select(
                            'wallet.*',
                            'user.display_name',
                            'user.user_email'
                        )
                        ->join(
                            $wpdb->users . ' AS user', 'user.ID', '=', 'wallet.user_id'
                        );
        $query        = self::set_filter_query( $query );

        $recordsTotal = $query->count();
        $query        = self::set_length_query($query);
        $wallet       = $query->get()->toArray();

        if ( $wallet ) :
            self::set_respond('valid', true);
            self::set_respond('wallet', $wallet);
            self::set_respond('recordsTotal', $recordsTotal);
            self::set_respond('recordsFiltered', $recordsTotal);
        else:
            self::set_respond('valid', false);
            self::set_respond('wallet', []);
            self::set_respond('recordsTotal', 0);
            self::set_respond('recordsFiltered', 0);
        endif;

        return new static;
    }

    /**
     * Update valid point based on order id
     * @since   1.0.0
     */
    static public function update_valid_point() {

        self::set_action( 'update-valid-point' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $data = Capsule::table( self::table() )
                        ->where('order_id', self::$data['order_id'] )
                        ->where('label', self::$data['label'] )
                        ->update(array(
                            'valid_point' => self::$data['valid_point']
                        ));

            self::set_valid( true );

        endif;

        return new static;
    }

    /**
     * Update valid point based on meta id
     * @since   1.0.0
     */
    static public function update_valid_point_by_meta() {

        self::set_action( 'update-valid-point-by-meta' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $data = Capsule::table( self::table() )
                        ->where('meta_id',  self::$data['meta_id'] )
                        ->where('label',    self::$data['label'] )
                        ->update(array(
                            'valid_point' => self::$data['valid_point']
                        ));

            self::set_valid( true );

        endif;

        return new static;
    }

    /**
     * Get available user wallet data
     * @since   1.0.0
     */
    static public function get_user_wallet() {

        global $wpdb;

        self::set_action( 'get-user-wallet' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $query  = Capsule::table( self::table() )
                        ->select(
                            'user_id',
                            Capsule::raw(
                                'SUM(CASE WHEN type = "in" AND refundable = 1 AND valid_point = 1 THEN value ELSE 0 END) AS cash_value'
                            ),
                            Capsule::raw(
                                'SUM(CASE WHEN type = "in" AND refundable = 0 AND valid_point = 1 THEN value ELSE 0 END) AS point_value' // Non refundable
                            ),
                            Capsule::raw(
                                'SUM(CASE WHEN type = "out" AND valid_point = 1 THEN value ELSE 0 END) AS used_value'
                            ),
                            Capsule::raw(
                                'SUM(
                                    CASE
                                        WHEN type = "in" AND refundable = 1 AND valid_point = 1 THEN value
                                        WHEN type = "in" AND refundable = 0 AND valid_point = 1 THEN 0
                                        WHEN type = "out" AND valid_point = 1 THEN -value
                                    END
                                 ) AS available_cash'
                            ),
                            Capsule::raw(
                                'SUM(CASE WHEN type = "in" AND valid_point = 1 THEN value ELSE -value END) AS available_total'
                            )
                        )
                        ->where('valid_point', true)
                        ->where('user_id', self::$data['user_id'])
                        ->first();

            if($query) :

                self::set_valid(true);
                self::set_respond('wallet', $query);

            else :

                self::set_valid(false);
                self::set_message( sprintf( __('No wallet data for user %s', 'sejowoo'), self::$data['user_id']));

            endif;

        endif;

        return new static;
    }
}
