<?php
namespace SejoWoo\Database;

use Illuminate\Database\Capsule\Manager as Capsule;

Class Commission extends \SejoWoo\Database
{
    static protected $ids         = [];
    static protected $table       = 'sejowoo_commissions';
    static protected $props = array(
        'order_id'     => 0,
        'item_id'      => 0,
        'product_id'   => 0,
        'buyer_id'     => 0,
        'affiliate_id' => 0,
        'tier'         => 0,
        'quantity'     => 0,
        'commission'   => 0.0,
        'order_status' => 'on-hold',
        'paid_status'  => false
    );

    /**
     * Create table if not exists
     * @return void
     */
    static public function create_table()
    {
        parent::$table = self::$table;

        if(!Capsule::schema()->hasTable( self::table() )):
            Capsule::schema()->create( self::table(), function($table){
                $table->increments('ID');
                $table->datetime('created_at');
                $table->datetime('updated_at')->default('0000-00-00 00:00:00');
                $table->datetime('deleted_at')->default('0000-00-00 00:00:00');
                $table->integer('order_id');
                $table->integer('item_id');
                $table->integer('product_id');
                $table->integer('buyer_id');
                $table->integer('affiliate_id');
                $table->integer('tier');
                $table->integer('quantity');
                $table->float('commission', 12, 2);
                $table->string('order_status', 100)->default('on-hold');
                $table->tinyInteger('paid_status')->default(0);
            });
        endif;
    }

    /**
     * Reset all data
     * @since   1.0.0
     */
    static public function reset() {

        parent::reset();
        self::$data = self::$props;

        return new static;
    }

    /**
     * Set default data
     * @since   1.0.0
     */
    static public function set_data( array $data ) {

        $data = wp_parse_args($data, self::$props );

        self::$data['order_id']     = absint( $data['order_id'] );
        self::$data['item_id']      = absint( $data['item_id'] );
        self::$data['product_id']   = absint( $data['product_id'] );
        self::$data['buyer_id']     = absint( $data['buyer_id'] );
        self::$data['affiliate_id'] = absint( $data['affiliate_id'] );
        self::$data['tier']         = absint( $data['tier'] );
        self::$data['quantity']     = absint( $data['quantity'] );
        self::$data['commission']   = floatval( $data['commission'] );
        self::$data['order_status'] = $data['order_status'];
        self::$data['paid_status']  = boolval( $data['paid_status'] );

        parent::$data = self::$data;

        return new static;

    }

    /**
     * Validate buyer
     * @since   1.0.0
     */
    static public function validate_buyer() {

        self::$data['user_id'] = self::$data['buyer_id'];

        parent::validate_user( 'buyer' );
    }

    /**
     * Validate affiliate
     * @since   1.0.0
     */
    static public function validate_affiliate() {

        self::$data['user_id'] = self::$data['affiliate_id'];

        parent::validate_user( 'affiliate' );
    }

    /**
     * Validate tier, quantity and commission
     * @since   1.0.0
     */
    static public function validate_number( $type = 'tier' ) {

        if( 0 >= self::$data[ $type ] ) :

            self::set_valid     ( false );
            self::set_message   ( sprintf( __('%s must be over 0', 'sejowoo'), ucfirst($type) ) );
            self::set_respond   ( 'error', 'invalid-data' );

        endif;
    }

    /**
     * Validate data
     * @since   1.0.0
     * @since   1.2.2   Remove buyer validation to enable guest checkout
     */
    static public function validate() {

        if( 'add' === self::$action ) :

            self::validate_order();
            self::validate_item();
            self::validate_product();
            // self::validate_buyer();
            self::validate_affiliate();
            self::validate_order_status();
            self::validate_number( 'tier' );
            self::validate_number( 'quantity' );
            self::validate_number( 'commission' );


        elseif( 'check' === self::$action ) : // we use this method to check if the data is already in database or no

            self::validate_order();
            self::validate_item();
            self::validate_affiliate();

        elseif( 'get-by-order' === self::$action ) :

            self::validate_order();
            self::validate_order_status();

        elseif( 'get-total-by-order' === self::$action ) :

            self::validate_order();
            self::validate_order_status();

            if( 0 < self::$data['affiliate_id'] ) :
                self::validate_affiliate();
            endif;

        elseif( 'get-total-by-affiliate' === self::$action ) :

            self::validate_affiliate();

        elseif( 'update-order-status' === self::$action ) :

            self::validate_order();
            self::validate_order_status();

        elseif( 'get-user-wallet' === self::$action ) :

            self::validate_affiliate();

        endif;

    }

    /**
     * Get commission detail data, we use this method to check if the data is already in database or n
     * @since 1.0.0
     */
    static public function check() {

        self::set_action( 'check' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $data = Capsule::table( self::table() )
                        ->where('order_id',     self::$data['order_id'] )
                        ->where('item_id',      self::$data['item_id'] )
                        ->where('affiliate_id', self::$data['affiliate_id'] )
                        ->first();

            if($data) :
                self::set_valid     ( true );
                self::set_respond   ('commission', (array) $data);
            else :
                self::set_valid     ( false );
                self::set_respond   ( 'error', 'data-not-found' );
                self::set_message   ( __('Data not found', 'sejowoo') );
            endif;

        endif;

        return new static;
    }

    /**
     * Add new commission data
     * @since   1.0.0
     */
    static public function add() {

        self::set_action( 'add' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $commission = [
                'created_at'   => current_time('mysql'),
                'order_id'     => self::$data['order_id'],
                'product_id'   => self::$data['product_id'],
                'item_id'      => self::$data['item_id'],
                'buyer_id'     => self::$data['buyer_id'],
                'affiliate_id' => self::$data['affiliate_id'],
                'tier'         => self::$data['tier'],
                'quantity'     => self::$data['quantity'],
                'commission'   => self::$data['commission'],
                'order_status' => self::$data['order_status'],
                'paid_status'  => self::$data['paid_status'],
            ];

            $commission['ID'] = Capsule::table(self::table())
                            ->insertGetId($commission);

            self::set_valid     ( true );
            self::set_respond   ( 'commission', $commission );

        endif;

        return new static;

    }

    /**
     * Update order status
     * @since 1.0.0
     */
    static public function update_order_status() {

        self::set_action( 'update-order-status' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $query = Capsule::table(self::table())
                                    ->where('order_id', self::$data['order_id'])
                                    ->update(array(
                                        'order_status' => self::$data['order_status']
                                    ));

            self::set_valid     ( boolval( $query ) );

        endif;

        return new static;

    }

    /**
     * Get data based on order
     * @since   1.0.0
     */
    static public function get_by_order() {

        self::set_action( 'get-by-order' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $data = Capsule::table( self::table() )
                        ->where('order_id',     self::$data['order_id'] )
                        ->where('order_status', self::$data['order_status'] )
                        ->get();

            if($data) :
                self::set_valid     ( true );
                self::set_respond   ('commissions', $data);
            else :
                self::set_valid     ( false );
                self::set_respond   ( 'error', 'data-not-found' );
                self::set_message   ( __('Data not found', 'sejowoo') );
            endif;

        endif;

        return new static;

    }

    /**
     * Get data based on order
     * @since   1.0.0
     */
    static public function get_total_by_order() {

        self::set_action( 'get-total-by-order' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $query = Capsule::table( self::table() )
                        ->select(
                            'order_id',
                            Capsule::raw('SUM(commission) as total_commission')
                        )
                        ->where('order_id',     self::$data['order_id'] )
                        ->where('order_status', self::$data['order_status'] );

            if( 0 < self::$data['affiliate_id'] ) :
                $query = $query->where('affiliate_id',  self::$data['affiliate_id'] );
            endif;

            $data = $query->get();

            if($data) :
                self::set_valid     ( true );
                self::set_respond   ('commissions', $data);
            else :
                self::set_valid     ( false );
                self::set_respond   ( 'error', 'data-not-found' );
                self::set_message   ( __('Data not found', 'sejowoo') );
            endif;

        endif;

        return new static;

    }

    /**
     * Get total commission based by affiliate
     * @since   1.0.0
     */
    static public function get_total_by_affiliate() {

        self::set_action( 'get-total-by-affiliate' );
        self::validate();

        if( false !== self::$valid ) :

            parent::$table = self::$table;

            $data = Capsule::table( self::table() )
                        ->select(
                            Capsule::raw('SUM(commission) as total_commission')
                        )
                        ->whereIn('order_status',   array('processing', 'completed') )
                        ->where('affiliate_id',     self::$data['affiliate_id'] )
                        ->first();

            if($data) :
                self::set_valid     ( true );
                self::set_respond   ('commission', $data->total_commission);
            else :
                self::set_valid     ( false );
                self::set_respond   ( 'error', 'data-not-found' );
                self::set_message   ( __('Data not found', 'sejowoo') );
            endif;

        endif;

        return new static;

    }
}
