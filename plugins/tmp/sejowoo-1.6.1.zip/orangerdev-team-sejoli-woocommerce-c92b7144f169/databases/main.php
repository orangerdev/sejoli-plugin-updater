<?php
namespace SejoWoo;

Class Database
{
    static protected $ids      = NULL; // multiple $ids
    static protected $id       = NULL;
    static protected $valid    = true;
    static protected $data     = array();
    static protected $respond  = [];
    static protected $action   = '';
    static protected $messages = [];
    static protected $table    = NULL;
    static protected $status   = NULL;
    static protected $filter   = array(
        'start'     => NULL,
        'length'    => NULL,
        'order'     => NULL,
        'search'    => NULL,
    );

    static protected $chart = [
        'start_date' => NULL,
        'end_date'   => NULL,
        'type'       => 'daily'
    ];


    /**
     * Table define
     * @return [type] [description]
     */
    static protected function table()
    {
        global $wpdb;

        $prefix = $wpdb->prefix;

        return $prefix.self::$table;
    }

    /**
     * Reset data
     * @var [type]
     */
    static public function reset()
    {
        self::$table        = NULL;
        self::$ids          = NULL;
        self::$id           = NULL;
        self::$valid        = true;
        self::$respond      = [];
        self::$messages     = [];
        self::$filter       = [
            'start'     => NULL,
            'length'    => NULL,
            'order'     => NULL,
            'search'    => NULL
        ];

        self::$chart = [
            'start_date' => NULL,
            'end_date'   => NULL,
            'type'       => 'daily'
        ];


        self::$action       = '';

        return new static;
    }

    /**
     * Set ID to be integer
     */
    static public function set_id($id)
    {
        self::$id = absint($id);
        return new static;
    }

    /**
     * Set multiple IDS
     * @since   1.1.10
     */
    static public function set_multiple_id($ids) {
        self::$ids = array_map('intval', (array) $ids);
        return new static;
    }

    /**
     * Validate ID value
     * @since   1.0.0
     */
    static public function validate_id() {

        if( 0 >= self::$data['ID'] ) :

            self::set_valid     ( false );
            self::set_message   ( __('ID value is not valid', 'sejowoo') );
            self::set_respond   ( 'error', 'invalid-data' );

        endif;

    }

    /**
     * Validate user
     * @since 1.0.0
     */
    static public function validate_user( $type = 'user' ) {

        self::$data['user'] = get_user_by( 'id', self::$data['user_id']);

        if( !is_a( self::$data['user'], 'WP_User') ) :

            self::set_valid     ( false );
            self::set_message   ( sprintf( __('%s is not valid', 'sejowoo'), ucfirst( $type ) ) );
            self::set_respond   ( 'error', 'invalid-data' );

        endif;
    }

    /**
     * Validate order
     * @since   1.0.0
     */
    static public function validate_order( ) {

        self::$data['order']    = wc_get_order( self::$data['order_id'] );

        if( !is_a( self::$data['order'], 'WC_Order') ) :

            self::set_valid     ( false );
            self::set_message   ( __('Order is not valid', 'sejowoo') );
            self::set_respond   ( 'error', 'invalid-data' );

        endif;
    }

    /**
     * Validate order status
     * @since   1.0.0
     */
    static public function validate_order_status( ) {

        $order_statuses = wc_get_order_statuses();

        if(
            ! array_key_exists( self::$data['order_status'], $order_statuses ) &&
            ! array_key_exists( 'wc-' . self::$data['order_status'], $order_statuses )
        ) :

            self::set_valid     ( false );
            self::set_message   ( sprintf( __('Order status is not valid: %s', 'sejowoo'), self::$data['order_status']) );
            self::set_respond   ( 'error', 'invalid-data' );

        endif;
    }

    /**
     * Validate item
     * @since   1.0.0
     */
    static public function validate_item( ) {

        if( 0 === self::$data['item_id'] ) :

            self::set_valid     ( false );
            self::set_message   ( __('Item ID must not be 0', 'sejowoo') );
            self::set_respond   ( 'error', 'invalid-data' );

        endif;
    }

    /**
     * Validate product
     * @since   1.0.0
     * @since   1.1.2   Enable product_variation
     */
    static public function validate_product( ) {

        self::$data['product']    = get_post( self::$data['product_id'] );

        if(
            ! is_a( self::$data['product'], 'WP_Post') ||
            ! in_array( self::$data['product']->post_type, SEJOWOO_WC_PRODUCT_TYPES )
        ) :

            self::set_valid     ( false );
            self::set_message   ( __('Product is not valid', 'sejowoo') );
            self::set_respond   ( 'error', 'invalid-data' );

        endif;
    }

    /**
     * Validate admin data
     * @since 1.0.0
     */
    static public function validate_admin() {

        $admin = get_user_by( 'id', self::$data['admin_id']);

        if( !is_a( $admin, 'WP_User') || !$admin->has_cap('manage_options')) :

            self::set_valid     ( false );
            self::set_message   ( __('User is not valid admin', 'sejowoo') );
            self::set_respond   ( 'error', 'invalid-data' );

        endif;
    }

    /**
     * Validate absolute integer with greater than zero
     * @since   1.0.0
     */
    static public function validate_absint( $field ) {

        if( 0 >= absint(self::$data[$field]) ) :

            self::set_valid     ( false );
            self::set_message   ( sprintf( __('%s is not valid value', 'sejowoo'), $field ) );
            self::set_respond   ( 'error', 'invalid-data' );

        endif;

    }

    /**
     * Set filter data
     * @param string        $key
     * @param string|array  $value
     * @param string        $compare
     */
    static public function set_filter(string $key, $value, $compare = NULL) {
        self::$filter['search'][] = [
            'name'    => $key,
            'val'     => $value,
            'compare' => $compare
        ];

        return new static;
    }

    /**
     * Set filters from array
     * @param array $filter
     */
    static public function set_filter_from_array(array $filters) {

        foreach($filters as $key => $value) :
            if(!is_null($value)) :
                self::$filter['search'][] = [
                    'name' => $key,
                    'val'  => $value
                ];
            endif;
        endforeach;

        return new static;
    }

    /**
     * Set length and order query
     * @since   1.0.0
     */
    static protected function set_length_query($query) {

        if ( 0 < self::$filter['start'] ) :
            $start = intval( self::$filter['start'] );
            $query->offset( $start );
        endif;

        if ( 0 < self::$filter['length']) :
            $length = intval( self::$filter['length'] );
            $query->limit( $length );
        endif;

        if(!is_null(self::$filter['order']) && is_array(self::$filter['order'])) :
            foreach(self::$filter['order'] as $column => $sort) :
                $query->orderBy($column, $sort);
            endforeach;
        else :
            $query->orderBy( 'ID', 'desc' );
        endif;

        return $query;
    }

    /**
     * Set filter data to query
     */
    static protected function set_filter_query($query)
    {
        if ( !is_null( self::$filter['search'] ) && is_array( self::$filter['search'] ) ) :

            foreach ( self::$filter['search'] as $key => $value ) :
                if ( !empty( $value['val'] ) ) :
                    if(is_array($value['val'])) :
                        $query->whereIn( $value['name'],$value['val'] );
                    elseif(isset($value['compare']) && !is_null($value['compare'])) :
                        $query->where( $value['name'], $value['compare'], $value['val']);
                    else :
                        $query->where( $value['name'],$value['val'] );
                    endif;
                elseif( false === boolval($value['val']) ) :
                    $query->where( $value['name'],$value['val'] );
                endif;
            endforeach;
        endif;

        return $query;
    }

    /**
     * Set data start
     */
    static public function set_data_start($start) {
        self::$filter['start'] = absint($start);
        return new static;
    }

    /**
     * Set data length
     */
    static public function set_data_length($length) {
        self::$filter['length'] = absint($length);
        return new static;
    }

    /**
     * Set order data
     */
    static public function set_data_order($column, $sort) {
        self::$filter['order'][$column] = $sort;
        return new static;
    }

    /**
     * Set action value
     * @var [type]
     */
    static public function set_action($action = '')
    {
        self::$action = $action;
        return new static;
    }

    /**
     * Set chart start date
     * @since   1.0.0
     */
    static public function set_chart_start_date($start_date = '') {
        self::$chart['start_date'] = (empty($start_date)) ? date('Y-m-d', strtotime('-30 days')) : $start_date;
        self::$filter['search'][]  = [
            'name'    => 'created_at',
            'val'     => self::$chart['start_date'].' 00:00:00',
            'compare' => '>='
        ];

        return new static;
    }

    /**
     * Set chart start date
     * @since   1.0.0
     */
    static public function set_chart_end_date($end_date = '') {
        self::$chart['end_date']  = (empty($end_date)) ? date('Y-m-d') : $end_date;
        self::$filter['search'][] = [
            'name'    => 'created_at',
            'val'     => self::$chart['end_date'].' 23:59:59',
            'compare' => '<='
        ];
        return new static;
    }

    /**
     * Calculate to choose what chart type based on range date
     */
    static protected function calculate_chart_range_date() {

        if(!empty(self::$chart['end_date']) && !empty(self::$chart['start_date'])) :

            $end_time   = strtotime(self::$chart['end_date']);
            $start_time = strtotime(self::$chart['start_date']);
            $day_range  = ($end_time - $start_time) / DAY_IN_SECONDS;

            if(31 >= $day_range ) :
                self::$chart['type'] = 'date';
            elseif(480 < $day_range) :
                self::$chart['type'] = 'year';
            else :
                self::$chart['type'] = 'month';
            endif;
        endif;

    }

    /**
     * Set valid
     * @var bool
     */
    static public function set_valid($valid)
    {
        self::$respond['valid'] = self::$valid = $valid;
        return new static;
    }

    /**
     * Set respond messages
     * @param string $message
     */
    static protected function set_message($message = '', $type = 'error')
    {
        self::$messages[$type][] = $message;
        self::set_respond('messages',self::$messages);
    }

    /**
     * Clean respond
     * @var [type]
     */
    static protected function clear_respond()
    {
        self::$respond = [];
    }

    /**
     * Set respond meta
     * @var [type]
     */
    static protected function set_respond($key,$value)
    {
        self::$respond[$key] = $value;
    }

    /**
     * Return the respond
     * @return mixed
     */
    public function respond()
    {
        $respond = self::$respond;
        self::$respond = [];
        return $respond;
    }
}
