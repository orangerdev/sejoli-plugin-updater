<?php
namespace Sejowoo\JSON;

Class Wallet extends \Sejowoo\JSON
{
    /**
     * Construction
     */
    public function __construct() {

    }

    /**
	 * Set wallet label detail
	 * @since 	1.0.0
	 * @param 	object 	$wallet_data		Single wallet data
	 * @return 	string
	 */
	public function set_wallet_label_detail( object $wallet_data ) {

		$detail = '';

		switch($wallet_data->label) :

            case 'wallet-use' :
                $detail  = sprintf(
                                __('Penggunaan dana untuk order %s', 'sejowoo'),
                                $wallet_data->order_id
                           );
                break;

			case 'cashback' :
				$product = wc_get_product($wallet_data->product_id);
				$detail  = sprintf(
								__('Cashback dari order %s untuk produk %s', 'sejowoo'),
								$wallet_data->order_id,
								is_a($product, 'WC_Product') ? $product->get_name() : __('[Produk telah dihapus]', 'sejowoo')
						   );
				break;

			case 'affiliate' :
				$product = wc_get_product($wallet_data->product_id);
				$detail  = sprintf(
								__('Poin dari affiliasi order %s untuk produk %s, tier %s', 'sejowoo'),
								$wallet_data->order_id,
								is_a($product, 'WC_Product') ? $product->get_name() : __('[Produk telah dihapus]', 'sejowoo'),
								$wallet_data->meta_data['tier']
							);
				break;

			case 'order' :

				$detail = sprintf(
							__('Pembayaran untuk order %s', 'sejowoo'),
							$wallet_data->order_id
						  );
				break;

			case 'request-fund' :

				$detail = __('Permintaan pencairan dana', 'sejowoo');
				break;

            case 'commission' :

                $product = wc_get_product($wallet_data->product_id);
                $meta = wp_parse_args( $wallet_data->meta_data, array(
                            'tier'     => 1,
                            'quantity' => 1
                        ));

                $detail = sprintf(
                            __('Komisi dari order %s untuk produk %s x %s, tier %s', 'sejowoo'),
                            $wallet_data->order_id,
                            is_a($product, 'WC_Product') ? $product->get_name() : __('[Produk telah dihapus]', 'sejowoo'),
                            $meta['quantity'],
                            $meta['tier']
                         );
                break;

			case 'manual'	:

				$detail	= $wallet_data->meta_data['note'] . ' ' . $wallet_data->meta_data['input'];
				break;

		endswitch;

		return apply_filters( 'sejowoo/wallet/note', $detail, $wallet_data);

	}

	/**
	 * Set data for datatable
	 * Hooked via action wp_ajax_sejowoo-wallet-table, priority 1
	 * @since 	1.0.0
	 * @return 	json
	 */
	public function set_data_for_table() {

		$table  = $this->set_table_args($_POST);
        $params = wp_parse_args($_POST, array(
            'nonce' => NULL
        ));

        $total = 0;
        $data  = [];

        if(wp_verify_nonce($params['nonce'], 'sejowoo-render-wallet-table')) :

    		$wallet_data = sejowoo_get_all_user_wallet($table['filter']);

            if( !is_wp_error( $wallet_data )) :

                foreach($wallet_data as $_data) :

                    $data[] = array(
                        'user_id'         => $_data->user_id,
                        'display_name'    => $_data->display_name,
                        'user_email'      => $_data->user_email,
                        'cash_value'      => wc_price($_data->cash_value),
                        'point_value'     => wc_price($_data->point_value),
                        'used_value'      => wc_price($_data->used_value),
                        'available_cash'  => wc_price($_data->available_cash),
                        'available_total' => wc_price($_data->available_total),
                        'detail_url'      => add_query_arg(array(
                                                'page'    => 'sejowoo-wallet-management',
												'user_id' => $_data->user_id
                                            ), admin_url('admin.php'))
                    );

                endforeach;

                $total = count($data);

            endif;


        endif;

        echo wp_send_json([
            'table'           => $table,
            'draw'            => $table['draw'],
            'data'            => $data,
            'recordsTotal'    => $total,
            'recordsFiltered' => $total
        ]);

        exit;

	}

	/**
	 * Set data for single user datatable
	 * Hooked via action wp_ajax_sejowoo-single-wallet-table, priority 1,
	 * Hooked via action sejowoo-ajax/get-wallet-list, priority 1
	 * @since 	1.0.0
	 * @return 	json
	 */
	public function set_data_for_single_user_table() {

		$table  = $this->set_table_args($_POST);
        $params = wp_parse_args($_POST, array(
            'nonce' 	=> NULL,
			'user_id'   => NULL
        ));

        $total = 0;
        $data  = [];

        if(
            wp_verify_nonce($params['nonce'], 'sejowoo-render-single-wallet-table')
        ) :

			$table['filter']['user_id']	= ( empty($params['user_id']) || !current_user_can('manage_sejoli_wallet') ) ?
											get_current_user_id() :
											intval($params['user_id']);

            if( !current_user_can('manage_sejoli_wallet') ) :
                $table['filter']['valid_point'] = true;
            endif;

    		$return = sejowoo_wallet_get_history($table['filter'], $table);

            if(false !== $return['valid']) :

                foreach($return['wallet'] as $_data) :

                    $data[] = array(
						'created_at'	=> date('Y/m/d', strtotime($_data->created_at)),
						'detail'        => $this->set_wallet_label_detail($_data),
                        'point' 		=> wc_price($_data->value),
                        'type'  		=> $_data->type,
						'refundable'    => boolval($_data->refundable)
                    );

                endforeach;

                $total = count($data);

            endif;

        endif;

        echo wp_send_json([
            'table'           => $table,
            'draw'            => $table['draw'],
            'data'            => $data,
            'recordsTotal'    => $total,
            'recordsFiltered' => $total
        ]);

        exit;
	}

	/**
	 * Create csv file
	 * Hooked via action wp_ajax_sejowoo-wallet-export-csv, priority 1
	 * @return 	file|json
	 */
	public function create_csv_file() {

		$table  = \Sejowoo\Model\JSON::set_table_args($_POST);
        $params = wp_parse_args($_POST, array(
            'nonce' => NULL
        ));

		if(
			wp_verify_nonce( $_POST['nonce'], 'sejowoo-wallet-export-csv') &&
			current_user_can('manage_sejoli_wallet')
		) :

			$wallet_data = sejowoo_get_all_user_wallet($table['filter']);

            if( !is_wp_error( $wallet_data )) :

				header('Content-Type: text/csv');
				header('Content-Disposition: attachment; filename="sejowoo-wallet-per-'.date('d-m-Y').'.csv"');

				$fp = fopen('php://output', 'wb');

				fputcsv( $fp, array(
					'user_id',
					'name',
					'email',
					'cash',
					'point',
					'used',
					'available_cash',
					'available_total'
				));

                foreach($wallet_data as $_data) :

					fputcsv( $fp, array(
                        $_data->user_id,
                        $_data->display_name,
                        $_data->user_email,
                        $_data->cash_value,
                        $_data->point_value,
                        $_data->used_value,
                        $_data->available_cash,
                        $_data->available_total
                    ));

                endforeach;

                fclose($fp);

			else :

				wp_send_json_error( $wallet_data );

            endif;

		endif;

		exit;
	}

	/**
	 * Create csv file for a single user
	 * Hooked via action wp_ajax_sejowoo-single-wallet-export-csv, priority 1
	 * @return 	file|json
	 */
	public function create_csv_file_for_single() {

		$table  = \Sejowoo\Model\JSON::set_table_args($_POST);
        $params = wp_parse_args($_POST, array(
            'nonce' 	=> NULL,
			'user_id'   => 0
        ));

		if(wp_verify_nonce( $_POST['nonce'], 'sejowoo-single-wallet-export-csv')) :

			$table['filter']['user_id']	= ( empty($params['user_id']) || ! current_user_can('manage_sejoli_wallet')) ?
											get_current_user_id() :
											intval($params['user_id']);

			$table['length'] = 0;

			$return = sejowoo_wallet_get_history($table['filter'], $table);

            if(false !== $return['valid']) :

				$wallet = $return['wallet'];
				$user   = new \WC_Customer($wallet[0]->user_id);
				$name   = strtoupper( sanitize_title( $user->get_display_name() ) );

				header('Content-Type: text/csv');
				header('Content-Disposition: attachment; filename="sejowoo-wallet-by-user-' . $name . '-' . date('d-m-Y') . '.csv"');

				$fp = fopen('php://output', 'wb');

				fputcsv( $fp, array(
					'date',
					'detail',
					'point',
					'type',
					'refundable',
				));

                foreach($wallet as $_data) :


					fputcsv( $fp, array(
						date('Y/m/d', strtotime($_data->created_at)),
						$this->set_wallet_label_detail($_data),
                        $_data->value,
                        $_data->type,
						(true === boolval($_data->refundable) ) ? 'Y' : 'N'
                    ));

                endforeach;

                fclose($fp);

			endif;

		endif;

		exit;
	}
}
