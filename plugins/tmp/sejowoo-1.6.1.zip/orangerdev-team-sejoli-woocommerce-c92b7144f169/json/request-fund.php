<?php
namespace Sejowoo\JSON;

Class RequestFund extends \Sejowoo\JSON
{
    /**
     * Construction
     */
    public function __construct() {

    }

    /**
     * Submi request fund
     * Hooked via action sejowoo-ajax/submit-request-fund, priority 100
     * @since   1.0.0
     * @return  json
     */
    public function submit_request() {

        $response = array(
            'valid'   => true,
            'message' => __('You don\'t have any permission to do this request', 'sejowoo')
        );

        $file = $messages = array();

        $post_data = wp_parse_args( $_POST, array(
                        'bank_name'          => NULL,
                        'bank_account'       => NULL,
                        'bank_account_owner' => NULL,
                        'nonce'              => NULL
                     ));

        if(
            is_user_logged_in() &&
            wp_verify_nonce($post_data['nonce'], 'sejowoo-send-request-fund')
        ) :

            $user_wallet = sejowoo_get_single_user_wallet();

            $available_cash = (isset($user_wallet['available_cash'])) ? $user_wallet['available_cash'] : 0;

            if( 0 >= $available_cash ) :
                $response['valid'] = false;
                $messages[]        = __('Jumlah dana yang tersedia tidak mencukupi untuk permintaan pencairan', 'sejowoo');
            endif;

            if( empty( $post_data['bank_name'] ) ) :

                $response['valid'] = false;
                $messages[] = __('Anda belum memasukkan nama bank tujuan pencairan', 'sejowoo');

            endif;

            if( empty( $post_data['bank_account'] ) ) :

                $response['valid'] = false;
                $messages[] = __('Anda belum memasukkan nomor rekening bank tujuan pencairan', 'sejowoo');

            endif;

            if( empty( $post_data['bank_account_owner'] ) ) :

                $response['valid'] = false;
                $messages[] = __('Anda belum memasukkan nama pemilik rekening bank tujuan pencairan', 'sejowoo');

            endif;

            if( !isset($_FILES['id_card']) ) :

                $response['valid'] = false;
                $messages[] = __('Anda belum mengupload KTP / SIM / Bukti diri anda', 'sejowoo');

            else :

                $user = new \WC_Customer( get_current_user_id() );
                $file = $_FILES['id_card'];

                $uploaded = sejowoo_upload_file( $file, 'image', array(
                    'from'  => 'request-fund',
                    'title' => sprintf(
                        __('REQUEST-FUND-BY-%s-%s', 'sejowoo'),
                        $user->get_display_name(),
                        date('Y-m-d')
                    )
                ));

                if( is_wp_error( $uploaded ) ) :
                    $response['valid'] = false;
                    $messages[]        = $uploaded->get_error_message();
                endif;

            endif;

        else :

            $response['valid']   = false;

        endif;

        // Not valid
        if( false === $response['valid'] ) :
            $response['message'] = implode( '<br />', $messages );
        else :

            $request_data = array(
                'updated_at'         => current_time('mysql'),
                'bank_name'          => $post_data['bank_name'],
                'bank_account'       => $post_data['bank_account'],
                'bank_account_owner' => $post_data['bank_account_owner'],
                'id_card'            => $uploaded['file']['url'],
            );

            $user->update_meta_data( 'request_fund_info', $request_data);

            $user->save_meta_data();

            $request_data['amount']       = $user_wallet['available_cash'];
            $request_data['id_card_file'] = $uploaded['file']['file'];

            if( ! class_exists('Sejowoo\Email\AdminRequestFund') ) :
                \WC_Emails::instance();
            endif;

            /**
             * Hooked with Sejowoo/Admin/RequestFund::do_request, priority 5
             * Hooked with Sejowoo/Email/UserRequestFund::trigger_email, priority 10
             * Hooked with Sejowoo/Email/AdminRequestFund::trigger_email, priority 20
             */
            do_action( 'sejowoo/fund/send-request', $user, $request_data);

            $response['message'] = __('Permintaan pencairan dana sudah berhasil dilakukan. Mohon waktunya agar tim kami melakukan pencairan', 'sejowoo');

        endif;

        echo wp_send_json( $response );

        exit;
    }

    /**
	 * Set data for datatable
	 * Hooked via action wp_ajax_sejowoo-request-fund-table, priority 1
	 * @since 	1.0.0
	 * @return 	json
	 */
	public function set_data_for_table() {

		$table  = $this->set_table_args($_POST);
        $params = wp_parse_args($_POST, array(
            'nonce' => NULL
        ));

        $total = 0;
        $data  = [];

        if(wp_verify_nonce($params['nonce'], 'sejowoo-render-request-table')) :

    		$respond = sejowoo_get_request_fund_data($table['filter']);

            if( !is_wp_error( $respond )) :

                foreach($respond['request_funds'] as $_data) :

                    $data[] = array(
                        'ID'           => $_data->ID,
                        'created_at'   => date('Y M d', strtotime($_data->created_at)),
                        'user_id'      => $_data->user_id,
                        'display_name' => $_data->display_name,
                        'amount'       => wc_price($_data->amount),
                        'status'       => $_data->status
                    );

                endforeach;

                $total = count($data);

            endif;


        endif;

        echo wp_send_json([
            'table'           => $table,
            'draw'            => $table['draw'],
            'data'            => $data,
            'recordsTotal'    => $total,
            'recordsFiltered' => $total
        ]);

        exit;

	}

    /**
     * Get single request fund detail
     * Hooked via action wp_ajax_sejowoo-get-request-fund-detail, priority 1
     * @since   1.0.0
     * @return  json
     */
    public function get_detail() {

        $params = wp_parse_args($_GET, array(
            'ID'    => 0,
            'nonce' => NULL
        ));

        $response = array(
            'valid'   => false,
            'data'    => array(),
            'messages' => ''
        );

        if(
            current_user_can( 'manage_sejoli_wallet' ) &&
            wp_verify_nonce( $params['nonce'], 'sejowoo-get-request-fund-detail')
        ) :

            $request_data = sejowoo_get_single_request_fund( $params['ID'] );

            if( is_wp_error( $request_data ) ) :
                $response['messages'] = implode('<br />', $request_data->get_error_messages() );
            else :
                $request_data['form'] = ( 'requested' === $request_data['status'] ) ? true : false;
                $response['valid']    = true;
                $response['data']     = $request_data;
            endif;

        endif;

        echo wp_send_json($response);
    }

    /**
     * Update request status by administrator
     * Hooked via action wp_admin_sejowoo-update-request-fund, priority 1
     * @since   1.0.0
     * @return  json
     */
    public function update_status() {

        $response = array(
            'valid'   => false,
            'message' => __('Terjadi kesalahan pada sistem', 'sejowoo')
        );

        $params = wp_parse_args( $_POST, array(
            'nonce' => NULL,
            'ID'    => NULL,
            'status'=> NULL,
            'note'  => NULL
        ));

        $file = $_FILES['proof'];

        if(
            current_user_can( 'manage_sejoli_wallet' ) &&
            wp_verify_nonce( $params['nonce'], 'sejowoo-update-request-fund-status' )
        ) :

            $admin        = wp_get_current_user();
            $request_data = sejowoo_get_single_request_fund( $params['ID'] );

            if( is_wp_error( $request_data ) ) :
                $response['message'] = implode('<br />', $request_data->get_error_messages() );
            else :

                $uploaded = array(
                    'file'  => NULL,
                    'url'   => NULL
                );

                $uploaded = sejowoo_upload_file( $file, 'image', array(
                    'from'  => 'request-fund',
                    'title' => sprintf(
                        __('APPROVED-TRANSFER-BY-%s-%s', 'sejowoo'),
                        $admin->display_name,
                        date('Y-m-d')
                    )
                ));

                if( 'approved' === $params['status'] ) :

                    if( is_wp_error( $uploaded ) ) :
                        $response['message'] = $uploaded->get_error_message();
                    else :
                        $response['valid']  = true;
                        $response['message'] = __('Anda telah menerima pencairan dana', 'sejowoo');
                    endif;

                elseif( 'rejected' === $params['status'] ) :

                    $uploaded = array(
                        'file'  => array(
                            'url'   => '',
                            'file'  => ''
                        )
                    );

                    $response['valid']   = true;
                    $response['message'] = __('Anda telah menolak pencairan dana', 'sejowoo');
                else :
                    $response['message'] = __('Anda belum menentukan status pencairan', 'sejowoo');
                endif;

            endif;

            if( true === $response['valid'] ) :

                $request_data['admin']    = $admin->display_name;
                $request_data['admin_id'] = get_current_user_id();
                $request_data['status']   = $params['status'];

                $request_data['meta_data'] = array_merge($request_data['meta_data'], array(
                    'note'       => $params['note'],
                    'proof'      => $uploaded['file']['url'],
                    'proof_file' => $uploaded['file']['file']
                ));

                if( ! class_exists('Sejowoo\Email\UserRequestFundProcessed') ) :
                    \WC_Emails::instance();
                endif;

                /**
                 * Hooked with Sejowoo/Admin/RequestFund::update_request, priority 5
                 * Hooked with Sejowoo/Admin/Wallet::update_point_status_when_request_fund_processed, priority 10
                 * Hooked with Sejowoo/Email/UserRequestFundProcessed::trigger_email, priority 15
                 * Hooked with Sejowoo/Email/AdminRequestFundProcessed::trigger_email, priority 20
                 */
                do_action( 'sejowoo/fund/update-request', $admin, $request_data);

            endif;

        endif;

        echo wp_send_json($response);
        exit;
    }

}
