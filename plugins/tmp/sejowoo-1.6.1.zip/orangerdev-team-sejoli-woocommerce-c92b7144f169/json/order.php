<?php
namespace Sejowoo\JSON;

Class Order extends \Sejowoo\JSON
{
    /**
     * Construction
     */
    public function __construct() {

    }

    /**
     * Set user options
     * @since   1.0.0
     * @return  json
     */
    public function set_for_options() {

    }

    /**
     * Set table data
     * Hooked via action sejowoo-ajax/get-order-list, priority 1
     * @since   1.0.0
     * @return  json
     */
    public function set_for_table() {

		$table = $this->set_table_args($_POST);
        $json  = array(
            'table'           => $table,
            'draw'            => $table['draw'],
            'data'            => array(),
            'recordsTotal'    => 0,
            'recordsFiltered' => 0,
        );

        if( isset($_POST['nonce']) && wp_verify_nonce($_POST['nonce'], 'sejowoo-render-order-table') ) :

            if( isset($_POST['backend']) && current_user_can( 'manage_options' ) ) :

            else :
                $table['filter']['affiliate_id'] = get_current_user_id();
            endif;

            $respond = sejowoo_get_orders($table['filter'], $table);

    		if(false !== $respond['valid']) :
    			$json['data']            = $respond['orders'];
                $json['recordsTotal']    = $respond['total'];
                $json['recordsFiltered'] = $respond['total'];
    		endif;

        endif;

		echo wp_send_json($json);

		exit;
    }

}
