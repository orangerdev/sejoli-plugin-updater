<?php
namespace Sejowoo\JSON;

Class AffiliateNetwork extends \Sejowoo\JSON
{
    /**
     * Construction
     */
    public function __construct() {

    }

    /**
     * Translate data to jstree json data format
     * @since   1.0.0
     * @param   array   $list
     * @param   string  $parent
     * @param   string  $type
     * @return  array
     */
    protected function translate_for_jstree( $list, $parent = '#', $type = 'detail' ) {

        $data = array();

        foreach( $list as $i => $single ) :

            $display_name = $avatar_url = '';

            if( 'detail' === $type ) :

                $user         = get_user_by( 'id', $single['id'] );
                $display_name = $user->display_name;
                $avatar_url   = get_avatar_url( $user->ID );

                $data[] = array(
                    'id'       => $single['id'],
                    'parent'   => $parent,
                    'text'     => $display_name,
                    'icon'     => $avatar_url,
                    'a_attr'   => array(
                        'data-ID'   => $single['id']
                    )
                );

            else :

                $data[] = $single['id'];

            endif;

            if(
                is_array($single['downlines']) &&
                0 < count($single['downlines'])
            ) :
                $data = array_merge( $data, $this->translate_for_jstree( $single['downlines'], $single['id'], $type ) );
            endif;

        endforeach;

        return $data;
    }

    /**
     * Get network list
     * Hooked via action sejowoo-ajax/get-network-list, priority 1
     * @since   1.0.0
     * @return  void
     */
    public function get_network_list() {

        $response = array(

        );

        $args = wp_parse_args( $_GET, array(
            'node'  => 0,
            'nonce' => ''
        ));

        if(
            is_user_logged_in() &&
            wp_verify_nonce( $args['nonce'], 'sejowoo-get-network-list' )
        ) :

            $data = sejowoo_user_get_downlines(
                        get_current_user_id(),
                        sejowoo_get_max_downline_tiers()
                    );

            if( false !== $data ) :
                $response = $this->translate_for_jstree( $data, '#' );
            endif;

        endif;

        wp_send_json( $response );

    }

    /**
     * Get single network detail
     * Hooked via action sejowoo-ajax/get-network-detail, priority 1
     * @since   1.0.0
     * @return  void
     */
    public function get_network_detail() {

        $response = array(
            'valid'     => true,
            'message'   => __('Maaf, anda tidak berhak untuk mengakses data affiliate.', 'sejowoo')
        );

        $args = wp_parse_args( $_GET, array(
            'id'    => 0,
            'nonce' => ''
        ));

        if(
            is_user_logged_in() &&
            wp_verify_nonce( $args['nonce'], 'sejowoo-get-network-detail' ) &&
            !empty($args['id'])
        ) :
            $data = sejowoo_user_get_downlines(
                        get_current_user_id(),
                        sejowoo_get_max_downline_tiers()
                    );

            if( false !== $data ) :

                $tree = $this->translate_for_jstree( $data, '#', 'simple' );

                if( in_array( $args['id'], $tree ) ) :

                    $customer = new \WC_Customer( $args['id'] );

                    $response['user']   = array(
                        'name'       => $customer->get_display_name(),
                        'email'      => sejowoo_display_buyer_email( $customer->get_email() ),
                        'phone'      => sejowoo_display_buyer_phone( $customer->get_billing_phone() ),
                        'address'    => sejowoo_display_buyer_address( $customer->get_billing_address() ),
                        'commission' => wc_price( sejowoo_get_total_affiliate_commission( $args['id'] ) )
                    );

                endif;

            else :
                $response['valid']   = false;
                $response['message'] = __('Anda belum memiliki jaringan affiliasi.', 'sejowoo');
            endif;
        else :

            $response['valid']  = false;

        endif;

        $response['args'] = $args;

        wp_send_json( $response );

    }

}
