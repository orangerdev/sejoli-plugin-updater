<?php
namespace Sejowoo\JSON;

/**
 * @since   1.0.0
 * @var [type]
 */
Class BulkUpdateProduct extends \Sejowoo\JSON
{
    /**
     * Construction
     */
    public function __construct() {

    }

    /**
     * Get products based on arguments
     * @since   1.0.0
     * @param   array   $args
     * @return  array
     */
    protected function get_products( $args ) {

        $args = wp_parse_args( $args, array(
            'post_status' => 'any',
            'post_type'   => SEJOWOO_PRODUCT_CPT,
            'fields'      => 'ids',
        ));

        return \SejoWoo\Database\Post::set_args($args)->set_total(999999)->get();

    }

    /**
     * Update multi commission product
     * Hooked via action wp_ajax_bulk-update-commission-product, priority 1
     * @since   1.0.0
     * @return  json
     */
    public function update_commission() {

        $response = array(
            'valid'   => true,
            'message' => __('Maaf, anda tidak bisa melakukan proses ini', 'sejowoo')
        );

        $post_data = wp_parse_args( $_POST, array(
            'nonce'      => NULL,
            'categories' => array(),
            'commission' => 0
        ));

        if(
            current_user_can( 'manage_woocommerce' ) &&
            wp_verify_nonce( $post_data['nonce'], 'bulk-update-commission-product' )
        ) :

            $post_data['categories'] = explode('|', $post_data['categories']);

            if( 0 === $post_data['commission']) :

                $response['valid']   = false;
                $response['message'] = __('Anda belum memilih tipe komisi', 'sejowoo');

            endif;

            if( true === $response['valid'] ) :

                $args = array();

                if(
                    is_array($post_data['categories']) &&
                    0 < count($post_data['categories']) &&
                    !empty($post_data['categories'][0])
                ) :
                    $args['tax_query'] = array(
                        array(
                            'taxonomy' => 'product_cat',
                            'field'    => 'term_id',
                            'terms'    => $post_data['categories']
                        )
                    );
                endif;

                $products = $this->get_products( $args );

                foreach( $products as $product_id ) :

                    $product = wc_get_product( $product_id );

                    if( $product->is_type( 'variable') ) :

                        $variations_id = wp_list_pluck( $product->get_available_variations(), 'variation_id');

                        foreach( $variations_id as $var_id ) :

                            update_post_meta( $var_id, 'sejowoo_commission', intval( $post_data['commission'] ) );

                        endforeach;

                    else :

                        update_post_meta( $product_id, 'sejowoo_commission', intval( $post_data['commission'] ) );

                    endif;

                endforeach;

                $response['message'] = sprintf( __('Total %s produk telah diupdate tipe komisinya.', 'sejowoo'), count($products) );

            endif;

        else :

            $response['valid'] = false;

        endif;

        echo wp_send_json( $response );
    }

    /**
     * Update multi cashback product
     * Hooked via action wp_ajax_bulk-update-cashback-product, priority 1
     * @since   1.0.0
     * @return  json
     */
    public function update_cashback() {

        $response = array(
            'valid'   => true,
            'message' => __('Maaf, anda tidak bisa melakukan proses ini', 'sejowoo')
        );

        $post_data = wp_parse_args( $_POST, array(
            'nonce'      => NULL,
            'categories' => array(),
            'cashback'   => array()
        ));

        $cashback = wp_parse_args( $post_data['cashback'], array(
            'enabled'     => false,
            'value'      => 0,
            'type'       => 'fixed',
            'refundable' => false
        ));

        if(
            current_user_can( 'manage_woocommerce' ) &&
            wp_verify_nonce( $post_data['nonce'], 'bulk-update-cashback-product' )
        ) :

            $post_data['categories'] = explode('|', $post_data['categories']);

            if( true === $response['valid'] ) :

                $args = array();

                if(
                    is_array($post_data['categories']) &&
                    0 < count($post_data['categories']) &&
                    !empty($post_data['categories'][0])
                ) :
                    $args['tax_query'] = array(
                        array(
                            'taxonomy' => 'product_cat',
                            'field'    => 'term_id',
                            'terms'    => $post_data['categories']
                        )
                    );
                endif;

                $products = $this->get_products( $args );

                foreach( $products as $product_id ) :

                    $product = wc_get_product( $product_id );

                    if( $product->is_type( 'variable') ) :

                        $variations_id = wp_list_pluck( $product->get_available_variations(), 'variation_id');

                        foreach( $variations_id as $var_id ) :

                            update_post_meta( $var_id, 'cashback_enable',       ( 'true' === $cashback['enabled'] ) ? 'yes' : NULL );
                            update_post_meta( $var_id, 'cashback_value',        floatval( $cashback['value'] ) );
                            update_post_meta( $var_id, 'cashback_type',         $cashback['type'] );
                            update_post_meta( $var_id, 'cashback_refundable',   ( 'true' === $cashback['refundable'] ) ? 'yes' : NULL );

                        endforeach;

                    else :

                        update_post_meta( $product_id, 'cashback_enable',       ( 'true' === $cashback['enabled'] ) ? 'yes' : NULL );
                        update_post_meta( $product_id, 'cashback_value',        floatval( $cashback['value'] ) );
                        update_post_meta( $product_id, 'cashback_type',         $cashback['type'] );
                        update_post_meta( $product_id, 'cashback_refundable',   ( 'true' === $cashback['refundable'] ) ? 'yes' : NULL );

                    endif;

                endforeach;

                $response['message'] = sprintf( __('Total %s produk telah diupdate nilai cashback-nya.', 'sejowoo'), count($products) );

            endif;

        else :

            $response['valid'] = false;

        endif;

        echo wp_send_json( $response );
    }

    /**
     * Calculate price based on request
     * @since   1.1.0
     * @param   float   $price      Given product price
     * @param   array   $config
     * @return  float
     */
    protected function calculate_price( $price, array $config ) {

        $calc = 0;
        $temp_price = $price;

        if( 'percentage' === $config['type']) :

            $calc = $price * floatval($config['value']) / 100;

        else :

            $calc = floatval( $config['value']);

        endif;

        if( 'increase' === $config['calculation']) :
            $temp_price += $calc;
        else :
            $temp_price -= $calc;
        endif;

        $price = ( $temp_price > 0 ) ? $temp_price : 0;

        return $price;
    }

    /**
     * Update multi product price
     * Hooked via action wp_ajax_bulk-update-product-price-product, priority 1
     * @since   1.0.0
     * @return  json
     */
    public function update_product_price() {

        $response = array(
            'valid'   => true,
            'message' => __('Maaf, anda tidak bisa melakukan proses ini', 'sejowoo')
        );

        $post_data = wp_parse_args( $_POST, array(
            'nonce'         => NULL,
            'categories'    => array(),
            'product_price' => array()
        ));

        $setting = wp_parse_args( $post_data['product_price'], array(
            'calculation' => 'increase',
            'value'       => 0,
            'type'        => 'fixed',
        ));

        if(
            current_user_can( 'manage_woocommerce' ) &&
            wp_verify_nonce( $post_data['nonce'], 'bulk-update-product-price' )
        ) :

            $post_data['categories'] = explode('|', $post_data['categories']);

            if( 0 === $setting['value']) :

                $response['valid']   = false;
                $response['message'] = __('Anda belum mengisi nilai perubahan harga', 'sejowoo');

            endif;

            if( true === $response['valid'] ) :

                $args = array();

                if(
                    is_array($post_data['categories']) &&
                    0 < count($post_data['categories']) &&
                    !empty($post_data['categories'][0])
                ) :
                    $args['tax_query'] = array(
                        array(
                            'taxonomy' => 'product_cat',
                            'field'    => 'term_id',
                            'terms'    => $post_data['categories']
                        )
                    );
                endif;

                $products = $this->get_products( $args );

                foreach( $products as $product_id ) :

                    $product = wc_get_product( $product_id );

                    // For variation product
                    if( $product->is_type( 'variable') ) :

                        $variations_id = wp_list_pluck( $product->get_available_variations(), 'variation_id');

                        foreach( $variations_id as $var_id ) :

                            $var_product = wc_get_product( $var_id );
                            $price         = 0;
                            $regular_price = floatval( get_post_meta( $var_id, '_regular_price', true) );
                            $sale_price    = floatval( get_post_meta( $var_id, '_sale_price', true) );

                            $price = $regular_price = $this->calculate_price( $regular_price, $setting );

                            if( 0 < $sale_price) :
                                $sale_price = $this->calculate_price( $sale_price, $setting );
                            endif;

                            $var_product->set_regular_price( $regular_price );

                            if( 0 < $sale_price) :
                                $var_product->set_sale_price( $sale_price );
                                $price = $sale_price;
                            else :
                                $var_product->set_sale_price( 0 );
                            endif;

                            $var_product->set_price( $price );
                            $var_product->save();

                        endforeach;

                    // For regular product
                    else :

                        $price         = 0;
                        $regular_price = floatval( get_post_meta( $product_id, '_regular_price', true) );
                        $sale_price    = floatval( get_post_meta( $product_id, '_sale_price', true) );

                        $price = $regular_price = $this->calculate_price( $regular_price, $setting );

                        if( 0 < $sale_price) :
                            $sale_price = $this->calculate_price( $sale_price, $setting );
                        endif;

                        $product->set_regular_price( $regular_price );

                        if( 0 < $sale_price) :
                            $product->set_sale_price( $sale_price );
                            $price = $sale_price;
                        else :
                            $product->set_sale_price( NULL );
                        endif;

                        $product->set_price( $price );
                        $product->save();

                    endif;

                endforeach;

                $response['message'] = sprintf( __('Total %s produk telah diupdate harga produknya.', 'sejowoo'), count($products) );

            endif;

        else :

            $response['valid'] = false;

        endif;

        echo wp_send_json( $response );
    }
}
