<?php
namespace Sejowoo\JSON;

Class Product extends \Sejowoo\JSON
{
    /**
     * Construction
     */
    public function __construct() {

    }

    /**
     * Set user options
     * Hooked via action sejowoo-ajax/get-product-options, priority 1
     * @since   1.0.0
     * @return  json
     */
    public function set_for_options() {

        global $post;

        $options = [];
        $args    = wp_parse_args($_GET,[
            'term'  => '',
            'nonce' => ''
        ]);

        if( wp_verify_nonce($args['nonce'], 'sejowoo-render-product-options') ) :

            $query = array(
                's'           => $args['term'],
                'post_type'   => SEJOWOO_WC_PRODUCT_TYPES,
                'post_status' => 'publish'
            );

            $products = \SejoWoo\Database\Post::set_args($query)
                                ->set_total(300)
                                ->get();


            foreach( (array) $products as $product ) :

                $options[] = [
                    'id'   => $product->ID,
                    'text' => sprintf(
                                    _x(' %s #%s', 'product-options', 'sejowoo'),
                                    $product->post_title,
                                    $product->ID
                              )
                ];

            endforeach;

            wp_reset_query();

        endif;

        wp_send_json([
            'results' => $options
        ]);

        exit;
    }

}
