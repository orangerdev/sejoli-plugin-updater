<?php
namespace Sejowoo\JSON;

use Illuminate\Database\Capsule\Manager as Capsule;

Class Leaderboard extends \Sejowoo\JSON
{
    /**
     * Construction
     */
    public function __construct() {

    }

    /**
     * Get calculation data
     * @param  string   $calculation
     * @param  array    $products
     * @param  array    $date
     * @return array
     */
    protected function calculate_value( $calculation, $products = array(), $date ) {

        global $wpdb;

        $data = array();

        $query = Capsule::table( Capsule::raw( $wpdb->prefix . 'sejowoo_commissions AS commission')  )
                    ->join(
                        $wpdb->users . ' AS user', 'user.ID', '=', 'commission.affiliate_id'
                    );

        if( 'omset' === $calculation ) :

            $query = $query->join( $wpdb->prefix . 'woocommerce_order_itemmeta AS itemmeta', 'itemmeta.order_item_id', '=', 'commission.item_id')
                            ->select(
                                'commission.affiliate_id',
                                'user.display_name',
                                Capsule::raw( 'SUM( itemmeta.meta_value ) AS value' )
                            )
                            ->where( 'itemmeta.meta_key', '_line_subtotal' );

        elseif( 'quantity' === $calculation ) :

            $query = $query->select(
                'commission.affiliate_id',
                'user.display_name',
                Capsule::raw( 'SUM( commission.quantity ) AS value' )
            );

        elseif( 'commission' === $calculation ) :

            $query = $query->select(
                'commission.affiliate_id',
                'user.display_name',
                Capsule::raw( 'SUM( commission.commission ) AS value' )
            );

        endif;

        if( 0 < count( $products ) && !empty($products[0])) :
            $query = $query->whereIn( 'commission.product_id', $products );
        endif;

        if( !current_user_can('manage_sejoli_sejoli') ) :
            $query = $query->limit( absint( carbon_get_theme_option('sejowoo_limit_leaderboard_data') ) );
        endif;

        $data = $query
                    ->where( 'commission.created_at', '>=', $date['start'] . ' 00:00:00' )
                    ->where( 'commission.created_at', '<=', $date['end'] . ' 23:59:59' )
                    ->whereIn('commission.order_status', array('completed') )
                    ->orderBy('value', 'DESC')
                    ->groupBy('commission.affiliate_id')
                    ->get();

        return $data;
    }

    /**
     * Set for table
     */
    public function set_for_table() {

        $table  = $this->set_table_args($_POST);

        $post = wp_parse_args( $_POST, array(
            'nonce'       => '',
            'backend'     => false,
            'products'    => array(),
            'calculation' => 'commission',
            'date_range'  => date('Y-m-d H:i:s') . ' - ' . date('Y-m-d H:i:s', strtotime('-30 days') )
        ));

        $data  = array();
        $total = 0;

        if( wp_verify_nonce( $post['nonce'], 'sejowoo-render-table-list') ) :

            $date_array = explode(' - ', $post['date_range'] );

            $date       = array(
                'start' => $date_array[0],
                'end'   => $date_array[1]
            );

            $user_data = $this->calculate_value( $post['calculation'], $post['products'], $date );

            $i = 1;
            $display_point = boolval( carbon_get_theme_option('sejowoo_display_leaderboard_point') );
            $value         = 0;

            foreach($user_data as $_data ) :

                if( false !== $display_point || current_user_can('manage_sejoli_sejoli') ) :

                    $value = in_array( $post['calculation'], array('commission', 'omset') ) ?
                                    wc_price($_data->value) :
                                    $_data->value;

                endif;

                $data[] = array(
                    'number'    => $i,
                    'affiliate' => $_data->display_name,
                    'avatar'    => get_avatar_url( $_data->affiliate_id ),
                    'value'     => $value
                );

                $i++;
            endforeach;
        endif;

        echo wp_send_json([
            'table'           => $table,
            'draw'            => $table['draw'],
            'data'            => $data,
            'recordsTotal'    => $total,
            'recordsFiltered' => $total
        ]);
    }
}
