<?php
namespace Sejowoo\JSON;

Class Coupon extends \Sejowoo\JSON
{
    /**
     * Parent coupon
     * @since   1.0.0
     * @var     WC_Coupon
     */
    protected $parent_coupon;

    /**
     * Construction
     */
    public function __construct() {

    }

    public function update_affiliate_coupons() {

        $response = array(
            'message' => __('Maaf, anda tidak berhak untuk mengupdate kupon affiliasi', 'sejowoo')
        );

        $post_data = wp_parse_args( $_POST, array(
            'nonce' => '',
            'id'    => 0
        ));

        if(
            is_user_logged_in() &&
            current_user_can('edit_shop_coupons') &&
            wp_verify_nonce($post_data['nonce'], 'sejowoo-update-affiliate-coupons') &&
            ! empty($post_data['id'])
        ) :

            $total_updated_coupons = sejowoo_update_affiliate_coupons( $post_data['id'] );
            $response['message']   = sprintf(
                                        __('Total %s kupon affiliasi sudah berhasil diupdate', 'sejowoo'),
                                        $total_updated_coupons
                                    );
        endif;

        wp_send_json($response);

        exit;
    }

    /**
	 * Set data for datatable
	 * Hooked via action sejowoo-ajax/render-affiliate-coupon-table, priority 1
	 * @since 	1.0.0
	 * @return 	json
	 */
	public function set_data_for_table() {

		$table  = $this->set_table_args($_POST);
        $params = wp_parse_args($_POST, array(
            'nonce' => NULL
        ));

        $total = 0;
        $data  = [];

        if(wp_verify_nonce($params['nonce'], 'sejowoo-render-affiliate-coupon-table')) :

            $args = array(
                'affiliate_id' => get_current_user_id()
            );

            $return = sejowoo_get_available_coupon_list($args, $table);

            if(false !== $return['valid']) :

                foreach($return['coupons'] as $_data) :

                    $coupon = new \WC_Coupon( $_data->ID );

                    if( 'percent' === $coupon->get_discount_type() ) :
                        $discount = $coupon->get_amount() . '%';
                    else :
                        $discount = strip_tags( wc_price( $coupon->get_amount() ) );
                    endif;

                    $data[] = array(
                        'id'            => $_data->ID,
						'coupon'        => strtoupper($coupon->get_code()),
						'discount'      => $discount,
                        'free_shipping' => $coupon->get_free_shipping(),
                        'max_amount'    => (0 < $coupon->get_maximum_amount() ) ? strip_tags( wc_price( $coupon->get_maximum_amount()) ) : NULL,
                        'min_amount'    => (0 < $coupon->get_minimum_amount() ) ? strip_tags( wc_price( $coupon->get_minimum_amount()) ) : NULL,
                        'usage_count'   => $coupon->get_usage_count(),
                        'usage_limit'   => (0 === $coupon->get_usage_limit() ) ? '&infin;' : $coupon->get_usage_limit(),
                        'expired_date'  => empty($coupon->get_date_expires()) ? NULL : date('Y M d', $coupon->get_date_expires()->getTimestamp()),
                        'affiliate'     => ( get_current_user_id() === absint($_data->post_author) ) && ( 0 < $_data->post_parent ) ? true : NULL
                    );

                endforeach;

                $total = count($data);

            endif;

        endif;

        echo wp_send_json([
            'table'           => $table,
            'draw'            => $table['draw'],
            'data'            => $data,
            'recordsTotal'    => $total,
            'recordsFiltered' => $total
        ]);

        exit;

	}

    /**
     * Validate parent coupon
     * @since   1.0.0
     * @param   integer $coupon_id
     * @return  array
     */
    protected function validate_parent_coupon( $coupon_id ) {

        $valid    = true;
        $messages = array();

        $this->parent_coupon = new \WC_Coupon( $coupon_id );

        if( !is_a($this->parent_coupon, 'WC_Coupon') ) :

            $valid      = false;
            $messages[] = __('Kupon utama tidak valid', 'sejowoo');

        else :

            if( 'yes' !== $this->parent_coupon->get_meta( 'enable_affiliate_use', true) ) :

                $valid      = false;
                $messages[] = __('Kupon utama tidak bisa digunakan untuk kupon affiliasi', 'sejowoo');

            endif;

        endif;

        return array(
            'valid'    => $valid,
            'messages' => $messages
        );
    }

    /**
     * Validate affiliate coupon
     * @since   1.0.0
     * @param   string  $affiliate_coupon
     * @param   integer $parent_coupon_id
     * @return [type]                   [description]
     */
    protected function validate_affiliate_coupon( $affiliate_coupon, $parent_coupon_id ) {

        $valid    = true;
        $messages = array();

        $coupon = wc_get_coupon_id_by_code( $affiliate_coupon );

        if( 0 < $coupon ) :

            $valid      = false;
            $messages[] = sprintf(__('Kupon %s sudah terdaftar', 'sejowoo'), $affiliate_coupon);

        else :

            $max_affiliate_coupon   = absint(carbon_get_theme_option('sejowoo_max_affiliate_coupon'));
            $total_affiliate_coupon = sejowoo_get_total_affiliate_coupon( get_current_user_id(), $parent_coupon_id );

            if( $max_affiliate_coupon <= $total_affiliate_coupon) :

                $valid      = false;
                $messages[] = sprintf(
                                __('Maksimal pembuatan kupon affiliasi per kupon utama adalah %d kupon. Anda sudah melebihi batas maksimum', 'sejowoo'),
                                $max_affiliate_coupon
                              );

            endif;

        endif;

        return array(
            'valid'    => $valid,
            'messages' => $messages
        );
    }

    /**
     * Create affiliate coupon
     * Hooked via action sejowoo-ajax/create-affiliate-coupon, priority 1
     * @since   1.0.0
     * @return  json
     */
    public function create_affiliate_coupon() {

        $response = array(
            'valid'   => true,
            'coupon'  => '',
            'message' => __('Maaf anda tidak bisa membuat kupon affiliasi', 'sejowoo')
        );

        $messages  = array();
        $post_data = wp_parse_args( $_POST, array(
                        'parent_coupon'    => NULL,
                        'affiliate_coupon' => NULL,
                        'nonce'            => NULL
                     ));

        if(
            is_user_logged_in() &&
            wp_verify_nonce( $post_data['nonce'], 'sejowoo-create-affiliate-coupon')
        ):

            $parent_coupon_id = absint( $post_data['parent_coupon'] );

            if( empty($parent_coupon_id) ) :

                $response['valid'] = false;
                $messages[]        = __('Anda belum memilih kupon utama', 'sejowoo');

            else :

                $parent_response = $this->validate_parent_coupon($parent_coupon_id);

                if( false === $parent_response['valid'] ) :
                    $response['valid'] = false;
                    $messages = array_merge($messages, $parent_response['messages']);
                endif;

            endif;

            $response['coupon'] = $affiliate_coupon = strtoupper( sanitize_title( $post_data['affiliate_coupon'] ) );

            if( empty($affiliate_coupon) ) :

                $response['valid'] = false;
                $messages[] = __('Anda belum mengisi kupon anda', 'sejowoo');

            else :

                if( 5 > strlen( $affiliate_coupon ) ) :

                    $response['valid'] = false;
                    $messages[] = __('Kupon anda terlalu pendek, minimal 5 karakter', 'sejowoo');

                else :

                    $affiliate_response = $this->validate_affiliate_coupon( $affiliate_coupon, $parent_coupon_id );

                    if( false === $affiliate_response['valid'] ) :
                        $response['valid'] = false;
                        $messages = array_merge($messages, $affiliate_response['messages']);
                    endif;

                endif;

            endif;

            if( true === $response['valid'] ) :
                $coupon = sejowoo_create_affiliate_coupon(
                                $affiliate_coupon,
                                get_current_user_id(),
                                $parent_coupon_id
                            );

                if(!is_wp_error($coupon) && is_a($coupon, 'WC_Coupon') ) :

                    $messages[] = sprintf(
                                        __('Kupon anda yaitu %s telah berhasil dibuat.', 'sejowoo'),
                                        $affiliate_coupon
                                  );
                else :
                    $response['valid']  = false;
                    $messages[]         = $coupon->get_error_message();
                endif;
            endif;

        else :

            $response['valid']  = false;

        endif;

        $response['message'] = ( 0 < count($messages)) ? implode( '<br />', $messages ) : $response['message'];

        echo wp_send_json( $response );
    }

    /**
     * Set parent coupon as select2 options
     * Hooked via action sejowoo-ajax/get-parent-coupon-list, priority 1
     * @since  1.0.0
     */
    public function set_for_parent_options() {

        $response = array();

        $get_data = wp_parse_args( $_GET, array(
                        'nonce' => ''
                    ));

        if( is_user_logged_in() && wp_verify_nonce( $get_data['nonce'], 'sejowoo-get-parent-coupon-list') ) :

            foreach( (array) sejowoo_get_affiliated_coupons() as $id => $coupon ) :

                $response[] = array(
                    'id'   => $id,
                    'text' => strtoupper($coupon)
                );

            endforeach;
        endif;

        echo wp_send_json($response);
    }

    /**
     * Set available coupon as select2 options
     * Hooked via action sejowoo-ajax/get-available-coupon-list, priority 1
     * @since  1.0.0
     */
    public function set_for_affiliate_options() {

        $response = array();

        $get_data = wp_parse_args( $_GET, array(
                        'nonce' => ''
                    ));

        if( is_user_logged_in() && wp_verify_nonce( $get_data['nonce'], 'sejowoo-get-affiliate-coupon-list') ) :

            $args = array(
                'affiliate_id' => get_current_user_id()
            );

            $return = sejowoo_get_available_coupon_list( $args, array(
                'start'  => 0,
                'length' => 999
            ));

            if( false !== $return['valid'] ) :

                foreach( $return['coupons'] as $_data ) :

                    $coupon = new \WC_Coupon( $_data->ID );

                    if( 'percent' === $coupon->get_discount_type() ) :

                        $discount = $coupon->get_amount() . '%';

                    else :

                        $discount = strip_tags( str_replace( "&nbsp;", ' ', wc_price( $coupon->get_amount() ) ) );

                    endif;

                    if( 0 < $_data->post_parent ):

                        $response[] = array(
                            'id'   => strtoupper($coupon->get_code()),
                            'text' => sprintf(
                                __('%s (Discount %s %s) %s', 'sejowoo'),
                                strtoupper( $coupon->get_code() ),
                                $discount,
                                ( $coupon->get_free_shipping() ) ? ' + ' . __('Gratis Ongkos Kirim', 'sejowoo') : '',
                                ( 0 < $_data->post_parent )      ? ' ' . __('(Kupon affiliasi)', 'sejowoo') : ''
                            )
                        );

                    endif;

                endforeach;

            endif;

        endif;

        echo wp_send_json( $response );

    }
}
