<?php
/**
 * My Account page
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/my-account.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 3.5.0
 */

defined( 'ABSPATH' ) || exit;

/**
 * My Account navigation.
 *
 * @since 2.6.0
 */
?>

<nav class="sidebar">

	<div class="logo d-flex justify-content-between">
		<a href="<?php echo home_url(); ?>">
			<?php
			if ( has_custom_logo() ) :
		
				$image = wp_get_attachment_image_src( get_theme_mod( 'custom_logo' ), 'full' );
				?>
				<img src="<?php echo $image[0]; ?>" alt="">
				<?php
			else:
				echo get_bloginfo( 'name' );
			endif;
			?>
		</a>
		<div class="sidebar_close_icon d-lg-none">
			<i class="ti-close"></i>
		</div>
	</div>
	
	<?php do_action( 'woocommerce_account_navigation' ); ?>


</nav>

<section class="main_content dashboard_part">

	<!-- menu  -->
	<div class="container-fluid no-gutters">
		<div class="row">
			<div class="col-lg-12 p-0">
				<div class="header_iner d-flex justify-content-between align-items-center">
					<div class="sidebar_icon d-lg-none">
						<i class="ti-menu"></i>
					</div>
					<div class="serach_field-area">
						<!-- <div class="search_inner">
							<form action="#">
								<div class="search_field">
									<input type="text" placeholder="Search here..." >
								</div>
								<button type="submit"> <img src="img/icon/icon_search.svg" alt=""> </button>
							</form>
						</div> -->
					</div>
					<div class="header_right d-flex justify-content-between align-items-center">
						<div class="header_notification_warp d-flex align-items-center">
							<li>
								<a href="#"> <img src="<?php echo SEJOWOO_URL . 'public/assets/img/icon/bell.svg'; ?>" alt=""> </a>
							</li>
							<li>
								<a href="#"> <img src="<?php echo SEJOWOO_URL . 'public/assets/img/icon/msg.svg'; ?>" alt=""> </a>
							</li>
						</div>
						<div class="profile_info">
							<img src="<?php echo get_avatar_url( get_current_user_id() ); ?>" alt="#">
							<div class="profile_info_iner">
								<p>Welcome back</p>
								<h5><?php echo esc_html( $current_user->display_name ); ?></h5>
								<div class="profile_info_details">
									<a href="<?php echo wc_customer_edit_account_url(); ?>">My Profile <i class="ti-user"></i></a>
									<!-- <a href="#">Settings <i class="ti-settings"></i></a> -->
									<a href="<?php echo wp_logout_url(); ?>">Log Out <i class="ti-shift-left"></i></a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--/ menu  -->
	
	<div class="main_content_iner ">
		<div class="container-fluid plr_30 body_white_bg pt_30" style="padding-bottom:10px !important">

			<div class="woocommerce-MyAccount-content">
				<?php
					/**
					 * My Account content.
					 *
					 * @since 2.6.0
					 */
					do_action( 'woocommerce_account_content' );
				?>
			</div>

		</div>
	</div>

	<!-- footer part -->
	<div class="footer_part">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="footer_iner text-center">
						<p><?php echo date('Y'); ?> &copy; <?php bloginfo('name'); ?></p>
					</div>
				</div>
			</div>
		</div>
	</div>

</section>
<!-- main content part end -->