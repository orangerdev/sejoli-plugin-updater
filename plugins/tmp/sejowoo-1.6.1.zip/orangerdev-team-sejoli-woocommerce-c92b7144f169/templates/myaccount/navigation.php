<?php
/**
 * My Account navigation
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/myaccount/navigation.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see     https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates
 * @version 2.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

do_action( 'woocommerce_before_account_navigation' );
?>


	<!-- <ul id="sidebar_menu">
		<?php foreach ( wc_get_account_menu_items() as $endpoint => $label ) : ?>
			<li class="<?php echo wc_get_account_menu_item_classes( $endpoint ); ?>">
				<a href="<?php echo esc_url( wc_get_account_endpoint_url( $endpoint ) ); ?>">
                    <img src="img/menu-icon/6.svg" alt="">
                    <span><?php echo esc_html( $label ); ?></span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul> -->

	<?php
	wp_nav_menu( array( 
		'theme_location' 	=> 'sejowoo-member-area-menu', 
		'menu_id' 			=> 'sidebar_menu',
		'container'			=> 'ul',
		// 'link_before'		=> '<img src="' . SEJOWOO_URL . 'public/assets/img/menu-icon/6.svg" alt=""><span>',
		'link_before'		=> '<span>',
		'link_after'		=> '</span>',
		'fallback_cb'     => 'Sejowoo_Nav_Walker::fallback',
		'walker'          => new Sejowoo_Nav_Walker()
	) ); 
	?>

<?php do_action( 'woocommerce_after_account_navigation' ); ?>
