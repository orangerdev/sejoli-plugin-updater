<?php
/**
 * Request fund information for administrator
 */

defined( 'ABSPATH' ) || exit;

/*
 * @hooked WC_Emails::email_header() Output the email header
 */
do_action( 'woocommerce_email_header', $email_heading, $email );

?><p><?php
    printf(
        esc_html__( '%s melakukan permintaan pencairan dana dengan detail sebagai berikut', 'sejowoo' ),
        $user->get_display_name()
    );
?></p><?php

/*
 * @hooked Sejowoo/Admin/RequestFund::set_detail_email_content
 */
do_action( 'sejowoo/email-content/request-fund', $request );

?><p><?php
    printf(
        __('Anda bisa melakukan tindakan pada permintaan ini melalui halaman berikut ini <a href="%s" target="_blank">WP-Admin &gt; Wallet &gt; Pencairan Dana</a>', 'sejowoo'),
        admin_url('admin.php?page=sejowoo-request-fund-management')
    );
?></p><?php

/*
 * @hooked WC_Emails::email_footer() Output the email footer
 */
do_action( 'woocommerce_email_footer', $email );
