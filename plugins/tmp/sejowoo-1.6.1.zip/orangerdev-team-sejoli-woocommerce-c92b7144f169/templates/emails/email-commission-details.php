<?php
/**
 * Commission details table shown in emails.
 */

defined( 'ABSPATH' ) || exit;

$text_align  = is_rtl() ? 'right' : 'left';
$margin_side = is_rtl() ? 'left' : 'right';
$total       = 0;
?>
<h2>
	<?php
	/* translators: %s: Order ID. */
	echo wp_kses_post(
        sprintf(
                __( 'Komisi dari order #%s', 'sejowoo' ) . ' (<time datetime="%s">%s</time>)',
                $order->get_order_number(),
                $order->get_date_created()->format( 'c' ),
                wc_format_datetime( $order->get_date_created() )
                )
     );
	?>
</h2>

<div style="margin-bottom: 40px;">
	<table class="td" cellspacing="0" cellpadding="6" style="width: 100%; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;" border="1">
		<thead>
			<tr>
				<th class="td" scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Product', 'sejowoo' ); ?></th>
				<th class="td" scope="col" style="width:32px;text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Qty', 'sejowoo' ); ?></th>
                <th class="td" scope="col" style="width:32px;text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Tier', 'sejowoo' ); ?></th>
				<th class="td" scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Commission', 'sejowoo' ); ?></th>
			</tr>
		</thead>
		<tbody>
        <?php
            foreach( $commissions as $commission ) :
                $item = $commission['item'];
                $total += $commission['value'];
        ?>
            <tr class="<?php echo esc_attr( apply_filters( 'woocommerce_order_item_class', 'order_item', $item, $order ) ); ?>">
        		<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>; vertical-align: middle; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif; word-wrap:break-word;">
        		<?php

        		// Product name.
        		echo wp_kses_post( apply_filters( 'woocommerce_order_item_name', $item->get_name(), $item, false ) );

        		// allow other plugins to add additional product information here.
        		do_action( 'woocommerce_order_item_meta_start', $item->get_id(), $item, $order, $plain_text );

        		wc_display_item_meta(
        			$item,
        			array(
        				'label_before' => '<strong class="wc-item-meta-label" style="float: ' . esc_attr( $text_align ) . '; margin-' . esc_attr( $margin_side ) . ': .25em; clear: both">',
        			)
        		);

        		// allow other plugins to add additional product information here.
        		do_action( 'woocommerce_order_item_meta_end', $item->get_id(), $item, $order, $plain_text );

        		?>
        		</td>
        		<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>; vertical-align:middle; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
        			<?php
        			$qty          = $item->get_quantity();
        			$refunded_qty = $order->get_qty_refunded_for_item( $item->get_id() );

        			if ( $refunded_qty ) {
        				$qty_display = '<del>' . esc_html( $qty ) . '</del> <ins>' . esc_html( $qty - ( $refunded_qty * -1 ) ) . '</ins>';
        			} else {
        				$qty_display = esc_html( $qty );
        			}
        			echo wp_kses_post( apply_filters( 'woocommerce_email_order_item_quantity', $qty_display, $item ) );
        			?>
        		</td>
                <td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>; vertical-align:middle; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
                    <?php echo wp_kses_post( $commission['tier'] ); ?>
                </td>
        		<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>; vertical-align:middle; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;">
        			<?php echo wp_kses_post( wc_price( $commission['value'] ) ); ?>
        		</td>
        	</tr>
        <?php endforeach; ?>
		</tbody>
		<tfoot>
            <tr>
				<th class="td" scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Product', 'sejowoo' ); ?></th>
                <th class="td" scope="col" style="width:32px;text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Tier', 'sejowoo' ); ?></th>
				<th class="td" scope="col" style="width:32px;text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Qty', 'sejowoo' ); ?></th>
				<th class="td" scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Commission', 'sejowoo' ); ?></th>
			</tr>
		</tfoot>
	</table>
</div>

<p><?php printf( esc_html__( 'Total komisi yang anda dapatkan adalah %s', 'sejowoo' ), wc_price( $total ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></p>
<?php
