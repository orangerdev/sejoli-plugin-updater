<?php
/**
 * User request fund email
 */

defined( 'ABSPATH' ) || exit;

/*
 * @hooked WC_Emails::email_header() Output the email header
 */
do_action( 'woocommerce_email_header', $email_heading, $email );

?><p><?php
    echo esc_html__( 'Permintaan pencairan dana telah diproses. Detail proses sebagai berikut :', 'sejowoo'
); ?></p><?php

/*
 * @hooked Sejowoo/Admin/RequestFund::set_detail_email_content_for_information_process
 */
do_action( 'sejowoo/email-content/info-request-fund', $request );

/*
 * @hooked WC_Emails::email_footer() Output the email footer
 */
do_action( 'woocommerce_email_footer', $email );
