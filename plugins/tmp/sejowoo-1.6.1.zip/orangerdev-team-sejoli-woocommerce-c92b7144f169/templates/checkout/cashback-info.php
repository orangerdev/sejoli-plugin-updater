<div class="form-row sejowoo-display-cashback-info">
    <?php if( 0 < $cashback ) : ?>
    <h3><?php _e('Potensi cashback', 'sejowoo'); ?></h3>

    <table class="shop_table">
        <tbody>
			<tr class="cart_item">
                <td class="product-name" style='width:200px;'><?php _e('Cashback', 'sejowoo'); ?></td>
                <td class="product-total">
                    <?php echo wc_price( $cashback ); ?>
                </td>
            </tr>
		</tbody>
    </table>
    <?php endif; ?>
</div>
