<?php
    $available_total = (isset($wallet_data['available_total'])) ? $wallet_data['available_total'] : 0;
    if(
        0 < floatval($available_total) &&
        carbon_get_theme_option('sejowoo_wallet_activate_on_checkout')
    ) : ?>
<div class="form-row sejowoo-display-wallet-field-use">

    <h3><?php _e('Dana di wallet anda', 'sejowoo'); ?></h3>

    <table class="shop_table">
        <tbody>
			<tr class="cart_item">
                <td class="product-name" style='width:200px;'><?php _e('Dana yang tersedia', 'sejowoo'); ?></td>
                <td class="product-total"><?php echo wc_price( $wallet_data['available_total'] ); ?></td>
            </tr>
            <tr class="cart_item">
                <td colspan='2'>
                    <label class="woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
                        <input id="sejowoo-use-wallet-point" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" type="checkbox" name="sejowoo-use-wallet-point" value="1" />
                        <span><?php _e('Gunakan semua dana yang ada?', 'sejowoo'); ?></span>
                    </label>
                </td>
            </tr>
		</tbody>
    </table>

</div>
<?php endif; ?>
