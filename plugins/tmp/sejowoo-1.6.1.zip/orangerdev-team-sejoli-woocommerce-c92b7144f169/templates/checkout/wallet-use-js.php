<script type="text/javascript">
(function($){
    'use strict';

    $(document).on('change', '#sejowoo-use-wallet-point', function(){
        $(document.body).trigger('update_checkout');
    });
})(jQuery);
</script>
