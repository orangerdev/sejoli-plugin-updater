<div class="sejowoo-affiliate-info">
    <p><?php
    printf(
        __('Affiliasi oleh %s', 'sejowoo'),
        $affiliate->get_display_name()
    );
    ?></p>
</div>
