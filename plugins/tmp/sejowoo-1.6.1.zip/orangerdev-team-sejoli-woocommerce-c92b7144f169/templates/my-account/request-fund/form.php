<?php

!defined('ABSPATH') ? exit : true;

/**
* @since    1.0.0
* @since    1.1.2.2     Add refresh page after completed the form
**/

$user_wallet       = sejowoo_get_single_user_wallet();
$user              = new \WC_Customer( get_current_user_id() );
$request_fund_info = wp_parse_args( $user->get_meta( 'request_fund_info', true ), array(
                        'updated_at'         => NULL,
                        'bank_name'          => NULL,
                        'bank_account'       => NULL,
                        'bank_account_owner' => NULL,
                        'id_card'            => NULL
                    ));

$min_request_fund = floatval( carbon_get_theme_option( 'sejowoo_wallet_minimum_reqeust_fund' ) );

if( $min_request_fund >= $user_wallet['available_cash']) :
?><div class="woocommerce-message woocommerce-error"><?php
    printf(
        __('Jumlah dana yang bisa dicairkan di dompet anda tidak mencukupi. <br />Minimal dana yang bisa dicairkan adalah %s.', 'sejowoo'),
        wc_price($min_request_fund)
    );
?></div><?php
else :

$request_fund_message = carbon_get_theme_option('sejowoo_wallet_request_fund_message');

if( !empty($request_fund_message) ) :
    ?><div class="woocommerce-message woocommerce-info"><?php
    echo wpautop( $request_fund_message );
    ?></div><?php
endif;
?>

<form id='sejowoo-request-fund-form' class="sejowoo-form request-fund" action="index.html" method="POST">
<?php
    woocommerce_form_field( 'bank_name', array(
        'type'        => 'text',
        'label'       => __('Bank tujuan transfer', 'sejowoo'),
        'description' => __('Diisi dengan nama bank tujuan transfer', 'sejowoo'),
        'required'    => true,
    ), $request_fund_info['bank_name'] );

    woocommerce_form_field( 'bank_account', array(
        'type'        => 'text',
        'label'       => __('Nomor rekening', 'sejowoo'),
        'required'    => true,
    ),  $request_fund_info['bank_account'] );

    woocommerce_form_field( 'bank_account_owner', array(
        'type'        => 'text',
        'label'       => __('Nama lengkap pemilik rekening', 'sejowoo'),
        'required'    => true,
    ),  $request_fund_info['bank_account_owner'] );

?>
    <p class="form-row validate-required" id="id_card" data-priority="">
        <label for="id_card" class="">
            <?php _e('KTP / SIM', 'sejowoo'); ?>
            <abbr class="required" title="required">*</abbr>
        </label>
        <span class="woocommerce-input-wrapper">
            <input type="file" name="id_card" id="id_card" placeholder="" value="" aria-describedby="amount-description /">
            <span class="description" id="amount-description" style="display: inline-block;">
                <?php _e('Apabila nama pemilik rekening tidak sesuai dengan KTP/SIM, kami berhak untuk menolak pencairan dana', 'sejowoo'); ?>
            </span>
        </span>
    </p>

    <p class="form-row " id="amount_field" data-priority="">
        <label for="amount" class="">
            <?php _e('Jumlah yang dicairkan', 'sejowoo'); ?>
        </label>
        <span class="woocommerce-input-wrapper">
            <input type="text" class="input-text " name="amount" id="amount" placeholder="" value="<?php echo strip_tags( wc_price( $user_wallet['available_cash'] ) ); ?>" aria-describedby="amount-description" readonly>
            <span class="description" id="amount-description" style="display: inline-block;">
                <?php _e('Nilai yang dicairkan sudah ditentukan sendiri oleh sistem', 'sejowoo'); ?>
            </span>
        </span>
    </p>
    <p>
        <?php wp_nonce_field( 'sejowoo-send-request-fund' , 'nonce' ); ?>
        <button type="submit" class="woocommerce-Button button" name="send_request_fund" value="Save changes"><?php _e('Kirim permintaan pencairan Dana', 'sejowoo'); ?></button>
    </p>
    <div id='sejowoo-form-message' class="woocommerce-message" style='display:none'></div>
</form>

<script type="text/javascript">
(function($){

    'use script';

    let form = document.getElementById('sejowoo-request-fund-form'),
        message = document.getElementById('sejowoo-form-message');

    form.addEventListener( 'submit', function(e){
        e.preventDefault();

        let data = new FormData(form),
            xhr = new XMLHttpRequest();

            xhr.addEventListener( 'loadstart', function(){
                sejowoo.block( form );
                message.style.display = 'none';
            });

            xhr.addEventListener( 'load', function( response ){
                sejowoo.unblock( form );
                message.style.display = 'block';
            });

            xhr.onreadystatechange = function() {

                message.classList.remove('woocommerce-error');
                message.classList.remove('woocommerce-info');

                if (this.readyState == 4 && this.status == 200) {
                    let response = JSON.parse( this.responseText );

                    if(false === response.valid ) {
                        message.classList.add('woocommerce-error');
                    } else {

                        message.classList.add('woocommerce-info');

                        setTimeout(function(){
                            location.reload();
                        }, 1000);
                    }

                    message.innerHTML = response.message;
                }
            }

            xhr.open("POST", sejowoo_myaccount.request_fund.submit.ajaxurl );

            xhr.send(data);

    });
})(jQuery);
</script>
<?php
endif;
