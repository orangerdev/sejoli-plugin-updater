<?php
    defined( 'ABSPATH' ) || exit;
    $user_wallet = sejowoo_get_single_user_wallet();
?>
<div class="sejowoo-wallet-info sejowoo-grid three-cols">
    <div class="col blue">
        <h3><?php _e('Dana yang tersedia', 'sejowoo'); ?></h3>
        <?php echo wc_price( $user_wallet['available_total'] ); ?>
    </div>
    <div class="col green">
        <h3><?php _e('Dana yang bisa dicairkan', 'sejowoo'); ?></h3>
        <?php echo wc_price( $user_wallet['available_cash'] ); ?>
    </div>
    <div class="col yellow">
        <h3><?php _e('Dana yang telah digunakan', 'sejowoo'); ?></h3>
        <?php echo wc_price( $user_wallet['used_value'] ); ?>
    </div>
</div>

<div class="sejowoo-table-holder">
    <table id='sejowoo-wallet' class="sejowoo-wallet-table woocommerce-MyAccount-wallet shop_table shop_table_responsive my_account_wallet account-wallet-table">
        <thead>
            <tr>
                <th><?php _e('Tgl', 'sejowoo'); ?></th>
                <th><?php _e('Note', 'sejowoo'); ?></th>
                <th><?php _e('Nilai', 'sejowoo'); ?></th>
                <th><?php _e('Tipe', 'sejowoo'); ?></th>
                <th><?php _e('Status', 'sejowoo'); ?></th>
            </tr>
        </thead>
        <tbody>

        </tbody>
        <tfoot>
            <tr>
                <th style='max-width:100px;'><?php _e('Tgl', 'sejowoo'); ?></th>
                <th><?php _e('Note', 'sejowoo'); ?></th>
                <th style='max-width:100px;'><?php _e('Nilai', 'sejowoo'); ?></th>
                <th style='max-width:100px;'><?php _e('Tipe', 'sejowoo'); ?></th>
                <th style='max-width:100px;'><?php _e('Status', 'sejowoo'); ?></th>
            </tr>
        </tfoot>
    </table>
</div>

<script type="text/javascript">

let sejowoo_table;

(function( $ ) {
	'use strict';
    $(document).ready(function() {

        sejowoo_table = $('#sejowoo-wallet').DataTable({
            language: dataTableTranslation,
            searching: false,
            processing: false,
            serverSide: true,
            ajax: {
                type: 'POST',
                url: sejowoo_myaccount.wallet.single_table.ajaxurl,
                data: function(data) {
                    data.nonce = sejowoo_myaccount.wallet.single_table.nonce;
                }
            },
            pageLength : 50,
            lengthMenu : [
                [50, 100, 200],
                [50, 100, 200],
            ],
            order: [
                [ 0, "desc" ]
            ],
            columnDefs: [
                {
                    targets: [1, 2, 3],
                    orderable: false
                },{
                    targets: 0,
                    width: '80px',
                    data : 'created_at',
                    className: 'center'
                },{
                    targets: 1,
                    data: 'detail',
                },{
                    targets: 2,
                    width: '80px',
                    data : 'point',
                    className: 'center'
                },{
                    targets: 3,
                    width: '80px',
                    data : 'refundable',
                    className: 'center',
                    render: function(data, meta, full) {
                        if('out' === full.type) {
                            return '-';
                        } else if( true === data ) {
                            return '<label class="ui blue label"><?php _e('Cash', 'sejowoo'); ?></label>';
                        } else {
                            return '<label class="ui purple label"><?php _e('Poin', 'sejowoo'); ?></label>';
                        }
                    }
                },{
                    targets: 4,
                    width:  '80px',
                    data: 'type',
                    className: 'center',
                    render: function(data) {
                        if('in' === data) {
                            return '<label class="ui green label"><?php _e('Tambah', 'sejowoo'); ?></label>';
                        } else {
                            return '<label class="ui yellow label"><?php _e('Kurang', 'sejowoo'); ?></label>';
                        }
                    }
                }
            ]
        });

        sejowoo_table.on('preXhr',function(){
            sejowoo.block('.sejowoo-table-holder');
        });

        sejowoo_table.on('xhr',function(){
            sejowoo.unblock('.sejowoo-table-holder');
        });

    });
})(jQuery);
</script>
