<!-- <button class="ui primary button show-filter-form"><i class="filter icon"></i> <?php _e( 'Filter Data', 'sejowoo' ); ?></button>
<button class="ui button export-csv"><i class="file alternate icon"></i> <?php _e( 'Export to CSV', 'sejowoo' ); ?></button> -->
<div class="sejowoo-table-holder">
    <table id='sejowoo-order' class="sejowoo-order-table woocommerce-MyAccount-wallet shop_table shop_table_responsive my_account_wallet account-order-table">
        <thead>
            <tr>
                <th><?php _e('Detil',       'sejowoo'); ?></th>
                <th><?php _e('Nama Produk', 'sejowoo'); ?></th>
                <th><?php _e('Total',       'sejowoo'); ?></th>
                <th><?php _e('Komisi',      'sejowoo'); ?></th>
                <th><?php _e('Status',      'sejowoo'); ?></th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan="4">Tidak ada data yang bisa ditampilkan</td>
            </tr>
        </tbody>
        <tfoot>
            <tr>
                <th><?php _e('Detil',       'sejowoo'); ?></th>
                <th><?php _e('Nama Produk', 'sejowoo'); ?></th>
                <th><?php _e('Total',       'sejowoo'); ?></th>
                <th><?php _e('Komisi',      'sejowoo'); ?></th>
                <th><?php _e('Status',      'sejowoo'); ?></th>
            </tr>
        </tfoot>
    </table>
</div>

<script type="text/javascript">

let sejowoo_table;

(function( $ ) {
	'use strict';
    $(document).ready(function() {

        sejowoo_table = $('#sejowoo-order').DataTable({
            language: dataTableTranslation,
            searching: false,
            processing: false,
            serverSide: true,
            ajax: {
                type: 'POST',
                url: sejowoo_myaccount.order.table.ajaxurl,
                data: function(data) {
                    data.nonce = sejowoo_myaccount.order.table.nonce;
                }
            },
            pageLength : 50,
            lengthMenu : [
                [50, 100, 200],
                [50, 100, 200],
            ],
            order: [
                [ 0, "desc" ]
            ],
            columnDefs: [
                {
                    targets: [1, 2, 3, 4],
                    orderable: false
                },{
                    targets: 0,
                    data: 'date',
                    render: function(data, meta, full) {
                        let tmpl = $.templates('#sejowoo-order-detail');
                        return tmpl.render({
                                date:  data,
                                buyer_name:  full.buyer_name,
                                buyer_phone: full.buyer_phone,
                                buyer_email: full.buyer_email,
                            });
                    }
                },{
                    targets: 1,
                    className: 'right',
                    width: '90px',
                    data: 'product_name',
                },{
                    targets: 2,
                    className: 'right',
                    width: '90px',
                    data: 'total',
                },{
                    targets: 3,
                    className: 'right',
                    width: '90px',
                    data: 'commission',
                },{
                    targets: 4,
                    width: '80px',
                    className: 'center full-label',
                    data: 'status',
                    render: function(data, type, full) {
                        let tmpl = $.templates('#sejowoo-label-status');
                        return tmpl.render({
                                label:  data,
                                color:  full.color_status
                            });
                    }
                }
            ]
        });

        sejowoo_table.on('preXhr',function(){
            sejowoo.block('.sejowoo-table-holder');
        });

        sejowoo_table.on('xhr',function(){
            sejowoo.unblock('.sejowoo-table-holder');
        });

    });
})(jQuery);
</script>
<!-- ORDET DETAIL - JSRENDER -->
<script id='sejowoo-order-detail' type="text/x-jsrender">
<span class='sejowoo-order-detail'>
    <span class='label name'>{{:buyer_name}}</span>
    <span class='label date'>{{:date}}</span>
    {{if buyer_phone}}
    <span class='label phone'>{{:buyer_phone}}</span>
    {{/if}}
    {{if buyer_email}}
    <span class='label email'>{{:buyer_email}}</span>
    {{/if}}
</span>
</script>
<?php
wc_get_template(
    'others/label.php',
    array(),
    SEJOWOO_DIR . 'templates/',
    SEJOWOO_DIR . 'templates/'
);
