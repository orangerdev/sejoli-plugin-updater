<div id="filter-form-wrap" class="ui small modal">
    <i class="close icon"></i>
    <div class="header">
        <?php _e( 'Filter Data', 'sejowoo' ); ?>
    </div>
    <div class="content">
        <form id="filter-form" class="ui form">
            <div class="field">
                <label><?php _e( 'Tanggal', 'sejowoo' ); ?></label>
                <input type="text" name="date-range" id="date-range"/>
            </div>
            <div class="field">
                <label><?php _e( 'Produk', 'sejowoo' ); ?></label>
                <select name="product_id" id="product_id">
                    <option value=""><?php _e( '--Pilih Produk--', 'sejowoo' ); ?></option>
                </select>
            </div>
            <div class="field">
                <label><?php _e( 'Status Order', 'sejowoo' ); ?></label>
                <select name="status" id="status" class="select2-filled">
                    <option value=""><?php _e( '--Pilih Status Order--', 'sejowoo' ); ?></option>
                    <?php
                    $order_status = apply_filters('sejowoo/order/status', []);
                    foreach($order_status as $key => $label) :
                    ?>
                        <option value="<?php echo $key; ?>"><?php echo $label; ?></option>
                    <?php
                    endforeach;
                    ?>
                </select>
            </div>
            <div class="field">
                <label><?php _e( 'Tipe Order', 'sejowoo' ); ?></label>
                <select name="type" id="type" class="select2-filled">
                    <option value=""><?php _e( '--Pilih Tipe Order--', 'sejowoo' ); ?></option>
                    <option value="regular"><?php _e('Pembelian sekali waktu', 'sejowoo'); ?></option>
                    <option value="subscription-tryout"><?php _e("Berlangganan - Tryout", 'sejowoo'); ?></option>
                    <option value="subscription-signup"><?php _e("Berlangganan - Awal", 'sejowoo'); ?></option>
                    <option value="subscription-regular"><?php _e("Berlangganan - Regular", 'sejowoo'); ?></option>
                </select>
            </div>
        </form>
    </div>
    <div class="actions">
        <button class="ui primary button filter-form"><?php _e( 'Filter', 'sejowoo' ); ?></button>
    </div>
</div>
