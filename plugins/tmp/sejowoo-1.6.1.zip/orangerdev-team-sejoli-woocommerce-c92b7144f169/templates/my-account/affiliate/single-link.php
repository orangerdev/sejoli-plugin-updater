<div class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide affiliate-links">
    <label class='affiliate-link-title' for="aff-<?php echo $id; ?>"><?php echo $title; ?></label>
    <div class='affiliate-link-description'><?php echo $description; ?></div>
    <span class="InputAddOn">
        <input type="text" class="woocommerce-Input woocommerce-Input--text input-text InputAddOn-field" id="aff-<?php echo $id; ?>" value="<?php echo $link ?>">
        <input type="hidden" class='affiliate-default-link' value='<?php echo $link; ?>'>
        <button type="button" class="InputAddOn-item copy-btn" data-clipboard-target="#aff-<?php echo $id; ?>">
            <i class="copy icon"></i> <?php _e( 'Copy', 'sejowoo' ); ?>
        </button>
    </span>
</div>
