<div id='sejowoo-form-message' class="woocommerce-message" style='display:none'></div>

<div id='sejowoo-affiliate-network' class="sejowoo-affiliate-network">
    <div id="js-tree-list">

    </div>
</div>
<div id="question" style="display:none; cursor: default">

</div>

<script>
(function($) {
    'use strict';

    $(document).ready(function(){

        let blockMessage = $('#sejowoo-form-message');

        $('#js-tree-list').jstree({
            core:   {
                data:   {
                    url    : sejowoo_myaccount.network.list.ajaxurl
                }
            },
            plugins : [ "themes", "json_data", "ui" ]
        });

        $(document).on('click', '.jstree-anchor', function(){

            let dataID = parseInt($(this).data('id'));

            $.ajax({
                url:        sejowoo_myaccount.network.detail.ajaxurl,
                type:       'GET',
                data:   {
                    'id': dataID
                },
                dataType:   'json',
                beforeSend: function() {
                    sejowoo.block('#sejowoo-affiliate-network');
                    blockMessage.removeClass('woocommerce-error').hide().html('');
                },
                success:    function(response) {

                    sejowoo.unblock('#sejowoo-affiliate-network');

                    if(response.valid) {
                        let tmpl = $.templates('#affiliate-network-modal-content');

                        $('#question').html(tmpl.render(response.user));

                        $.blockUI({
                            message: $('#question'),
                            css: {
                                width: '480px'
                            },
                            onBlock: function() {
                               $(".blockPage").addClass("sejowoo-popup");
                            }
                        });

                        $('.blockOverlay')
                            .attr('title', '<?php _e('Klik untuk tutup', 'sejowoo'); ?>')
                            .click($.unblockUI);

                    } else {
                        blockMessage.addClass('woocommerce-error').html(response.message).fadeIn();
                    }
                }
            })

            return false;
        });

    });

})(jQuery);
</script>

<!-- AFFILIATE NETWORK MODALCONTENT -->
<script id='affiliate-network-modal-content' type="text/x-jsrender">
<section class="woocommerce-order-details">
    <h2 class="woocommerce-order-details__title"><?php _e('Detail Affiliasi', 'sejowoo'); ?></h2>
    <table class="woocommerce-table woocommerce-table--order-details shop_table order_details">
        <tbody>
            <tr>
                <th scope="row"><?php _e('Nama ', 'sejowoo'); ?>:</th>
                <td>{{:name}}</td>
            </tr>
            {{if email}}
            <tr>
                <th scope="row"><?php _e('Email ', 'sejowoo'); ?>:</th>
                <td>{{:email}}</td>
            </tr>
            {{/if}}
            {{if phone}}
            <tr>
                <th scope="row"><?php _e('Telpon ', 'sejowoo'); ?>:</th>
                <td>{{:phone}}</td>
            </tr>
            {{/if}}
            {{if address}}
            <tr>
                <th scope="row"><?php _e('Alamat ', 'sejowoo'); ?>:</th>
                <td>{{:address}}</td>
            </tr>
            {{/if}}
            <tr>
                <th scope="row"><?php _e('Komisi ', 'sejowoo'); ?>:</th>
                <td>{{:commission}}</td>
            </tr>
        </tbody>
    </table>
</section>
</script>
