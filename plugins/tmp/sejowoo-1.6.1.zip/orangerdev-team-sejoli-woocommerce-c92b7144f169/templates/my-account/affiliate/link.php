<?php
defined('ABSPATH') || exit;

$hide_affiliate_coupon = boolval( carbon_get_theme_option('sejowoo_member_area_hide_affiliate_coupon') );

?>
<form id="affiliate-link-holder" class='sejowoo-affiliate-links sejowoo-form'>
<?php
    wc_get_template(
        'my-account/affiliate/single-link.php',
        array(
            'id'          => 'home',
            'title'       => __('Homepage', 'sejowoo'),
            'description' => '<p>' . __('Pengunjung akan dialihkan ke halaman depan website ini', 'sejowoo') . '</p>',
            'link'        => sejowoo_generate_affiliate_link()
        ),
        SEJOWOO_DIR . 'templates/',
        SEJOWOO_DIR . 'templates/'
    );

    $links = sejowoo_get_all_affiliate_links();

    foreach( (array) $links as $link ) :

            wc_get_template(
                'my-account/affiliate/single-link.php',
                array(
                    'id'          => $link->ID,
                    'title'       => $link->post_title,
                    'description' => wpautop( $link->post_content ),
                    'link'        => sejowoo_generate_affiliate_link( $link->post_name )
                ),
                SEJOWOO_DIR . 'templates/',
                SEJOWOO_DIR . 'templates/'
            );

    endforeach; ?>

</form>

<?php if( true !== $hide_affiliate_coupon ) : ?>

<form id='sejowoo-affiliate-coupon-form' class="sejowoo-affiliate-coupon-form sejowoo-form generate-form" style='margin-bottom:4rem'>

    <h4><?php _e('Tambah parameter ke link affiliasi anda', 'sejowoo'); ?></h4>

    <?php
        echo woocommerce_form_field(
            'coupon',
            array(
                'type'     => 'select',
                'label'    => __('Tambahkan Kupon', 'sejowoo'),
                'required' => true,
                'options'  => array( ''  => __('Tanpa Kupon', 'sejowoo') ),
                'class'    => array('inline-field')
            )
        );
    ?>

</form>
<script type="text/javascript">
(function($){

    'use strict';

    let sejowoo_coupon_select2;

    let updateCouponOptions = function() {

        $.ajax({
            url:      sejowoo_myaccount.affiliate.coupon_list.ajaxurl,
            type:     'GET',
            dataType: 'json',
            success:  function(response) {

                response.forEach(function(i, el){
                    let option = new Option( response[el].text, response[el].id, true, true);

                    // sejowoo_coupon_select2.append(option).trigger('change');
                    sejowoo_coupon_select2.append(option);
                    sejowoo_coupon_select2.find('option:eq(0)').prop('selected', true);
                });

            }
        });
    }

    let getParameterValues = function() {

        let data = $("#sejowoo-affiliate-coupon-form :input[value!='']")
                        .serialize()
                        .replace(/&?[^=&]+=(&|$)/g,'');

        if( 0 < data.length ) {
            $(document).find('.affiliate-default-link').each(function(i, e){
                let url   = $(e).val(),
                    input = $(e).parent().find('.woocommerce-Input');

                    input.val(url + '?' + data);
            });
        }

        if(data.length === 0) {
            $(document).find('.affiliate-default-link').each(function(i, e){
                let url   = $(e).val(),
                    input = $(e).parent().find('.woocommerce-Input');

                    input.val(url);
            });
        }
    }

    $(document).ready(function(){

        sejowoo_coupon_select2 = $('#coupon')
            .css({
                width: '400px'
            })
            .select2({
                width:             'resolve',
                placeholder:       '<?php _e('Pilih Kupon', 'sejowoo'); ?>',
                allowClear:        true,
                dropdownAutoWidth: true
            })
            .on('change', function (e) {
                getParameterValues();
            })
            .on("select2:unselecting", function (e) {
                sejowoo_coupon_select2.val(null).trigger("change"); 
                getParameterValues();
            });

        updateCouponOptions();

    });

})(jQuery);
</script>
<?php endif; ?>
