<?php defined('ABSPATH') || exit; ?>

<div class="sejowoo-filter-holder">
    <button class='sejowoo-display-form-filter' type='button'><?php _e('Atur Data', 'sejowoo'); ?></button>
    <form id="leaderboard-filter" class="ui form sejowoo-form-filter-holder">
        <div class="field">
            <select id="product_id" name="product_id" class="filter-data" multiple="multiple" size="1">
                <option value=""><?php _e( '--Pilih Produk--', 'sejowoo' ); ?></option>
            </select>
        </div>
        <div class="field">
            <input type="text" id="date-range" name="date_range" class="filter-data date-range">
        </div>
        <div class="field">
            <select id='calculate_type' class="filter-data" name="calculate_type">
                <option value="commission"><?php _e('Dihitung berdasarkan jumlah komisi', 'sejowoo'); ?></option>
                <option value="quantity"><?php _e('Dihitung berdasarkan jumlah pembelian', 'sejowoo'); ?></option>
                <option value="omset"><?php _e('Dihitung berdasarkan jumlah omset', 'sejowoo'); ?></option>
            </select>
        </div>
        <div class="field">
            <button id="leaderboard-filter-button" class="ui primary button" type='button'>
                <?php _e( 'Atur Data', 'sejowoo' ); ?>
            </button>
        </div>
    </form>
</div>

<div class="sejowoo-table-holder">
    <table id='sejowoo-leaderboard' class="sejowoo-leaderboard-table woocommerce-MyAccount-leaderboard shop_table shop_table_responsive my_account_leaderboard account-leaderboard-table">
        <thead>
            <tr>
                <th></th>
                <th><?php _e('Affiliasi', 'sejowoo'); ?></th>
                <th></th>
            </tr>
        </thead>
        <tbody></tbody>
        <tfoot>
            <tr>
                <th></th>
                <th><?php _e('Affiliasi', 'sejowoo'); ?></th>
                <th></th>
            </tr>
        </tfoot>
    </table>
</div>

<script type="text/javascript">

let sejowoo_table;

(function( $ ) {
	'use strict';
    $(document).ready(function() {

        sejowoo.daterangepicker(
            '#date-range',
            moment().startOf('month'),
            moment().endOf('month')
        );

        sejowoo_table = $('#sejowoo-leaderboard').DataTable({
            language:   dataTableTranslation,
            searching:  false,
            processing: true,
            serverSide: false,
            info:       false,
            paging:     false,
            ajax:       {
                type: 'POST',
                url:  sejowoo_myaccount.leaderboard.table.ajaxurl,
                data: function(data) {
                    data.nonce       = sejowoo_myaccount.leaderboard.table.nonce;
                    data.products    = $('#product_id').val();
                    data.date_range  = $('#date-range').val();
                    data.calculation = $('#calculate_type').val();
                }
            },
            pageLength : -1,
            columnDefs: [
                {
                    targets: [1, 2],
                    orderable: false
                },{
                    targets: 0,
                    data:    'number',
                    width:   '32px',
                    class:   'center'
                },{
                    targets: 1,
                    render:  function(data, type, full) {
                        let tmpl = $.templates('#user-detail');
                        return tmpl.render( full );
                    }
                },{
                    targets: 2,
                    width: '200px',
                    data : 'value',
                    className: 'price'
                }
            ],
            initComplete:   function() {
                let api = this.api();

                if( false === sejowoo_myaccount.leaderboard.table.display_point ) {
                    api.column(2).visible( false );
                }
            }
        });

        sejowoo_table.on('preXhr',function(){
            sejowoo.block('.sejowoo-table-holder');
        });

        sejowoo_table.on('xhr',function(){
            sejowoo.unblock('.sejowoo-table-holder');
            let calculate = $('#calculate_type').val();

            if( 'commission' == calculate ) {
                $(sejowoo_table.columns(2).header()).html( sejowoo_myaccount.leaderboard.table.header.commission );
            } else if( 'quantity' == calculate ) {
                $(sejowoo_table.columns(2).header()).html( sejowoo_myaccount.leaderboard.table.header.quantity );
            } else if( 'omset' == calculate ) {
                $(sejowoo_table.columns(2).header()).html( sejowoo_myaccount.leaderboard.table.header.omset );
            }
        });

        $.ajax({
            url : sejowoo_myaccount.product.options.ajaxurl,
            data : {
                nonce : sejowoo_myaccount.product.options.nonce
            },
            type : 'GET',
            dataType : 'json',
            beforeSend : function() {
            },
            success : function(response) {
                // console.log(response);
                $('#product_id').select2({
                    allowClear: true,
                    placeholder: sejowoo_myaccount.product.options.placeholder,
                    width:'100%',
                    data : response.results,
                    templateResult : function(data) {
                        return $("<textarea/>").html(data.text).text();
                    },
                    templateSelection : function(data) {
                        return $("<textarea/>").html(data.text).text();
                    }
                });
            }
        });

        $('body').on('click', '#leaderboard-filter-button', function(){
            $('#leaderboard-filter').hide();
            sejowoo_table.ajax.reload();
            return false;
        });

        $('#calculate_type').select2();

        $('.sejowoo-display-form-filter').click(function(){
            $('#leaderboard-filter').toggle();
        });

    });
})(jQuery);
</script>
<script id='user-detail' type="text/x-jsrender">
<div class='user-with-avatar'>
    <img src='{{:avatar}}' />
    <span>{{:affiliate}}</span>
</div>
</script>
