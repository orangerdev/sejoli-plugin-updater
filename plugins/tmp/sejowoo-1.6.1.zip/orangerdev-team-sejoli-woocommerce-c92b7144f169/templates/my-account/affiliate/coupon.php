<div id='sejowoo-form-message' class="woocommerce-message" style='display:none'></div>

<form id='sejowoo-affiliate-coupon-form' class="sejowoo-affiliate-coupon-form sejowoo-form" style='margin-bottom:4rem'>
    <h3><?php _e('Buat kupon affiliasi anda', 'sejowoo'); ?></h3>
<?php
    echo woocommerce_form_field(
        'parent_coupon',
        array(
            'type'     => 'select',
            'label'    => __('Kupon Utama', 'sejowoo'),
            'required' => true,
            'options'  => array(
                            ''  => __('Sistem sedang mengambil kupon yang tersedia...', 'sejowoo')
                         )
        )
    );

    echo woocommerce_form_field(
        'affiliate_coupon',
        array(
            'type'         => 'text',
            'label'        => __('Kupon Anda', 'sejowoo'),
            'required'     => true,
            'autocomplete' => false,
            'description'  => __('Isi dengan kupon yang anda inginkan. Hanya menerima huruf dan angka saja dan minimal 5 karakter', 'sejowoo')
        )
    );
?>
<p>
    <?php wp_nonce_field( 'sejowoo-create-affiliate-coupon' , 'nonce' ); ?>
    <button type="submit" class="woocommerce-Button button button-primary" name="create_affiliate_coupon" value="Save changes">
        <?php _e('Buat kupon affiliasi', 'sejowoo'); ?>
    </button>
</p>

</form>

<div class="sejowoo-table-holder">
    <h3><?php _e('Kupon yang tersedia', 'sejowoo'); ?></h3>
    <table id='sejowoo-coupon' class="sejowoo-coupon-table woocommerce-MyAccount-wallet shop_table shop_table_responsive my_account_wallet account-coupon-table">
        <thead>
            <tr>
                <th><?php _e('Kupon ', 'sejowoo'); ?></th>
                <th><?php _e('Nilai', 'sejowoo'); ?></th>
                <th><?php _e('Limit', 'sejowoo'); ?></th>
            </tr>
        </thead>
        <tbody>

        </tbody>
        <tfoot>
            <tr>
                <th style='max-width:180px'><?php _e('Kupon ', 'sejowoo'); ?></th>
                <th><?php _e('Nilai', 'sejowoo'); ?></th>
                <th style='max-width:60px'><?php _e('Limit', 'sejowoo'); ?></th>
            </tr>
        </tfoot>
    </table>
</div>

<script type="text/javascript">
(function($){

    'use strict';

    let sejowoo_table,
        sejowoo_coupon_select2,
        form = document.getElementById('sejowoo-affiliate-coupon-form'),
        message = document.getElementById('sejowoo-form-message'),
        coupon = document.getElementById('affiliate_coupon');

    form.addEventListener( 'submit', function(e){

        e.preventDefault();

        let data = new FormData(form),
            xhr = new XMLHttpRequest();

        xhr.addEventListener( 'loadstart', function(){
            sejowoo.block( form );
            message.style.display = 'none';
        });

        xhr.addEventListener( 'load', function( response ){
            sejowoo.unblock( form );
            message.style.display = 'block';
        });

        xhr.onreadystatechange = function() {

            message.classList.remove('woocommerce-error');
            message.classList.remove('woocommerce-info');

            if (this.readyState == 4 && this.status == 200) {

                let response = JSON.parse( this.responseText );

                if(false === response.valid ) {
                    message.classList.add('woocommerce-error');
                } else {
                    message.classList.add('woocommerce-info');
                    sejowoo_table.ajax.reload();
                }
                coupon.value = response.coupon;
                message.innerHTML = response.message;
            }
        }

        xhr.open("POST", sejowoo_myaccount.coupon.create.ajaxurl );

        xhr.send(data);
    });

    let updateParentOptions = function() {

        $.ajax({
            url:      sejowoo_myaccount.coupon.parent_list.ajaxurl,
            type:     'GET',
            dataType: 'json',
            success:  function(response) {

                response.forEach(function(i, el){
                    let option = new Option( response[el].text, response[el].id, true, true);
                    sejowoo_coupon_select2.append(option).trigger('change');
                });

            }
        });
    }

    $(document).ready(function(){

        sejowoo_coupon_select2 = $('#parent_coupon').select2();

        updateParentOptions();

        sejowoo_table = $('#sejowoo-coupon').DataTable({
            language: dataTableTranslation,
            searching: false,
            processing: false,
            serverSide: true,
            ajax: {
                type: 'POST',
                url: sejowoo_myaccount.coupon.table.ajaxurl,
                data: function(data) {
                    data.nonce = sejowoo_myaccount.coupon.table.nonce;
                }
            },
            pageLength : 50,
            lengthMenu : [
                [50, 100, 200],
                [50, 100, 200],
            ],
            order: [
                [ 0, "desc" ]
            ],
            columnDefs: [
                {
                    targets: [1, 2],
                    orderable: false
                },{
                    targets: 0,
                    width:   '180px',
                    data:    'coupon',
                    render:  function(data, meta, full) {
                        let tmpl = $.templates('#affiliate-coupon-code');
                        return tmpl.render(full);
                    }
                },{
                    targets: 1,
                    data:    'detail',
                    render:  function(data, meta, full) {
                        let tmpl = $.templates('#affiliate-coupon-detail');
                        return tmpl.render(full);
                    }
                },{
                    targets:   2,
                    width:     '60px',
                    data:      'limit',
                    className: 'center',
                    render:  function(data, meta, full) {
                        let tmpl = $.templates('#affiliate-coupon-limit-detail');
                        return tmpl.render(full);
                    }
                }
            ]
        });

        sejowoo_table.on('preXhr',function(){
            sejowoo.block('.sejowoo-table-holder');
        });

        sejowoo_table.on('xhr',function(){
            sejowoo.unblock('.sejowoo-table-holder');
            new ClipboardJS('.copy-coupon-code');
        });

        $(document).on('click', '.copy-coupon-code', function(){
            $(this).addClass('copied').text('copied');
        });

    });
})(jQuery);
</script>
<!-- AFFILIATE COUPON CODE -->
<script id='affiliate-coupon-code' type="text/x-jsrender">
    {{:coupon}}
    <button id='coupon-{{:id}}' data-id='{{:id}}' type='button' class='copy-button copy-coupon-code' data-clipboard-text='{{:coupon}}'><?php _e('copy ', 'sejowoo'); ?></button>
</script>

<!-- AFFILIATE COUPON DETIL -->
<script id='affiliate-coupon-detail' type="text/x-jsrender">

<label class='label peter-river'><?php _e('DISCOUNT ', 'sejowoo'); ?> {{:discount}}</label>

{{if affiliate}}
<label class='label wisteria'><?php _e('KUPON AFFILIASI ', 'sejowoo'); ?></label>
{{/if}}

{{if free_shipping}}
<label class='label emerald'><?php _e('FREE SHIPPING', 'sejowoo'); ?></label>
{{/if}}

{{if max_amount}}
<label class='label carrot'><?php _e('MAX SHOP ', 'sejowoo'); ?> : {{:max_amount}}</label>
{{/if}}

{{if max_amount}}
<label class='label carrot'><?php _e('MIN SHOP ', 'sejowoo'); ?> : {{:min_amount}}</label>
{{/if}}

{{if expired_date}}
<label class='label pomegranate'><?php _e('EXPIRED ', 'sejowoo'); ?> : {{:expired_date}}</label>
{{/if}}
</script>
<script id='affiliate-coupon-limit-detail' type="text/x-jsrender">
{{:usage_count}}/{{:usage_limit}}
</script>
