<!-- LABEL STATUS - JSRENDERs -->
<script id='sejowoo-label-status' type="text/x-jsrender">
<span class='label' style='background-color:{{:color}}'>
    {{:label}}
</span>
</script>
