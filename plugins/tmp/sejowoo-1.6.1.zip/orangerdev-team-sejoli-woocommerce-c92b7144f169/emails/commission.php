<?php
namespace Sejowoo\Email;

!defined( 'ABSPATH' ) ? exit: true;

/**
 * @since   1.0.0
 */
class Commission extends \WC_Email {

    /**
     * Object data
     * @since   1.0.0
     */
    public $object = array(
        'order'       => NULL,
        'commissions' => array()
    );

    /**
     * Construction
     */
    public function __construct() {

        $this->id             = 'sejowoo-commission-email';
        $this->title          = __('Komisi affiliasi', 'sejowoo');
        $this->description    = __('Email notifikasi yang berisi data komisi untuk affiliasi', 'sejowoo');
        $this->placeholders   = array(
            '{order_date}'   => '',
            '{order_number}' => '',
        );

        add_action( 'sejowoo/commission/update-status-valid', array($this, 'trigger'), 1, 2);

        $this->template_base = SEJOWOO_DIR . 'templates/emails/';
        $this->template_html  = 'affiliate-commission.php';
        $this->template_plain = 'affiliate-commission.php';

        // Call parent constructor.
        parent::__construct();

        $this->recipient      = 'info@affiliate.com';
    }

    /**
     * Get email subject.
     *
     * @since  3.1.0
     * @return string
     */
    public function get_default_subject() {
        return __('Alhamdulillah, ada komisi affiliasi untuk anda dari [{site_title}] order #[{order_number}]', 'sejowoo');;
    }

    /**
     * Get email heading.
     *
     * @since  3.1.0
     * @return string
     */
    public function get_default_heading() {
        return __('Komisi affiliasi untuk anda', 'sejowoo');
    }

    /**
     * Send email
     * @since   1.0.0
     * @param   WC_Order    $order
     * @param   array       $commissions
     * @return
     */
    public function trigger( \WC_Order $order, array $commission_data ) {

        $this->setup_locale();

        if ( ! $this->is_enabled() ) :
            return;
        endif;

        $this->placeholders['{order_date}']   = wc_format_datetime( $order->get_date_created() );
        $this->placeholders['{order_number}'] = $order->get_order_number();

        $this->object['order']         = $order;
        $this->object['email_heading'] = $this->get_heading();
        $this->object['sent_to_admin'] = false;
        $this->object['plain_text']    = false;
        $this->object['email']         = $this;

        foreach( $commission_data as $data ) :

            $this->object['commissions'] = $data['commissions'];

            $this->send(
                $data['user']->get_email(),
                $this->get_subject(),
                $this->get_content(),
                $this->get_headers(),
                $this->get_attachments()
            );

        endforeach;

        $this->restore_locale();
    }

    /**
      * Get email content, HTML type
      * @since  1.0.0
      * @return string
      */
     public function get_content_html() {

         return wc_get_template_html(
             $this->template_html,
             $this->object,
             $this->template_base,
             $this->template_base
         );
     }


     /**
      * Get email content, plain type
      * @since  1.0.0
      * @return string
      */
     public function get_content_plain() {

         return wc_get_template_html(
             $this->template_plain,
             $this->object,
             $this->template_base,
             $this->template_base
         );
     }

     /**
     * Initialize Settings Form Fields
     * @since   1.0.0
     */
     public function init_form_fields() {

         $placeholder_text  = sprintf(
                                    __( 'Shortcode yang tersedia: %s', 'sejowoo' ),
                                    '<code>' . implode( '</code>, <code>', array_keys( $this->placeholders ) ) . '</code>'
                              );

         $this->form_fields = array(

            'enabled'    => array(
                'title'   => __('Aktifkan/Nonaktifkan', 'sejowoo'),
                'type'    => 'checkbox',
                'label'   => __('Aktifkan notifikasi ini?', 'sejowoo'),
                'default' => 'yes'
            ),

            'subject'    => array(
                'title'       => __('Judul Email', 'sejowoo'),
                'type'        => 'text',
                'description' => $placeholder_text,
                'placeholder' => $this->get_default_subject(),
                'default'     => $this->get_default_subject()
            ),

            'heading'    => array(
                'title'       => __('Judul Isi Email', 'sejowoo'),
                'type'        => 'text',
                'description' => $placeholder_text,
                'placeholder' => $this->get_default_heading(),
                'default'     => $this->get_default_heading()
            ),

            'email_type'         => array(
                'title'       => __( 'Tipe Email', 'sejowoo' ),
                'type'        => 'select',
                'description' => __( 'Pilih format email yang digunakan.', 'sejowoo' ),
                'default'     => 'html',
                'class'       => 'email_type wc-enhanced-select',
                'options'     => $this->get_email_type_options(),
                'desc_tip'    => true,
            ),
        );
    }

}
