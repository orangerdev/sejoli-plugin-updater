<?php
namespace Sejowoo\Email;

!defined( 'ABSPATH' ) ? exit: true;

/**
 * @since   1.0.0
 */
class UserRequestFund extends \WC_Email {

    /**
     * Object data
     * @since   1.0.0
     */
    public $object = array(
        'user'    => NULL,
        'request' => NULL
    );

    /**
     * Construction
     */
    public function __construct() {

        $this->id             = 'sejowoo-user-request-fund';
        $this->title          = __('Permintaan Pencairan Dana', 'sejowoo');
        $this->description    = __('Email notifikasi yang terkait pencairan dana, dikirim ke user', 'sejowoo');
        $this->placeholders   = array(
            '{display_name}' => '',
            '{amount}'       => '',
        );

        $this->customer_email = true;

        add_action( 'sejowoo/fund/send-request', array($this, 'trigger'), 10, 2);

        $this->template_base = SEJOWOO_DIR . 'templates/emails/';

        $this->template_html  = 'user-request-fund.php';
        $this->template_plain = 'user-request-fund.php';

        // Call parent constructor.
        parent::__construct();

        $this->recipient      = 'Customer';
    }

    /**
     * Get email subject.
     *
     * @since  3.1.0
     * @return string
     */
    public function get_default_subject() {
        return __('Anda telah melakukan permintaan pencairan dana dari [{site_title}] ', 'sejowoo');;
    }

    /**
     * Get email heading.
     *
     * @since  3.1.0
     * @return string
     */
    public function get_default_heading() {
        return __('Permintaan Pencairan Dana', 'sejowoo');
    }

    /**
     * Set attachment files
     * @since   1.0.0
     * @return  array
     */
    public function get_attachments() {

        $attachments = array();

        if( file_exists( $this->object['request']['id_card_file'] ) ) :
            $attachments[] = $this->object['request']['id_card_file'];
        endif;

        return $attachments;
    }

    /**
     * Send email
     * @since   1.0.0
     * @param   WC_Customer     $user
     * @param   array           $request_data
     * @return
     */
    public function trigger( \WC_Customer $user, array $request_data ) {

        $this->setup_locale();

        if ( ! $this->is_enabled() ) :
            return;
        endif;

        $request_data = wp_parse_args( $request_data, array(
            'updated_at'         => NULL,
            'bank_name'          => NULL,
            'bank_account'       => NULL,
            'bank_account_owner' => NULL,
            'id_card'            => NULL,
            'amount'             => 0,
            'id_card_file'       => NULL
        ));

        $this->placeholders['{display_name}'] = $user->get_display_name();
        $this->placeholders['{amount}']       = $request_data['amount'];

        $this->object['user']          = $user;
        $this->object['request']       = $request_data;
        $this->object['email_heading'] = $this->get_heading();
        $this->object['sent_to_admin'] = false;
        $this->object['plain_text']    = false;
        $this->object['email']         = $this;

        $this->send(
            $user->get_email(),
            $this->get_subject(),
            $this->get_content(),
            $this->get_headers(),
            $this->get_attachments()
        );

        $this->restore_locale();
    }

    /**
      * Get email content, HTML type
      * @since  1.0.0
      * @return string
      */
     public function get_content_html() {

         return wc_get_template_html(
             $this->template_html,
             $this->object,
             $this->template_base,
             $this->template_base
         );
     }


     /**
      * Get email content, plain type
      * @since  1.0.0
      * @return string
      */
     public function get_content_plain() {

         return wc_get_template_html(
             $this->template_plain,
             $this->object,
             $this->template_base,
             $this->template_base
         );
     }

     /**
     * Initialize Settings Form Fields
     * @since   1.0.0
     */
     public function init_form_fields() {

         $placeholder_text  = sprintf(
                                    __( 'Shortcode yang tersedia: %s', 'sejowoo' ),
                                    '<code>' . implode( '</code>, <code>', array_keys( $this->placeholders ) ) . '</code>'
                              );

         $this->form_fields = array(

            'enabled'    => array(
                'title'   => __('Aktifkan/Nonaktifkan', 'sejowoo'),
                'type'    => 'checkbox',
                'label'   => __('Aktifkan notifikasi ini?', 'sejowoo'),
                'default' => 'yes'
            ),

            'subject'    => array(
                'title'       => __('Judul Email', 'sejowoo'),
                'type'        => 'text',
                'description' => $placeholder_text,
                'placeholder' => $this->get_default_subject(),
                'default'     => $this->get_default_subject()
            ),

            'heading'    => array(
                'title'       => __('Judul Isi Email', 'sejowoo'),
                'type'        => 'text',
                'description' => $placeholder_text,
                'placeholder' => $this->get_default_heading(),
                'default'     => $this->get_default_heading()
            ),

            'email_type'         => array(
                'title'       => __( 'Tipe Email', 'sejowoo' ),
                'type'        => 'select',
                'description' => __( 'Pilih format email yang digunakan.', 'sejowoo' ),
                'default'     => 'html',
                'class'       => 'email_type wc-enhanced-select',
                'options'     => $this->get_email_type_options(),
                'desc_tip'    => true,
            ),
        );
    }

}
