<?php

/**
 * Fired during plugin activation
 *
 * @link       https://sejoli.co.id
 * @since      1.0.0
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Sejowoo
 * @subpackage Sejowoo/includes
 * @author     Sejoli <orangerdigiart@gmail.com>
 */
class Sejowoo_Activator {

	/**
	 * Create custom tables for Sejoli
	 * @since    0.1.0
	 */
	public static function activate() {

		SejoWoo\Database\Commission::create_table();
		SejoWoo\Database\RequestFund::create_table();
		SejoWoo\Database\Wallet::create_table();

		// force woocommere to do this
		update_option('woocommerce_enable_guest_checkout',					'no');
		update_option('woocommerce_enable_checkout_login_reminder', 		'yes');
		update_option('woocommerce_enable_signup_and_login_from_checkout',  'yes');
	}

}
