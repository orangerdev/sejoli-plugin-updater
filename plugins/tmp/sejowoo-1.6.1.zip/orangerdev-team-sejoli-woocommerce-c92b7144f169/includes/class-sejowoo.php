<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * @link       https://sejowoo.co.id
 * @since      1.0.0
 *
 * @package    Sejowoo
 * @subpackage Sejowoo/includes
 */

/**
 * The core plugin class.
 *
 * This is used to define internationalization, admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 *
 * @since      1.0.0
 * @package    Sejowoo
 * @subpackage Sejowoo/includes
 * @author     Sejoli <orangerdigiart@gmail.com>
 */
class Sejowoo {

	/**
	 * The loader that's responsible for maintaining and registering all hooks that power
	 * the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      Sejowoo_Loader    $loader    Maintains and registers all hooks for the plugin.
	 */
	protected $loader;

	/**
	 * The unique identifier of this plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $plugin_name    The string used to uniquely identify this plugin.
	 */
	protected $plugin_name;

	/**
	 * The current version of the plugin.
	 *
	 * @since    1.0.0
	 * @access   protected
	 * @var      string    $version    The current version of the plugin.
	 */
	protected $version;

	/**
	 * Define the core functionality of the plugin.
	 *
	 * Set the plugin name and the plugin version that can be used throughout the plugin.
	 * Load the dependencies, define the locale, and set the hooks for the admin area and
	 * the public-facing side of the site.
	 *
	 * @since    1.0.0
	 */
	public function __construct() {
		if ( defined( 'SEJOWOO_VERSION' ) ) {
			$this->version = SEJOWOO_VERSION;
		} else {
			$this->version = '1.0.0';
		}
		$this->plugin_name = 'sejowoo';

		$this->load_dependencies();
		$this->set_locale();
		$this->define_admin_hooks();
		$this->define_public_hooks();
		$this->define_json_hooks();

	}

	/**
	 * Load the required dependencies for this plugin.
	 *
	 * Include the following files that make up the plugin:
	 *
	 * - Sejowoo_Loader. Orchestrates the hooks of the plugin.
	 * - Sejowoo_i18n. Defines internationalization functionality.
	 * - Sejowoo_Admin. Defines all hooks for the admin area.
	 * - Sejowoo_Public. Defines all hooks for the public side of the site.
	 *
	 * Create an instance of the loader which will be used to register the hooks
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function load_dependencies() {

		/**
		 * The class responsible for orchestrating the actions and filters of the
		 * core plugin.
		 */
		require_once SEJOWOO_DIR . 'includes/class-sejowoo-loader.php';

		/**
		 * The class responsible for defining internationalization functionality
		 * of the plugin.
		 */
		require_once SEJOWOO_DIR . 'includes/class-sejowoo-i18n.php';

		/**
		 * The class responsible for integrating with database
		 * @since 0.1.0
		 */
		require_once SEJOWOO_DIR . '/includes/class-sejowoo-database.php';

		/**
		 * The class responsible for defining database process and system logic
		 */
		require_once SEJOWOO_DIR. '/models/main.php';
 		require_once SEJOWOO_DIR. '/models/user.php';

		/**
		 * The class responsible for defining database structure
		 */
		require_once SEJOWOO_DIR. '/databases/main.php';
		require_once SEJOWOO_DIR. '/databases/affiliate.php';
		require_once SEJOWOO_DIR. '/databases/commission.php';
		require_once SEJOWOO_DIR. '/databases/coupon.php';
		require_once SEJOWOO_DIR. '/databases/post.php';
		require_once SEJOWOO_DIR. '/databases/request-fund.php';
		require_once SEJOWOO_DIR. '/databases/wallet.php';

		/**
		 * The class responsible for defining all actions that occur in the admin area.
		 */
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-admin.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-affiliate.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-cashback.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-coupon.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-dokan.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-license.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-leaderboard.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-order.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-product.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-user.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-user-group.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-commission.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-product.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-request-fund.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-social-proof.php';
		require_once SEJOWOO_DIR . 'admin/class-sejowoo-wallet.php';

		/**
		 * The class responsible for defining all actions that occur in the public-facing
		 * side of the site.
		 */
		require_once SEJOWOO_DIR . 'public/class-sejowoo-affiliate.php';
		require_once SEJOWOO_DIR . 'public/class-sejowoo-affiliate-network.php';
		require_once SEJOWOO_DIR . 'public/class-sejowoo-affiliate-order.php';
		require_once SEJOWOO_DIR . 'public/class-sejowoo-cashback.php';
		require_once SEJOWOO_DIR . 'public/class-sejowoo-commission.php';
		require_once SEJOWOO_DIR . 'public/class-sejowoo-coupon.php';
		require_once SEJOWOO_DIR . 'public/class-sejowoo-dokan.php';
		require_once SEJOWOO_DIR . 'public/class-sejowoo-endpoint.php';
		require_once SEJOWOO_DIR . 'public/class-sejowoo-leaderboard.php';
		require_once SEJOWOO_DIR . 'public/class-sejowoo-public.php';
		require_once SEJOWOO_DIR . 'public/class-sejowoo-request-fund.php';
		require_once SEJOWOO_DIR . 'public/class-sejowoo-social-proof.php';
		require_once SEJOWOO_DIR . 'public/class-sejowoo-user-group.php';
		require_once SEJOWOO_DIR . 'public/class-sejowoo-wallet.php';

		/**
		 * The class responsible for defining all actions that work for json functions
		 */
		require_once SEJOWOO_DIR . '/json/main.php'; // MUST BE PUT FIRST
		require_once SEJOWOO_DIR . '/json/affiliate-network.php';
		require_once SEJOWOO_DIR . '/json/bulk-update-product.php';
		require_once SEJOWOO_DIR . '/json/coupon.php';
		require_once SEJOWOO_DIR . '/json/leaderboard.php';
		require_once SEJOWOO_DIR . '/json/product.php';
		require_once SEJOWOO_DIR . '/json/request-fund.php';
		require_once SEJOWOO_DIR . '/json/user.php';
		require_once SEJOWOO_DIR . '/json/wallet.php';
		require_once SEJOWOO_DIR . '/json/order.php';

		/**
		 * The files responsible for defining all functions that will work as helper
		 */
		require_once SEJOWOO_DIR . '/functions/affiliate.php';
		require_once SEJOWOO_DIR . '/functions/cashback.php';
		require_once SEJOWOO_DIR . '/functions/commission.php';
		require_once SEJOWOO_DIR . '/functions/coupon.php';
		require_once SEJOWOO_DIR . '/functions/license.php';
		require_once SEJOWOO_DIR . '/functions/product.php';
		require_once SEJOWOO_DIR . '/functions/other.php';
		require_once SEJOWOO_DIR . '/functions/user.php';
		require_once SEJOWOO_DIR . '/functions/order.php';
		require_once SEJOWOO_DIR . '/functions/request-fund.php';
		require_once SEJOWOO_DIR . '/functions/user-group.php';
		require_once SEJOWOO_DIR . '/functions/wallet.php';

		$this->loader = new Sejowoo_Loader();

		Sejowoo\DB::connection();

		do_action('sejowoo/init');

		$this->loader->add_action('woocommerce_loaded', $this, 'load_models', 10);

	}

	/**
	 * Load models
	 * Hooked via action woocommerce_loaded, priority 10
	 * @since  	0.1.0
	 * @return 	void
	 */
	public function load_models() {

		require_once SEJOWOO_DIR. '/models/commission.php';
		require_once SEJOWOO_DIR. '/models/json.php';

	}

	/**
	 * Define the locale for this plugin for internationalization.
	 *
	 * Uses the Sejowoo_i18n class in order to set the domain and to register the hook
	 * with WordPress.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function set_locale() {

		$plugin_i18n = new Sejowoo_i18n();

		$this->loader->add_action( 'plugins_loaded', $plugin_i18n, 'load_plugin_textdomain' );

	}

	/**
	 * Register all of the hooks related to the admin area functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_admin_hooks() {

		$admin = new Sejowoo\Admin( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'plugins_loaded',				$admin, 'check_if_woocommerce_active',		1);
		$this->loader->add_action( 'plugins_loaded',				$admin, 'setup_database',					1);
		$this->loader->add_action( 'admin_bar_menu',				$admin, 'add_member_area_link',				999);
		$this->loader->add_action( 'after_setup_theme',				$admin, 'load_carbon_fields', 		 		999);
		$this->loader->add_action( 'carbon_fields_register_fields',	$admin, 'setup_carbon_fields', 		 		10);
		$this->loader->add_filter( 'sejowoo/general/container',		$admin, 'get_container', 			 		999);
		$this->loader->add_filter( 'sejowoo/general/fields',		$admin, 'set_sejowoo_general_fields', 		10);
		$this->loader->add_action( 'admin_enqueue_scripts',			$admin, 'enqueue_styles', 	 				999);
		$this->loader->add_action( 'admin_enqueue_scripts',			$admin, 'enqueue_scripts', 	 				999);
		$this->loader->add_action( 'admin_init',					$admin, 'check_page_request',    			999);
		$this->loader->add_filter( 'sejowoo/general/fields',		$admin, 'set_debug_fields', 				999999);

		$this->loader->add_filter( 'sejowoo/admin/is-sejowoo-page',	$admin, 'is_sejowoo_page',			 		1);
		$this->loader->add_action( 'admin_notices',					$admin, 'notify_check_woocommerce', 		100);

		$affiliate = new Sejowoo\Admin\Affiliate( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'init',														$affiliate, 'register_post_type', 			999);
		$this->loader->add_action( 'wp_ajax_sejowoo-get-affiliate-user-list',					$affiliate, 'get_affiliate_list',			999);
		$this->loader->add_action( 'carbon_fields_register_fields', 							$affiliate, 'setup_carbon_fields', 			1009);
		$this->loader->add_filter( 'sejowoo/admin/js-localize-data',							$affiliate, 'set_localize_js_var',			1);
		$this->loader->add_filter( 'sejowoo/general/fields',									$affiliate, 'set_sejowoo_general_fields',	20);
		$this->loader->add_filter( 'manage_edit-'. SEJOWOO_AFFILIATE_CPT.'_columns',			$affiliate, 'add_custom_columns',			119);
		$this->loader->add_action( 'manage_'. SEJOWOO_AFFILIATE_CPT.'_posts_custom_column',		$affiliate, 'display_custom_column_values', 119, 2);

		$cashback = new Sejowoo\Admin\Cashback( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_filter( 'sejowoo/cashback/setting',							$cashback, 'set_cashback_setting', 10, 2);

		$this->loader->add_filter( 'woocommerce_product_data_tabs', 					$cashback, 'add_product_tab',	   		10 );
		$this->loader->add_action( 'woocommerce_product_data_panels', 					$cashback, 'set_cashback_fields', 		10 );
		$this->loader->add_action( 'woocommerce_product_after_variable_attributes',		$cashback, 'set_cashback_fields_for_variation', 100, 3);
		$this->loader->add_action( 'woocommerce_process_product_meta', 					$cashback, 'save_product_options', 		10 );
		$this->loader->add_action( 'woocommerce_save_product_variation',				$cashback, 'save_product_variation',	10, 2);

		$this->loader->add_action( 'woocommerce_checkout_order_created',		$cashback, 'add_cashback_in_order', 200, 3);
		$this->loader->add_action( 'woocommerce_order_status_pending', 			$cashback, 'set_cashback_status_invalid', 200);
		$this->loader->add_action( 'woocommerce_order_status_failed', 			$cashback, 'set_cashback_status_invalid', 200);
		$this->loader->add_action( 'woocommerce_order_status_on-hold', 			$cashback, 'set_cashback_status_invalid', 200);
		$this->loader->add_action( 'woocommerce_order_status_refunded', 		$cashback, 'set_cashback_status_invalid', 200);
		$this->loader->add_action( 'woocommerce_order_status_cancelled', 		$cashback, 'set_cashback_status_invalid', 200);
		$this->loader->add_action( 'woocommerce_order_status_processing', 		$cashback, 'set_cashback_status_invalid', 200);
		$this->loader->add_action( 'woocommerce_order_status_completed', 		$cashback, 'set_cashback_status_valid', 200);

		$commission = new Sejowoo\Admin\Commission( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'init', 										$commission, 'register_post_type', 				100);
		$this->loader->add_filter( 'manage_sejowoo-commission_posts_columns',	$commission, 'modify_admin_columns',			100);
		$this->loader->add_action( 'manage_posts_custom_column',				$commission, 'display_setup_data',				100, 2);
		$this->loader->add_filter( 'sejowoo/commission/fields',					$commission, 'setup_commission_tier_fields',	1);
		$this->loader->add_action( 'carbon_fields_register_fields',				$commission, 'register_commission_fields', 		100);
		$this->loader->add_filter( 'sejowoo/commission/options',				$commission, 'get_as_options',					100);
		$this->loader->add_filter( 'woocommerce_email_classes',					$commission, 'register_email',					100);

		$this->loader->add_action( 'admin_init',								$commission, 'check_product_commission',		989);
		$this->loader->add_action( 'admin_init',								$commission, 'check_order_commission',			989);

		$this->loader->add_action( 'admin_menu',								$commission, 'register_admin_submenu',			100);

		$this->loader->add_action( 'woocommerce_checkout_order_created',		$commission, 'calculate_order_commission',		11, 3);
		$this->loader->add_action( 'woocommerce_order_status_pending', 			$commission, 'set_commission_status_invalid',   299);
		$this->loader->add_action( 'woocommerce_order_status_failed', 			$commission, 'set_commission_status_invalid',   299);
		$this->loader->add_action( 'woocommerce_order_status_on-hold', 			$commission, 'set_commission_status_invalid',   299);
		$this->loader->add_action( 'woocommerce_order_status_refunded', 		$commission, 'set_commission_status_invalid',   299);
		$this->loader->add_action( 'woocommerce_order_status_cancelled', 		$commission, 'set_commission_status_invalid',   299);
		$this->loader->add_action( 'woocommerce_order_status_processing', 		$commission, 'set_commission_status_invalid', 	299);
		$this->loader->add_action( 'woocommerce_order_status_completed', 		$commission, 'set_commission_status_valid',     299);

		$coupon = new Sejowoo\Admin\Coupon( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_init',								$coupon, 'save_new_coupon',				199);
		$this->loader->add_action( 'admin_notices',								$coupon, 'display_notice',				199);
		$this->loader->add_action( 'wp_ajax_sejowoo-get-main-coupons',			$coupon, 'get_main_coupons',			199);
		$this->loader->add_action( 'admin_menu',								$coupon, 'add_affiliate_coupon_menu',   100);
		$this->loader->add_action( 'admin_enqueue_scripts',						$coupon, 'register_needed_css_and_js_files', 199);
		$this->loader->add_filter( 'woocommerce_coupon_data_tabs',				$coupon, 'set_tab_fields',						100);
		$this->loader->add_action( 'woocommerce_coupon_options',				$coupon, 'add_shipping_cost_reduction_options', 100, 2);
		$this->loader->add_action( 'woocommerce_coupon_data_panels',			$coupon, 'add_affiliate_setup_options', 		100, 2);
		$this->loader->add_action( 'woocommerce_coupon_options_save',			$coupon, 'save_meta_data',						100, 2);
		$this->loader->add_filter( 'manage_edit-shop_coupon_columns',			$coupon, 'add_custom_columns',					100);
		$this->loader->add_action( 'manage_shop_coupon_posts_custom_column',	$coupon, 'display_custom_column_values',		100, 2);
		$this->loader->add_action( 'admin_footer',								$coupon, 'add_js_script',						100);

		$dokan = new Sejowoo\Admin\Dokan( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_filter( 'sejowoo/general/fields',				$dokan, 'setup_setting_fields', 		   9999);
		$this->loader->add_action( 'dokan_before_prepare_for_calculation',	$dokan, 'prepare_before_insert_to_wallet', 9999, 4);
		$this->loader->add_filter( 'dokan_prepare_for_calculation',			$dokan, 'calculate_earning', 			   9999, 6);
		$this->loader->add_filter( 'dokan_get_earning_by_product', 			$dokan, 'insert_to_wallet',				   9999, 3);

		$this->loader->add_action( 'woocommerce_order_status_pending', 		$dokan, 'set_revenue_status_invalid',   399);
		$this->loader->add_action( 'woocommerce_order_status_failed', 		$dokan, 'set_revenue_status_invalid',   399);
		$this->loader->add_action( 'woocommerce_order_status_on-hold', 		$dokan, 'set_revenue_status_invalid',   399);
		$this->loader->add_action( 'woocommerce_order_status_refunded', 	$dokan, 'set_revenue_status_invalid',   399);
		$this->loader->add_action( 'woocommerce_order_status_cancelled', 	$dokan, 'set_revenue_status_invalid',   399);
		$this->loader->add_action( 'woocommerce_order_status_processing', 	$dokan, 'set_revenue_status_invalid', 	399);
		$this->loader->add_action( 'woocommerce_order_status_completed', 	$dokan, 'set_revenue_status_valid',     399);

		$license = new Sejowoo\Admin\License( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'plugins_loaded',							$license, 'check_license', 				1);
		$this->loader->add_action( 'sejoli/admin/js-localize-data',				$license, 'set_localize_js_var',		1);
		$this->loader->add_action( 'wp_ajax_sejoli-validate-license',			$license, 'validate_sejoli_license',	1);
		$this->loader->add_action( 'wp_ajax_sejoli-reset-license',				$license, 'reset_sejoli_license',		1);
		$this->loader->add_action( 'admin_notices',								$license, 'display_license_message', 		1);
		$this->loader->add_action( 'admin_notices',								$license, 'display_your_license_message', 	1);
		$this->loader->add_action( 'admin_init',								$license, 'register_routine',				1);
		$this->loader->add_action( 'admin_init',								$license, 'check_license_form',				1);
		$this->loader->add_action( 'admin_menu',								$license, 'register_license_form',			1);
		// DEMI ALLAH, SIAPAPUN YANG MENGAKALI LICENSE INI, SAYA TIDAK IKHLAS. REZEKI KELUARGA DAN ANAK SAYA ADA DISINI
		// SAYA HANYA MENDOAKAN SIAPAPUN YANG MENGAKALI LICENSE INI AGAR BERTAUBAT
		$this->loader->add_action( 'sejoli/license/berkah',						$license, 'check_license_routine',			1);
		$this->loader->add_action( 'admin_menu',								$license, 'register_admin_menu', 			1005);
		$this->loader->add_action( 'admin_menu',								$license, 'register_your_license_menu',		99999);

		$leaderboard = new Sejowoo\Admin\Leaderboard( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_filter( 'sejowoo/admin/is-sejowoo-page', 			$leaderboard, 'set_needed_scripts',	 		10);
		$this->loader->add_action( 'sejowoo/admin/js-localize-data',			$leaderboard, 'set_localize_js_var', 		105);
		$this->loader->add_action( 'admin_menu',								$leaderboard, 'register_leaderboard_menu',	105);

		$order = new Sejowoo\Admin\Order( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_filter( 'manage_edit-shop_order_columns',			$order, 'add_custom_columns',			100);
		$this->loader->add_action( 'manage_shop_order_posts_custom_column',		$order, 'display_custom_column_values',100, 2);

		$product = new Sejowoo\Admin\Product( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_filter( 'sejowoo/admin/js-localize-data',					$product, 'set_localize_js_var',			1);
		$this->loader->add_action( 'admin_enqueue_scripts',								$product, 'register_css_and_js_files',	    1001);
		$this->loader->add_action( 'carbon_fields_register_fields',						$product, 'register_bulk_product_options',	100);
		$this->loader->add_action( 'admin_footer',										$product, 'set_javascript_code',			1);

		$this->loader->add_action( 'manage_posts_custom_column',						$product, 'display_product_detail',			1000, 2);

		$this->loader->add_action( 'woocommerce_product_options_general_product_data',	$product, 'add_commission_field', 				100);
		$this->loader->add_action( 'woocommerce_product_after_variable_attributes',		$product, 'add_commission_field_for_variation', 100, 3);
		$this->loader->add_action( 'woocommerce_process_product_meta',					$product, 'save_product_meta',					100);
		$this->loader->add_action( 'woocommerce_save_product_variation',				$product, 'save_product_variation',				100, 2);
		$this->loader->add_filter( 'sejowoo/general/fields',							$product, 'setup_setting_fields', 90);

		$request_fund = new Sejowoo\Admin\RequestFund( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_filter( 'sejowoo/admin/is-sejowoo-page', 			$request_fund, 'set_needed_scripts',	122);
		$this->loader->add_filter( 'sejowoo/admin/js-localize-data',			$request_fund, 'set_localize_js_var',	122);
		$this->loader->add_filter( 'woocommerce_email_classes',					$request_fund, 'register_emails', 		122);
		$this->loader->add_action( 'admin_menu',								$request_fund, 'register_admin_menu', 	122);
		$this->loader->add_action( 'sejowoo/fund/send-request', 				$request_fund, 'do_request',			5, 2);
		$this->loader->add_action( 'sejowoo/fund/update-request',				$request_fund, 'update_request',		5, 2);
		$this->loader->add_action( 'sejowoo/email-content/request-fund',		$request_fund, 'set_detail_email_content', 1);
		$this->loader->add_action( 'sejowoo/email-content/info-request-fund',	$request_fund, 'set_detail_email_content_for_information_process', 1);

		$social_proof = new Sejowoo\Admin\SocialProof( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_filter( 'sejowoo/general/fields',				$social_proof, 'setup_setting_fields', 90);
		$this->loader->add_action( 'admin_footer',							$social_proof, 'add_js_code',		   90);

		$user = new Sejowoo\Admin\User( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'init',										$user, 'create_member_role',	1);
		$this->loader->add_filter( 'sejowoo/admin/js-localize-data',			$user, 'set_localize_js_var',	1);
		$this->loader->add_action( 'carbon_fields_register_fields',				$user, 'setup_profile_fields',	999);
		$this->loader->add_filter( 'sejowoo/user/meta-data',				 	$user, 'declare_user_meta',		1);
		$this->loader->add_filter( 'sejowoo/user/meta-data',				 	$user, 'set_user_meta',			999);
		$this->loader->add_action( 'woocommerce_checkout_order_created',		$user, 'set_affiliate',			10, 3);
		$this->loader->add_action( 'admin_footer',						 		$user, 'add_profile_js',		999);
		$this->loader->add_filter( 'sejowoo/user/affiliate-user',		 		$user, 'get_affiliate_users', 	100);
		$this->loader->add_action( 'show_user_profile', 				 		$user, 'set_user_affiliate', 10 );
		$this->loader->add_action( 'edit_user_profile', 				 		$user, 'set_user_affiliate', 10 );
		$this->loader->add_action( 'personal_options_update', 			 		$user, 'save_user_affiliate_profile_fields' );
		$this->loader->add_action( 'edit_user_profile_update', 			 		$user, 'save_user_affiliate_profile_fields' );

		$usergroup = new Sejowoo\Admin\UserGroup( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'init',								 		$usergroup, 'register_post_type', 			1010);
		$this->loader->add_filter( 'sejowoo/cashback/setting',					$usergroup, 'set_cashback_setting', 		5, 2);
		$this->loader->add_filter( 'sejowoo/admin/js-localize-data', 	 		$usergroup, 'set_localize_js_var',			1);
		$this->loader->add_action( 'admin_menu',						 		$usergroup, 'add_custom_user_menu',			100);
		$this->loader->add_action( 'admin_enqueue_scripts',				 		$usergroup, 'register_css_and_js',			100);
		$this->loader->add_filter( 'sejowoo/admin/is-sejowoo-page',		 		$usergroup, 'is_sejowoo_page', 				1000);
		$this->loader->add_action( 'carbon_fields_register_fields',		 		$usergroup, 'setup_group_fields',  			1010);
		$this->loader->add_filter( 'sejowoo/general/fields',					$usergroup, 'setup_setting_fields', 		10);
		$this->loader->add_action( 'save_post_' . SEJOWOO_USER_GROUP_CPT,		$usergroup, 'set_transient_data',			1010, 2);

		$this->loader->add_filter( 'woocommerce_product_data_tabs', 				$usergroup, 'setup_group_product_data_tab',	10);
		$this->loader->add_action( 'woocommerce_product_data_panels', 				$usergroup, 'user_group_product_data', 		10 );
		$this->loader->add_action( 'woocommerce_product_after_variable_attributes', $usergroup, "user_group_product_data_in_variation", 10, 3);
		$this->loader->add_action( 'woocommerce_process_product_meta', 				$usergroup, 'save_group_data_product_option_fields', 10 );
		$this->loader->add_action( 'woocommerce_save_product_variation',			$usergroup, "save_group_data_product_option_fields_in_variation", 10, 2);

		$this->loader->add_filter( 'sejowoo/product/fields',				 	$usergroup, 'setup_group_setting_fields', 	25);
		$this->loader->add_filter( 'sejowoo/product/meta-data',			 		$usergroup, 'setup_group_product_meta',   	50, 2);
		$this->loader->add_action( 'sejowoo/user/fields',		 		 		$usergroup, 'setup_user_fields',  			20);
		$this->loader->add_filter( 'sejowoo/user/meta-data',				 	$usergroup, 'set_user_meta',				1001);
		$this->loader->add_action( 'pre_get_posts',								$usergroup, 'sort_group_by_priority',		1);

		$this->loader->add_filter( 'manage_sejowoo-user-group_posts_columns',	$usergroup, 'modify_group_columns', 		1);
		$this->loader->add_action( 'manage_posts_custom_column',		 		$usergroup, 'display_custom_data_in_table',	100, 2);
		$this->loader->add_filter( 'manage_users_columns', 				 		$usergroup, 'modify_user_table', 			10);
		$this->loader->add_filter( 'manage_users_custom_column', 		 		$usergroup, 'display_value_for_user_table', 20, 3 );

		$this->loader->add_filter( 'sejowoo/product/price',						$usergroup, 'set_discount_product_price',	100, 2);
		$this->loader->add_filter( 'sejowoo/commission/value',					$usergroup, 'set_commission_value',			100, 4);
		$this->loader->add_action( 'sejowoo_ajax_sejowoo-user-export',			$usergroup, 'export_csv',			 		1);
		$this->loader->add_filter( 'sejowoo/user/roles',						$usergroup, 'set_role_names',				1, 2);

		// $this->loader->add_action( 'woocommerce_order_status_processing', 		$usergroup, 'update_user_group', 			10, 1);
		$this->loader->add_action( 'woocommerce_order_status_completed',		$usergroup, 'update_user_group_by_total_order',	90, 1);
		$this->loader->add_action( 'woocommerce_order_status_completed', 		$usergroup, 'update_user_group_by_product',		100, 1);

		$this->loader->add_filter( 'woocommerce_add_to_cart_validation', 		$usergroup, 'validate_product_permission_by_user_group', 10, 5 );

		$this->loader->add_action( 'user_register',								$usergroup, 'set_default_user_group', 10);

		$wallet = new Sejowoo\Admin\Wallet( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'admin_menu',								$wallet, 'register_admin_menu',  10);
		$this->loader->add_filter( 'sejowoo/general/fields',					$wallet, 'setup_setting_fields', 80);
		$this->loader->add_filter( 'sejowoo/admin/is-sejowoo-page', 			$wallet, 'set_needed_scripts',	 10);
		$this->loader->add_filter( 'sejowoo/admin/js-localize-data',			$wallet, 'set_localize_js_var',	 10);
		$this->loader->add_action( 'sejowoo/fund/update-request',				$wallet, 'update_point_status_when_request_fund_processed', 10, 2);
		$this->loader->add_action( 'woocommerce_checkout_update_order_meta',	$wallet, 'check_if_order_use_wallet', 100);
		$this->loader->add_action( 'woocommerce_order_status_failed', 			$wallet, 'set_wallet_use_status_invalid', 	100);
		$this->loader->add_action( 'woocommerce_order_status_refunded', 		$wallet, 'set_wallet_use_status_invalid',   100);
		$this->loader->add_action( 'woocommerce_order_status_cancelled', 		$wallet, 'set_wallet_use_status_invalid',   100);
	}

	/**
	 * Register all of the hooks related to the public-facing functionality
	 * of the plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 */
	private function define_public_hooks() {

		$public = new Sejowoo\Front( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'sejowoo/myaccount/set-sejowoo-page',	$public, 'set_is_sejowoo_page', 			1);
		$this->loader->add_action( 'init',									$public, 'prepare_woocommerce_endpoint',	1);
		$this->loader->add_filter( 'woocommerce_account_menu_items', 		$public, 'add_my_account_links', 			100);
		$this->loader->add_filter( 'woocommerce_get_query_vars',			$public, 'register_my_account_endpoint',	1999);
		$this->loader->add_action( 'wp_enqueue_scripts', 					$public, 'enqueue_styles', 					999);
		$this->loader->add_action( 'wp_enqueue_scripts', 					$public, 'enqueue_scripts', 				999);

		$affiliate = new Sejowoo\Front\Affiliate( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'init',												$affiliate, 'set_endpoint',		 1);
		$this->loader->add_filter( 'query_vars',										$affiliate, 'set_query_vars',	 999);
		$this->loader->add_action( 'sejowoo/affiliate/set-cookie',						$affiliate, 'set_cookie',		 1);
		$this->loader->add_action( 'sejowoo/affiliate/redirect',						$affiliate, 'redirect',			 999);
		$this->loader->add_action( 'parse_query',										$affiliate, 'check_parse_query', 100);
		$this->loader->add_filter( 'sejowoo/my-account-endpoint/vars',					$affiliate, 'register_my_account_endpoint',	12);

		$this->loader->add_filter( 'sejowoo/user/affiliate',							$affiliate, 'disable_use_own_affiliate',		 999, 2);
		$this->loader->add_filter( 'woocommerce_update_order_review_fragments',			$affiliate, 'ajax_display_affiliate_info', 	 200);
		$this->loader->add_action( 'woocommerce_review_order_after_submit',				$affiliate, 'display_affiliate_info',		 200);

		$this->loader->add_action( 'woocommerce_checkout_create_order', 				$affiliate, 'set_order_meta', 				 10, 1 );
		$this->loader->add_filter( 'woocommerce_order_data_store_cpt_get_orders_query', $affiliate, 'set_wc_order_custom_query_var', 10, 2 );

		$this->loader->add_action( 'template_redirect',									$affiliate, 'set_is_sejowoo_page',		111);
		$this->loader->add_action( 'sejowoo/myaccount/js-localize-data',				$affiliate, 'set_localize_js_vars',		111);
		$this->loader->add_filter( 'sejowoo/myaccount/links',							$affiliate, 'add_my_account_links',		10);
		$this->loader->add_filter( 'woocommerce_endpoint_affiliate-link_title',			$affiliate, 'set_my_account_title',		1);
		$this->loader->add_action( 'woocommerce_account_affiliate-link_endpoint', 		$affiliate, 'set_my_account_content', 	1);

		// Actions used to insert a new endpoint in the WordPress.
		$this->loader->add_action( 'init', $affiliate, 'add_endpoints' );
		$this->loader->add_filter( 'query_vars', $affiliate, 'add_query_vars', 0 );

		$affiliate_order = new Sejowoo\Front\AffiliateOrder( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'parse_query',									$affiliate_order, 'set_is_sejowoo_page', 			111);
		$this->loader->add_action( 'sejowoo/myaccount/js-localize-data',			$affiliate_order, 'set_localize_js_vars',			111);
		$this->loader->add_filter( 'sejowoo/my-account-endpoint/vars',				$affiliate_order, 'register_my_account_endpoint',	10);
		$this->loader->add_filter( 'sejowoo/myaccount/links',						$affiliate_order, 'add_my_account_links',			5);
		$this->loader->add_filter( 'woocommerce_endpoint_affiliate-order_title',	$affiliate_order, 'set_my_account_title', 			1);
		$this->loader->add_action( 'woocommerce_account_affiliate-order_endpoint', 	$affiliate_order, 'set_my_account_content', 		1);

		// Actions used to insert a new endpoint in the WordPress.
		$this->loader->add_action( 'init', $affiliate_order, 'add_endpoints' );
		$this->loader->add_filter( 'query_vars', $affiliate_order, 'add_query_vars', 0 );

		$affiliate_network = new Sejowoo\Front\AffiliateNetwork( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'sejowoo/myaccount/js-localize-data',				$affiliate_network, 'set_localize_js_vars',		 	133);
		$this->loader->add_filter( 'sejowoo/my-account-endpoint/vars',					$affiliate_network, 'register_my_account_endpoint', 16);
		$this->loader->add_filter( 'sejowoo/myaccount/links',							$affiliate_network, 'add_my_account_links',			30);
		$this->loader->add_action( 'wp_enqueue_scripts',								$affiliate_network, 'register_css_and_js_files',	1133);
		$this->loader->add_filter( 'woocommerce_endpoint_affiliate-network_title',		$affiliate_network, 'set_my_account_title',			1);
		$this->loader->add_action( 'woocommerce_account_affiliate-network_endpoint',	$affiliate_network, 'set_my_account_content',		1);

		// Actions used to insert a new endpoint in the WordPress.
		$this->loader->add_action( 'init', $affiliate_network, 'add_endpoints' );
		$this->loader->add_filter( 'query_vars', $affiliate_network, 'add_query_vars', 0 );

		$cashback = new Sejowoo\Front\Cashback( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'woocommerce_before_checkout_form',			$cashback, 'calculate_potential_cashback',	10);
		$this->loader->add_action( 'woocommerce_checkout_order_review',			$cashback, 'display_cashback_info',			11);
		$this->loader->add_filter( 'woocommerce_update_order_review_fragments',	$cashback, 'ajax_display_cashback_info', 	100);

		$commission = new Sejowoo\Front\Commission( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'woocommerce_before_checkout_form',			$commission, 'calculate_potential_commission',	10);

		$coupon = new Sejowoo\Front\Coupon( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'sejowoo/affiliate/set-cookie',						$coupon, 'set_affiliate_coupon',			144);
		$this->loader->add_action( 'wp',												$coupon, 'apply_affiliate_coupon_in_cart_checkout_page',		100);
		$this->loader->add_filter( 'sejowoo/user/affiliate',							$coupon, 'set_user_affiliate',				100, 4);
		$this->loader->add_action( 'sejowoo/myaccount/js-localize-data',				$coupon, 'set_localize_js_vars',		 	144);
		$this->loader->add_filter( 'sejowoo/my-account-endpoint/vars',					$coupon, 'register_my_account_endpoint', 	14);
		$this->loader->add_filter( 'sejowoo/myaccount/links',							$coupon, 'add_my_account_links',			20);
		$this->loader->add_action( 'template_redirect',									$coupon, 'set_is_sejowoo_page',				144);
		$this->loader->add_filter( 'woocommerce_endpoint_affiliate-coupon_title',		$coupon, 'set_my_account_title',			1);
		$this->loader->add_action( 'woocommerce_account_affiliate-coupon_endpoint',		$coupon, 'set_my_account_content',			1);
		$this->loader->add_action( 'woocommerce_cart_calculate_fees',					$coupon, 'set_shipping_cost_reduction',		999);

		// Actions used to insert a new endpoint in the WordPress.
		$this->loader->add_action( 'init', $coupon, 'add_endpoints' );
		$this->loader->add_filter( 'query_vars', $coupon, 'add_query_vars', 0 );

		$dokan = new Sejowoo\Front\Dokan( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'init',									$dokan, 'register_myaccount_endpoint',		1);
		$this->loader->add_action( 'init',									$dokan, 'remove_unneeded_product_fields',	9999);

		$this->loader->add_action( 'dokan_new_product_added', 				$dokan, 'save_product', 	 	100, 2);
		$this->loader->add_action( 'dokan_product_updated', 				$dokan, 'save_product', 	 	100, 2);
		$this->loader->add_filter( 'sejowoo/wallet/note', 					$dokan, 'set_wallet_detail', 	100, 2);
		$this->loader->add_filter( 'dokan_get_dashboard_nav',				$dokan, 'remove_unneeded_menu', 100);
		$this->loader->add_action( 'template_redirect',						$dokan, 'redirect_myaccount_to_vendor_dashboard', 1);
		$this->loader->add_filter( 'woocommerce_add_to_cart_validation', 	$dokan, 'prevent_vendor_buy_own_product',   100, 2);

		$this->loader->add_action( 'wp_enqueue_scripts',					$dokan, 'set_localize_js_vars', 		100);
		$this->loader->add_filter( 'dokan_product_cat_dropdown_args', 		$dokan, 'modify_product_category_args',	999);
		$this->loader->add_filter( 'dokan_bulk_order_statuses',				$dokan, 'modify_bulk_order_statuses',	100);
		$this->loader->add_filter( 'woocommerce_admin_order_actions',		$dokan, 'modify_order_actions',			100, 2);

		$this->loader->add_filter( 'woocommerce_account_menu_items', 		$dokan, 'add_my_account_links',   			999);
		$this->loader->add_filter( 'dokan_get_dashboard_settings_nav',		$dokan, 'setup_dokan_store_setting_nav',	999);

		$endpoint = new Sejowoo\Front\Endpoint( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'init',	 				$endpoint, 'set_endpoint', 		10);
		$this->loader->add_filter( 'query_vars',			$endpoint, 'set_query_vars',	10);
		$this->loader->add_action( 'parse_query',			$endpoint, 'check_parse_query',	10);

		$leaderboard = new Sejowoo\Front\Leaderboard( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_filter( 'sejowoo/my-account-endpoint/vars',			$leaderboard, 'register_my_account_endpoint', 17);
		$this->loader->add_action( 'wp_enqueue_scripts',						$leaderboard, 'register_css_and_js_files',	  1155);
		$this->loader->add_action( 'sejowoo/myaccount/js-localize-data',		$leaderboard, 'set_localize_js_vars',		  155);
		$this->loader->add_filter( 'sejowoo/myaccount/links',					$leaderboard, 'add_my_account_links',		  31);
		$this->loader->add_action( 'template_redirect',							$leaderboard, 'set_is_sejowoo_page',		  155);
		$this->loader->add_filter( 'woocommerce_endpoint_leaderboard_title',	$leaderboard, 'set_my_account_title',		  1);
		$this->loader->add_action( 'woocommerce_account_leaderboard_endpoint',	$leaderboard, 'set_my_account_content',		  1);

		// Actions used to insert a new endpoint in the WordPress.
		$this->loader->add_action( 'init', $leaderboard, 'add_endpoints' );
		$this->loader->add_filter( 'query_vars', $leaderboard, 'add_query_vars', 0 );

		$request_fund = new Sejowoo\Front\RequestFund( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'init',										$request_fund, 'set_endpoint', 				   122);
		$this->loader->add_action( 'parse_query',								$request_fund, 'set_is_sejowoo_page', 		   122);
		$this->loader->add_action( 'sejowoo/myaccount/js-localize-data',		$request_fund, 'set_localize_js_vars',		   122);
		$this->loader->add_filter( 'sejowoo/myaccount/links',					$request_fund, 'add_my_account_links',		   55);
		$this->loader->add_action( 'woocommerce_account_request-fund_endpoint', $request_fund, 'display_request_fund_page',	   122);
		$this->loader->add_filter( 'the_title',									$request_fund, 'set_page_title',			   122, 2);

		$social_proof 	= new Sejowoo\Front\SocialProof( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'init',									$social_proof, 'set_endpoint', 			1);
		$this->loader->add_filter( 'query_vars', 							$social_proof, 'set_query_vars', 		1019);
		$this->loader->add_action( 'wp_loaded',								$social_proof, 'set_if_activated',		1);
		$this->loader->add_action( 'parse_query',							$social_proof, 'check_parse_query', 	19);
		$this->loader->add_action( 'sejowoo-ajax/get-social-proof-data',	$social_proof, 'get_order_data',		1);
		$this->loader->add_action( 'wp',									$social_proof, 'check_if_enabled',		1019);
		$this->loader->add_action( 'body_class',							$social_proof, 'set_body_classes',		1019);
		$this->loader->add_action( 'wp_enqueue_scripts',					$social_proof, 'set_localize_js_vars',	1019);
		$this->loader->add_action( 'wp_footer',								$social_proof, 'set_scripts',			1019);

		$user_group = new Sejowoo\Front\UserGroup( $this->get_plugin_name(), $this->get_version() );

		// $this->loader->add_action( 'woocommerce_get_price_html',					  $user_group, 'set_front_price_html', 220, 2);
		$this->loader->add_action( 'woocommerce_before_calculate_totals',			  $user_group, 'set_price_in_cart',	 220);
		// $this->loader->add_filter( 'woocommerce_product_get_regular_price', 		  $user_group, 'set_price_based_user_group', 99, 2);
        // $this->loader->add_filter( 'woocommerce_product_get_sale_price',    		  $user_group, 'set_price_based_user_group', 99, 2);
        $this->loader->add_filter( 'woocommerce_product_get_price', 			 	  $user_group, 'set_price_based_user_group', 99, 2);
        // $this->loader->add_filter( 'woocommerce_product_variation_get_regular_price', $user_group, 'set_price_based_user_group', 99, 2);
        // $this->loader->add_filter( 'woocommerce_product_variation_get_sale_price', 	  $user_group, 'set_price_based_user_group', 99, 2);
        $this->loader->add_filter( 'woocommerce_product_variation_get_price', 		  $user_group, 'set_price_based_user_group', 99, 2);
        $this->loader->add_filter( 'woocommerce_sale_flash', $user_group, 'sejowoo_hide_default_sales_flash' );
        $this->loader->add_filter( 'woocommerce_before_shop_loop_item_title', $user_group, 'add_percentage_to_sale_badge', 20, 3 );
        $this->loader->add_filter( 'woocommerce_product_thumbnails', $user_group, 'add_percentage_to_sale_badge', 20, 3 );

		$wallet = new Sejowoo\Front\Wallet( $this->get_plugin_name(), $this->get_version() );

		$this->loader->add_action( 'init',	 									$wallet, 'register_myaccount_endpoint',  105);
		$this->loader->add_action( 'parse_query',								$wallet, 'set_is_sejowoo_page', 		 105);
		$this->loader->add_action( 'sejowoo/myaccount/js-localize-data',		$wallet, 'set_localize_js_vars',		 105);
		$this->loader->add_filter( 'sejowoo/myaccount/links',					$wallet, 'add_my_account_links',		 50);
		$this->loader->add_action( 'woocommerce_account_wallet-data_endpoint', 	$wallet, 'display_data_content', 		 1);
		$this->loader->add_action( 'woocommerce_cart_calculate_fees',			$wallet, 'set_wallet_use_to_cart',		 105);
		$this->loader->add_action( 'woocommerce_checkout_order_review',			$wallet, 'display_wallet_use_field',	 12);
		$this->loader->add_filter( 'woocommerce_calculated_total',				$wallet, 'set_cart_total_value',		 105, 2);
		$this->loader->add_action( 'woocommerce_checkout_order_created',		$wallet, 'set_wallet_use_to_order', 	 105, 3);
		$this->loader->add_action( 'wp_footer',									$wallet, 'add_checkout_script_js',		 105);

	}

	/**
	 * Register all of the hooks related to json request
	 *
	 * @since 	1.0.0
	 * @access 	private
	 */
	private function define_json_hooks() {

		$affiliate_network = new Sejowoo\JSON\AffiliateNetwork();

		$this->loader->add_action( 'sejowoo-ajax/get-network-list',			$affiliate_network, 'get_network_list', 	1);
		$this->loader->add_action( 'sejowoo-ajax/get-network-detail',		$affiliate_network, 'get_network_detail',	1);

		$bulk_update_product = new Sejowoo\JSON\BulkUpdateProduct();

		$this->loader->add_action( 'wp_ajax_bulk-update-cashback-product',		$bulk_update_product, 'update_cashback',   1);
		$this->loader->add_action( 'wp_ajax_bulk-update-commission-product',	$bulk_update_product, 'update_commission', 1);
		$this->loader->add_action( 'wp_ajax_bulk-update-product-price',			$bulk_update_product, 'update_product_price',   1);

		$coupon = new Sejowoo\JSON\Coupon();

		$this->loader->add_action( 'wp_ajax_sejowoo-update-affiliate-coupons',		$coupon, 'update_affiliate_coupons', 	1);
		$this->loader->add_action( 'sejowoo-ajax/render-affiliate-coupon-table',	$coupon, 'set_data_for_table',			1);
		$this->loader->add_action( 'sejowoo-ajax/create-affiliate-coupon',			$coupon, 'create_affiliate_coupon', 	1);
		$this->loader->add_action( 'sejowoo-ajax/get-parent-coupon-list',			$coupon, 'set_for_parent_options',		1);
		$this->loader->add_action( 'sejowoo-ajax/get-available-coupon-list',		$coupon, 'set_for_affiliate_options',	1);

		$leaderboard = new Sejowoo\JSON\Leaderboard();

		$this->loader->add_action( 'sejowoo-ajax/get-table-list',				$leaderboard, 'set_for_table', 1);

		$product = new Sejowoo\JSON\Product();

		$this->loader->add_action( 'sejowoo-ajax/get-product-list', 			$product, 'set_for_options', 1);

		$request_fund = new Sejowoo\JSON\RequestFund();

		$this->loader->add_action( 'wp_ajax_sejowoo-request-fund-table',		$request_fund, 'set_data_for_table',1);
		$this->loader->add_action( 'wp_ajax_sejowoo-get-request-fund-detail',	$request_fund, 'get_detail',		1);
		$this->loader->add_action( 'wp_ajax_sejowoo-update-request-fund',		$request_fund, 'update_status', 	1);
		$this->loader->add_action( 'sejowoo-ajax/submit-request-fund',			$request_fund, 'submit_request',	1);

		$user  = new Sejowoo\JSON\User();

		$this->loader->add_action( 'wp_ajax_sejowoo-user-options',			$user, 'set_for_options',		1);
		$this->loader->add_action( 'wp_ajax_sejowoo-user-table',			$user, 'set_for_table',			1);
		$this->loader->add_action( 'wp_ajax_sejowoo-user-update',			$user, 'update_user',			1);
		$this->loader->add_action( 'wp_ajax_sejowoo-user-export-prepare',	$user, 'prepare_for_exporting',	1);

		$order = new Sejowoo\JSON\Order();

		$this->loader->add_action( 'sejowoo-ajax/get-order-list',			$order, 'set_for_table', 1);

		$wallet = new Sejowoo\JSON\Wallet();

		$this->loader->add_action( 'wp_ajax_sejowoo-wallet-table',				$wallet, 'set_data_for_table',				1);
		$this->loader->add_action( 'wp_ajax_sejowoo-wallet-export-csv',			$wallet, 'create_csv_file',					1);
		$this->loader->add_action( 'wp_ajax_sejowoo-single-wallet-export-csv',	$wallet, 'create_csv_file_for_single',		1);
		$this->loader->add_action( 'wp_ajax_sejowoo-single-wallet-table',		$wallet, 'set_data_for_single_user_table',  1);
		$this->loader->add_action( 'sejowoo-ajax/get-wallet-list',				$wallet, 'set_data_for_single_user_table',	1);

	}

	/**
	 * Run the loader to execute all of the hooks with WordPress.
	 *
	 * @since    1.0.0
	 */
	public function run() {
		$this->loader->run();
	}

	/**
	 * The name of the plugin used to uniquely identify it within the context of
	 * WordPress and to define internationalization functionality.
	 *
	 * @since     1.0.0
	 * @return    string    The name of the plugin.
	 */
	public function get_plugin_name() {
		return $this->plugin_name;
	}

	/**
	 * The reference to the class that orchestrates the hooks with the plugin.
	 *
	 * @since     1.0.0
	 * @return    Sejowoo_Loader    Orchestrates the hooks of the plugin.
	 */
	public function get_loader() {
		return $this->loader;
	}

	/**
	 * Retrieve the version number of the plugin.
	 *
	 * @since     1.0.0
	 * @return    string    The version number of the plugin.
	 */
	public function get_version() {
		return $this->version;
	}

}
