<?php

namespace Sejowoo\Model;

/**
 * Since 0.1.0
 * Commission model data
 */
class Commission extends \WC_Data {

    /**
     * Default property values
     * @since   0.1.0
     * @var     array
     */
    protected $data = array(
        'created_at'    => NULL,
        'updated_at'    => NULL,
        'deleted_at'    => NULL,
        'order_id'      => 0,
        'item_id'       => 0,
        'product_id'    => 0,
        'affiliate_id'  => 0,
        'tier'          => 0,
        'commission'    => 0.0,
        'order_status'  => NULL,
        'paid_status'   => 0
    );

    /**
     * Affiliate constructor. Load affiliate data
     * @since   0.1.0
     * @param   mixed   $data   Sejowoo\Model\Affiliate, object or ID
     */
    public function __construct( $data = '' ) {

        parent::__construct( $data );

        if( $data instanceof \Sejowoo\Model\Affiliate ) :

            $this->set_id( absint( $data->get_id() ) );

        elseif( is_numeric( $data ) ) :

            $this->set_id( $data );

        else :

            $this->set_object_read( true );

        endif;
    }
}
