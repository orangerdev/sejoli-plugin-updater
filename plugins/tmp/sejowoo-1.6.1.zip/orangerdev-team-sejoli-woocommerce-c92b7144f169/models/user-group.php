<?php

namespace Sejowoo\Model;

/**
 * Since 0.1.0
 * Affiliate model data
 */
class UserGroup extends \WC_Data {

    /**
     * Default property values
     * @since   0.1.0
     * @var     array
     */
    protected $data = array(
        'id'           => 0,
        'name'         => NULL,
        'commissions'  => NULL,
        'per_products' => array(),
        'cashback'     => 0,
        'discount'     => 0,
        'priority'     => 0,
        'affiliate'    => 0
    );

    /**
     * Affiliate constructor. Load affiliate data
     * @since   0.1.0
     * @param   mixed   $data   Sejowoo\Model\Affiliate, object or ID
     */
    public function __construct( $data = '' ) {

        parent::__construct( $data );

        if( $data instanceof \Sejowoo\Model\UserGroup ) :

            $this->set_id( absint( $data->get_id() ) );

        elseif( is_numeric( $data ) ) :

            $this->set_id( $data );

        else :

            $this->set_object_read( true );

        endif;
    }
}
