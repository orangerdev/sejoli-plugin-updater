<?php
/**
 * Silence is golden.
 *
 * @package Woongkir
 */

// phpcs:disable
