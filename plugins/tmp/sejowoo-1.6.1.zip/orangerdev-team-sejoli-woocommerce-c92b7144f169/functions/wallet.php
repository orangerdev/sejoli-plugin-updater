<?php
/**
 * Add custom single wallet value
 * @since   1.0.0
 * @param   array $args
 */
function sejowoo_add_wallet_value(array $args) {

    $args = wp_parse_args($args, array(
        'order_id'    => 0,
        'item_id'     => 0,
        'user_id'     => get_current_user_id(),
        'meta_id'     => 0,
        'product_id'  => 0,
        'refundable'  => false,
        'valid_point' => false,
        'value'       => 0.0,
        'type'        => 'out',
        'label'       => 'wallet-use',
    ));

    $return      = array();
    $wallet_data = sejowoo_check_wallet_data( $args );
    $error       = new WP_Error();

    if(
        is_wp_error($wallet_data) &&
        'unable-get-wallet-detail' === $wallet_data->get_error_code()
    ):

        $respond = sejowoo_db('wallet')->set_data($args)
                        ->add()
                        ->respond();

        if( false !== $respond['valid'] ) :

            return $respond['wallet'];

        else :

            foreach( (array) $respond['messages']['error'] as $message ) :
                $error->add( $respond['error'], $message);
            endforeach;

        endif;

    else :
        $error->add(
            'unable-add-wallet',
            __('Unable to add wallet', 'sejowoo'),
            $args
        );

    endif;

    if( 0 < count($return) ) :
        return $return;
    endif;

    return $error;
}

/**
 * Check wallet data based on arguments
 * @since   1.0.0
 * @param   array           $args
 * @return  WP_Error|object
 */
function sejowoo_check_wallet_data( array $args ) {

    global $sejowoo;

    $respond = $sejowoo['db']->wallet::reset()
                ->set_data($args)
                ->get_detail()
                ->respond();

    if( false !== $respond['valid'] ) :
        return $respond['wallet'];
    else :
        return sejowoo_set_wp_error( $respond, 'unable-get-wallet-detail' );
    endif;
}

/**
 * Get available all user wallet data
 * @since   1.0.0
 * @param   array  $args
 * @return  array
 */
function sejowoo_get_all_user_wallet($args = array()) {

    $args = wp_parse_args($args, array(
                'user_id' => NULL
            ));

    $response    = sejowoo_db('wallet')->set_filter_from_array($args)
                    ->get_all_user_wallet()
                    ->respond();

    if( false !== $response['valid'] ) :

        return $response['wallet'];

    else :

        $error = sejowoo_set_error_response( $respond );

    endif;
}

/**
 * Get wallet history
 * @since   1.0.0
 * @param   array  $args
 * @param   array  $table
 * @return  array
 */
function sejowoo_wallet_get_history(array $args, $table = array()) {

    global $sejowoo;

    $args = wp_parse_args($args,[
        'user_id'     => NULL,
        'product_id'  => NULL,
        'type'        => NULL,
        'valid_point' => true
    ]);

    $table = wp_parse_args($table, [
        'start'   => NULL,
        'length'  => NULL,
        'order'   => NULL,
        'filter'  => NULL
    ]);

    if(isset($args['date-range']) && !empty($args['date-range'])) :
        $table['filter']['date-range'] = $args['date-range'];
        unset($args['date-range']);
    endif;

    $query = sejowoo_db('wallet')->set_filter_from_array($args)
                ->set_data_start($table['start']);

    if(isset($table['filter']['date-range']) && !empty($table['filter']['date-range'])) :
        list($start, $end) = explode(' - ', $table['filter']['date-range']);
        $query = $query->set_filter('created_at', $start , '>=')
                    ->set_filter('created_at', $end, '<=');
    endif;

    if(0 < $table['length']) :
        $query->set_data_length($table['length']);
    endif;

    if(!is_null($table['order']) && is_array($table['order'])) :
        foreach($table['order'] as $order) :
            $query->set_data_order($order['column'], $order['sort']);
        endforeach;
    endif;

    $response = $query->get()->respond();

    foreach( (array) $response['wallet'] as $i => $point) :
        $response['wallet'][$i]->meta_data = maybe_unserialize($point->meta_data);
    endforeach;

    return wp_parse_args($response,[
        'valid'    => false,
        'wallet'   => NULL,
        'messages' => []
    ]);
}

/**
 * Update wallet point valid status
 * @since   1.0.0
 * @param   integer     $order
 * @param   boolean     $status
 * @param   string      $label
 * @return  true|WP_Error
 */
function sejowoo_update_wallet_point_valid_status( $order_id, bool $status, $label ) {

    global $sejowoo;

    $respond = sejowoo_db('wallet')
                ->set_data(array(
                    'order_id'    => $order_id,
                    'valid_point' => $status,
                    'label'       => $label,
                ))
                ->update_valid_point()
                ->respond();

    if( false !== $respond['valid'] ) :
        return true;
    else :
        return sejowoo_set_wp_error( $respond, 'unable-update-valid-point-wallet' );
    endif;
}

/**
 * Update wallet point valid status by meta
 * @since   1.0.0
 * @param   integer     $meta_id
 * @param   boolean     $status
 * @param   string      $label
 * @return  true|WP_Error
 */
function sejowoo_update_wallet_point_valid_status_by_meta( $meta_id, bool $status, $label ) {

    global $sejowoo;

    $respond = sejowoo_db('wallet')
                ->set_data(array(
                    'meta_id'    => $meta_id,
                    'valid_point' => $status,
                    'label'       => $label,
                ))
                ->update_valid_point_by_meta()
                ->respond();

    if( false !== $respond['valid'] ) :
        return true;
    else :
        return sejowoo_set_wp_error( $respond, 'unable-update-valid-point-wallet' );
    endif;
}

/**
 * Get available user wallet data
 * @since   1.0.0
 * @since   1.1.1           Fix wrong available_cash calculation
 * @param   integer         $user_id
 * @return  array|false
 */
function sejowoo_get_single_user_wallet( $user_id = 0 ) {

    global $sejowoo;

    $user_id = ( 0 === intval($user_id) ) ? get_current_user_id() : $user_id;

    $respond = sejowoo_db('wallet')
                ->set_data(array(
                    'user_id'    => $user_id,
                ))
                ->get_user_wallet()
                ->respond();

    if( false !== $respond['valid'] ) :

        $respond['wallet']->available_cash = $respond['wallet']->cash_value - $respond['wallet']->used_value;

        $respond['wallet']->available_cash = ( 0 > floatval($respond['wallet']->available_cash) ) ?
                                                0 :
                                                $respond['wallet']->available_cash;

        $respond['wallet']->available_total = ( 0 > floatval($respond['wallet']->available_total) ) ?
                                                0 :
                                                $respond['wallet']->available_total;

        return (array) $respond['wallet'];
    endif;

    return false;
}
