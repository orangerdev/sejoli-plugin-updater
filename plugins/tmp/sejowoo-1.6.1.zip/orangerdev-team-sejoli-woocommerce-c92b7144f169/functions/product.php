<?php
/**
 * Get multiple products by id
 * @since   1.0.0
 * @param   array  $multiple_product_ids [description]
 * @return  array
 */
function sejowoo_get_products( array $multiple_product_ids ) {

    $product_data = [];

    $products = get_posts([
        'posts_per_page' => count( $multiple_product_ids ),
        'post_type'      => 'product',
        'include'        => $multiple_product_ids
    ]);

    foreach( (array) $products as $product ) :

        $product_data[ $product->ID ] = $product;

    endforeach;

    return $product_data;
}

/**
 * Get product data as array for select options
 * @since   1.0.0
 * @since   1.1.3   Enable product variation in return data
 * @return  array
 */
function sejowoo_get_product_options() {

    global $sejowoo;

    if(
        !isset($sejowoo['user-group-options']) ||
        0 === count($sejowoo['user-group-options'])
    ) :

        $product_data = [];

        $products = \SejoWoo\Database\Post::set_args([
                        'orderby'        => 'title',
                        'order'          => 'ASC',
                        'status'         => 'publish',
                        'post_type'      => array('product', 'product_variation')
                    ])
                    ->set_total( 1000 )
                    ->get();

        foreach($products as $product) :

            $product_data[$product->ID] = sprintf('%s (#%s)', $product->post_title, $product->ID);

        endforeach;

        $sejowoo['user-group-options'] = $product_data;

    else :
        $product_data = $sejowoo['user-group-options'];
    endif;

    return $product_data;
}

/**
 * Get product detail
 * Add parameter $renew to get fresh product data, not from global
 * @since   1.0.0
 * @since   1.6.0   Add conditional to accept if product is variation or no
 * @param   int     $product_id
 * @param   boolean $renew          Set true if not get the product data from global
 * @return  mixed
 */
function sejowoo_get_product(int $product_id, $renew = false) {

    global $sejowoo;

    if(!isset($sejowoo['products'][$product_id]) || $renew) :

        $product = get_post($product_id);

        if(is_a($product, 'WP_Post') && in_array($product->post_type, ["product", "product_variation"])) :

            $product = apply_filters('sejowoo/product/meta-data', $product, $product->ID);
            $sejowoo['products'][$product->ID] = $product;
            return $product;

        endif;

    else :
        return $sejowoo['products'][$product_id];
    endif;

    return new WP_Error('broke', __('Not valid product ID', 'sejowoo'));

}

/**
 * Get product category data as array for select options
 * @since   1.1.2
 * @return  array
 */
function sejowoo_get_product_category_options() {

    $options = array();
    $terms   = get_terms('product_cat', array(
                    'hide_empty' => false
               ));

    foreach( $terms as $term ) :
        $options[ $term->term_id ] = $term->name;
    endforeach;

    return $options;
}
