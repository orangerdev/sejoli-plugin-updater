<?php

!defined('ABSPATH') ? exit : true;

/**
 * Add request fund data
 * @since 1.0.0
 * @param array     $args
 */
function sejowoo_add_request_fund_data( array $args ) {

    global $sejowoo;


    $args  = wp_parse_args( $args, array(
                'user_id'   => NULL,
                'amount'    => 0,
                'meta_data' => array()
            ));

    $respond = $sejowoo['db']->request_fund::reset()
                ->set_data($args)
                ->add()
                ->respond();

    if( false !== $respond['valid'] ) :

        return $respond['request'];

    else :

        $error = new WP_Error( 'unable-add-request-fund' );

        foreach( (array) $respond['messages']['error'] as $message ) :
            $error->add( $respond['error'], $message);
        endforeach;

        return $error;
    endif;

}

/**
 * Get single request fund data by ID
 * @since   1.0.0
 * @param   integer         $id
 * @return  array|WP_Error
 */
function sejowoo_get_single_request_fund( $id ) {

    $respond = sejowoo_db('request_fund')->set_data(array('ID' => $id))
                ->single()
                ->respond();

    if( false !== $respond['valid'] ) :

        $request_data              = (array) $respond['request_data'];
        $request_data['meta_data'] = maybe_unserialize( $request_data['meta_data'] );

        $user = new \WC_Customer( $request_data['user_id'] );

        $request_data['user_name']  = $user->get_display_name();
        $request_data['user_phone'] = $user->get_billing_phone();
        $request_data['user_email'] = $user->get_email();

        if ( 0 === intval( $request_data['admin_id'] ) ) :
            $request_data['admin']      = NULL;
            $request_data['updated_at'] = NULL;
        else :
            $request_data['admin']        = get_user_by( 'id', $request_data['admin_id'] )->display_name;
            $request_data['updated_date'] = date('Y F d', strtotime( $request_data['updated_at']) );
        endif;

        $request_data['created_date'] = date('Y F d', strtotime( $request_data['created_at']) );
        $request_data['amount']       = wc_price( $request_data['amount'] );

        $request_data['meta_data']    = wp_parse_args( $request_data['meta_data'], array(
                                            'proof' => NULL,
                                            'note'  => NULL
                                        ));


        return $request_data;

    else :

        return sejowoo_set_wp_error( $respond, 'invalid-data' );

    endif;

}

/**
 * Get request fund data for datatable
 * @since   1.0.0
 * @param   array  $args
 * @param   array  $table
 * @return  array
 */
function sejowoo_get_request_fund_data(array $args, $table = array()) {

    global $sejowoo;

    $args = wp_parse_args($args,[
        'user_id'  => NULL,
        'admin_id' => NULL,
        'status'   => NULL
    ]);

    $table = wp_parse_args($table, [
        'start'   => NULL,
        'length'  => NULL,
        'order'   => NULL,
        'filter'  => NULL
    ]);

    if(isset($args['date-range']) && !empty($args['date-range'])) :
        $table['filter']['date-range'] = $args['date-range'];
        unset($args['date-range']);
    endif;

    $query = sejowoo_db('request_fund')->set_filter_from_array($args)
                ->set_data_start($table['start']);

    if(isset($table['filter']['date-range']) && !empty($table['filter']['date-range'])) :
        list($start, $end) = explode(' - ', $table['filter']['date-range']);
        $query = $query->set_filter('created_at', $start , '>=')
                    ->set_filter('created_at', $end, '<=');
    endif;

    if(0 < $table['length']) :
        $query->set_data_length($table['length']);
    endif;

    if(!is_null($table['order']) && is_array($table['order'])) :
        foreach($table['order'] as $order) :
            $query->set_data_order($order['column'], $order['sort']);
        endforeach;
    endif;

    $response = $query->get()->respond();

    foreach( (array) $response['request_funds'] as $i => $point) :
        $response['request_funds'][$i]->meta_data = maybe_unserialize($point->meta_data);
    endforeach;

    return wp_parse_args($response,[
        'valid'         => false,
        'request_funds' => NULL,
        'messages'      => []
    ]);
}

/**
 * Update request fund status
 * @since   1.0.0
 * @param   array  $args [description]
 * @return  true|WP_Error
 */
function sejowoo_update_request_fund_status( array $args ) {

    $args = wp_parse_args( $args, array(
        'ID'        => NULL,
        'status'    => 'rejected',
        'admin_id'  => NULL,
        'meta_data' => array()
    ));

    if('approved' === $args['status'] ) :

        $respond = sejowoo_db('request_fund')->set_data($args)
                        ->approve()
                        ->respond();

    else :

        $respond = sejowoo_db('request_fund')->set_data($args)
                        ->reject()
                        ->respond();

    endif;

    if( false !== $respond['valid'] ) :
        return true;
    else :
        return sejowoo_set_wp_error( $respond, 'invalid-update-request-data-status' );
    endif;

}
