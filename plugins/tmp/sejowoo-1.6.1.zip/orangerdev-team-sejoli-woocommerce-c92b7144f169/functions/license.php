<?php

/**
 * [sejowoo_check_own_license description]
 * @return boolean
 */
function sejowoo_check_own_license() {

    global $sejowoo;

    return boolval($sejowoo['license']['valid']);
}
