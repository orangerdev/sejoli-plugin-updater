<?php

/**
 * Check if current request is via AJAX
 * @since   1.0.0
 * @return  boolean
 */
function sejowoo_is_ajax_request() {

    $valid = false;

    if ( !empty( $_SERVER['HTTP_X_REQUESTED_WITH'] ) &&
        strtolower( $_SERVER['HTTP_X_REQUESTED_WITH'] ) === 'xmlhttprequest' ) :

        $valid = true;

    endif;

    return $valid;

}

/**
 * Check if WooCommerce is active
 * To call this function, make sure to embed into hook after plugins_loaded with priority more than 1
 * @since   1.0.0
 * @return  boolean
 */
function sejowoo_is_woocommerce_active() {

    global $sejowoo;

    return boolval( $sejowoo['active'] );
}

/**
 * Set error respond with WP_Error
 * @since   1.0.0
 * @param   array $respond
 * @return  WP_Error
 */
function sejowoo_set_error_response( array $respond ) {

    $error = new WP_Error();

    foreach( (array) $respond['messages']['error'] as $message ) :
        $error->add( $respond['error'], $message);
    endforeach;

    return $error;
}

/**
 * Call sejowoo database class
 * @since   1.0.0
 * @param   string $db_name [description]
 * @return  \SejoWoo\Database
 */
function sejowoo_db( $db_name ) {

    global $sejowoo;

    return $sejowoo['db']->$db_name::reset();
}

/**
 * Upload file
 * @since   1.0.0
 * @param   array   $file
 * @param   string  $file_type
 * @param   string  $file_data
 * @return  WP_Error|array
 */
function sejowoo_upload_file( array $file, $file_type = 'image', $file_data = array() ) {

    try {

        $file_data = wp_parse_args($file_data, array(
                        'from'  => 'request-fund',
                        'title' => ''
                    ));

        if( 0 !== $file['error'] ) :
            throw new Exception( __('Anda belum mengupload file', 'sejowoo') );
        endif;

        if( $file['size'] > wp_max_upload_size() ) :
            throw new Exception(
                sprintf(
                    __('Besar upload yang anda upload melebihi %s Mb', 'sejowoo'),
                    intval( wp_max_upload_size() / ( 1024 * 1024 ) )
                )
            );
        endif;

        switch( $file_type ) :

            case 'image' :
                $allowed_types = array(IMAGETYPE_PNG, IMAGETYPE_JPEG, IMAGETYPE_GIF);
                $detected_type = exif_imagetype($file['tmp_name']);

                if( !in_array($detected_type, $allowed_types) ):
                    throw new Exception( __('File yang anda upload tidak diizinkan. Harus berupa image', 'sejowoo') );
                endif;

                break;

        endswitch;

        $attachments = [];

        if ( ! function_exists( 'wp_handle_upload' ) ) :
            require_once( ABSPATH . 'wp-admin/includes/file.php' );
        endif;

        $upload_overrides = array( 'test_form' => false );

        $movefile = wp_handle_upload( $file, $upload_overrides );

        if ( $movefile && ! isset( $movefile['error'] ) ) :

            $attachments[] = $movefile['file'];

            $filename    = basename( $movefile['file'] );
            $wp_filetype = wp_check_filetype($filename, null );
            $filename    = ( empty($file_data['title'] ) ) ? $filename : $file_data['title'] ;

            $attachment  = array(
                'post_mime_type' => $wp_filetype['type'],
                'post_title'     => preg_replace('/\.[^.]+$/', '', $filename),
                'post_content'   => '',
                'post_status'    => 'inherit',
                'post_author'    => get_current_user_id(),
                'author'         => get_current_user_id()
            );

            $attachment_id    = wp_insert_attachment( $attachment, $movefile['file'] );
            $attachment['ID'] = $attachment_id;

            if ( ! is_wp_error($attachment_id) ) :

                require_once(ABSPATH . "wp-admin" . '/includes/image.php');

                $attachment_data = wp_generate_attachment_metadata( $attachment_id, $movefile['file'] );

                wp_update_attachment_metadata( $attachment_id,  $attachment_data );

                update_post_meta( $attachment_id, 'file_from', $file_data['from'] );

            endif;

            return array(
                'post_data' => $attachment,
                'file'      => $movefile
            );

        endif;

    } catch( Exception $e ) {
        return new WP_Error( 'error-upload', $e->getMessage() );
    }

}

/**
 * Set error message based on model respond
 * @since   1.0.0
 * @param   array  $respond
 * @param   string $error_code
 * @return  WP_Error
 */
function sejowoo_set_wp_error( array $respond, $error_code ) {

    $error = new WP_Error( $error_code );

    if( isset($respond['messages']) && isset($respond['messages']['error']) ) :
        foreach( (array) $respond['messages']['error'] as $message ) :
            $error->add( $respond['error'], $message);
        endforeach;
    endif;

    return $error;
}

/**
 * Get label color
 * @since   1.0.0
 * @return  array
 */
function sejowoo_get_label_color( $label ) {

    $colors = array(
        'completed'       => '#27ae60',
        'paid'            => '#27ae60',
        'shipping'        => '#16a085',
        'in-progress'     => '#2980b9',
        'on-hold'         => '#7f8c8d',
        'cancelled'       => '#d35400',
        'refunded'        => '#c0392b',
        'pending'         => '#7f8c8d',
        'added'           => '#2980b9',
        'inactive'        => '#c0392b',
        'active'          => '#2ecc71',
        'expired'         => '#c0392b'
    );

    if( array_key_exists( $label, $colors ) ) :
        return $colors[$label];
    endif;

    return sejowoo_get_hex_from_text( $label );
}

/**
 * Get hex color code from text
 * @since   1.0.0
 * @param   string  $text   String value that will be converted
 * @return  string  Hex code value
 */
function sejowoo_get_hex_from_text($text) {
    $code = dechex(crc32($text));
    $code = substr($code, 0, 6);
    return '#'.$code;
}

/**
 * Get main theme setting container
 * @since   1.0.0
 * @return  Container
 */
function sejowoo_get_main_theme_options() {
    return apply_filters( 'sejowoo/general/container', NULL );
}

/**
 * Change all chars except first and last
 * @since  1.0.0
 * @param  string   $string           Given string
 * @param  string   $replace_char     Characater that will replace
 * @return string   String that has been replaced
 */
function sejowoo_get_sensored_string(string $string, $replace_char = '*') {

    $words = explode(' ', $string);

    foreach($words as $i => $word) :

        $length    = strlen($word);
        $words[$i] = substr($word, 0, 1).str_repeat('*', $length - 2).substr($word, $length - 1, 1);

    endforeach;

    return implode(' ', $words);
}

/**
 * Set debug log to query monitor
 * @since   1.1.2
 */
function sejowoo_set_debug_log( ) {

    $debug_enable = boolval( carbon_get_theme_option( 'sejowoo_debug_enable' ) );

    if( true !== $debug_enable ) :
        return;
    endif;

    $bt     = debug_backtrace();
    $caller = array_shift($bt);
    $args   = [
        "file"  => $caller["file"],
        "line"  => $caller["line"],
        "args"  => func_get_args()
    ];

    do_action('qm/info', $args);
}

/**
 * Set plugin options as global variables
 * @since   1.1.2.1
 * @return  array
 */
function sejowoo_get_plugin_setup_options() {

    global $sejowoo;

    if( !isset($sejowoo['options'] ) ) :

        $sejowoo['options'] = array(
            'hide-affiliate-network' => boolval( carbon_get_theme_option('sejowoo_member_area_hide_affiliate_network') ),
            'hide-affiliate-link'    => boolval( carbon_get_theme_option('sejowoo_member_area_hide_affiliate_link') ),
			'hide-affiliate-order'   => boolval( carbon_get_theme_option('sejowoo_member_area_hide_affiliate_order') ),
            'hide-affiliate-coupon'  => boolval( carbon_get_theme_option('sejowoo_member_area_hide_affiliate_coupon') ),
            'hide-leaderboard'       => boolval( carbon_get_theme_option('sejowoo_member_area_hide_leaderboard') ),
            'no-access-affiliate'    => boolval( carbon_get_theme_option('sejowoo_no_access_affiliate') )
        );

    endif;


    return $sejowoo['options'];
};

/**
 * Set current user options as global variables
 * @since   1.1.2.1
 * @param   integer     $user_id
 * @return  array
 */
function sejowoo_get_global_current_user_options( $user_id = 0) {

    global $sejowoo;

    if( !isset($sejowoo['current-user'] ) ) :

        $user_id = ( 0 === $user_id ) ? get_current_user_id() : $user_id;

        $sejowoo['current-user'] = array(
            'user-group'         => absint( carbon_get_user_meta( $user_id, 'user_group') ),
            'can-view-affiliate' => boolval( carbon_get_user_meta( $user_id, 'user_group') ),
        );

    endif;

    return $sejowoo['current-user'];

}

/**
 * Set user global options as global variabels
 * @since   1.1.2.1
 * @param   integer $group_id
 * @return  array
 */
function sejowoo_get_global_user_group_options( $group_id = 0 ) {

    global $sejowoo;

    if( !isset($sejowoo['user-group'] ) ) :

        $sejowoo['user-group'] = array(
            'can-view-affiliate' => boolval( carbon_get_post_meta( $group_id, 'can_view_affiliate') ),
        );

    endif;

    return $sejowoo['user-group'];

}

/**
 * Check if valid endpoint url, enhance is_wc_endpoint_url
 * @since   1.2.1
 * @param   string  $endpoint
 * @return  boolean
 */
function sejowoo_check_endpoint_url( $endpoint ) {

    if(
        function_exists('is_wc_endpoint_url') &&
        is_wc_endpoint_url( $endpoint )
    ) :
        return true;
    else :

        global $wp;
        
        if(
            property_exists($wp, 'query_vars') &&
            is_array( $wp->query_vars ) &&
            array_key_exists( $endpoint, $wp->query_vars )
        ) :
            return true;
        endif;

    endif;

    return false;
}
