<?php
/**
 * All routine functions for affiliate
 */

 /**
  * Get cookie name
  * @since   1.0.0
  * @return  string
  */
 function sejowoo_get_cookie_name() {
     $tokens           = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
     $auth_key         = AUTH_KEY;
     $secure_auth_key  = SECURE_AUTH_KEY;
     $logged_in_key    = LOGGED_IN_KEY;
     $nonce_key        = NONCE_KEY;
     $auth_salt        = AUTH_SALT;
     $secure_auth_salt = SECURE_AUTH_SALT;
     $logged_in_salt   = LOGGED_IN_SALT;
     $nonce_salt       = NONCE_SALT;

     $i = [
         0 => absint(ord(strtolower($auth_key[0])) - 48),
         1 => absint(ord(strtolower($secure_auth_key[0])) - 96),
         2 => absint(ord(strtolower($logged_in_key[0])) - 96),
         3 => absint(ord(strtolower($nonce_key[0])) - 48),
         4 => absint(ord(strtolower($auth_salt[0])) - 96),
         5 => absint(ord(strtolower($secure_auth_salt[0])) - 96),
         6 => absint(ord(strtolower($logged_in_salt[0])) - 48),
         7 => absint(ord(strtolower($nonce_salt[0])) - 96),
     ];

     $key = '';

     foreach($i as $_i) :
         $key .= $tokens[$_i];
     endforeach;

     return 'SEJOWOO-'.$key;
 }

 /**
  * Get cookie value
  * @since   1.0.0
  * @return  array
  */
 function sejowoo_get_affiliate_cookie() {

     $data        = [];
     $cookie_name = sejowoo_get_cookie_name();

     if(isset($_COOKIE[$cookie_name])) :
         $data = maybe_unserialize(stripslashes($_COOKIE[$cookie_name]));
     endif;

     return $data;
 }

 /**
  * Get affiliate data by user
  * @param  WP_User|Int  $user
  * @param  string       $return     type of return, default will return the id only
  * @return mixed
  */
 function sejowoo_get_affiliate($user, $return = 'id')
 {
     global $sejolisa;

     $affiliate_id = $affiliate = NULL;
     $user_id      = get_current_user_id();

     if(is_a($user,'WP_User')) :
         $user_id = $user->ID;
     else :
         $user_id = intval($user);
     endif;

     $affiliate_id = intval( get_user_meta( $user_id, sejowoo_get_affiliate_key(), true ) );

     if(!is_null($affiliate_id) || 0 !== $affiliate_id) :

         if('id' === $return) :

             $affiliate = intval($affiliate_id);

         elseif('wp_user' === $return) :

             if(isset($sejolisa['affiliates']) && isset($sejolisa['affiliates'][$affiliate_id])) :

                 $affiliate = $sejolisa['affiliates'][$affiliate_id];

             else :

                 $sejolisa['affiliates'][$affiliate_id] = $affiliate  = get_user_by('id',$affiliate_id);

             endif;

         endif;

     endif;

     return $affiliate;
 }

/**
 * Get commission setup per product
 * @since   1.0.0
 * @param   integer|WC_Product      $product
 * @return  array|WP_Error    Return false if there is commission setup
 */
function sejowoo_get_product_commission( $product = 0 ) {

    if( $product instanceof WC_Product ) :

    elseif( is_numeric($product) ) :

        $product = wc_get_product($product);

        if(! ( $product instanceof WC_Product ) ) :

            return new WP_Error('error', __('Not valid WC_Product data', 'sejowoo'));

        endif;

    else :

        return new WP_Error('error', __('Not valid WC_Product data', 'sejowoo'));

    endif;

    /**
     * Get selected commission setup from the product meta
     */
    $commission_setup = intval( $product->get_meta('sejowoo_commission', true) );

    if($commission_setup) :

        $data        = false;
        $commissions = carbon_get_post_meta( $commission_setup, 'commission');

        foreach( (array) $commissions as $i => $commission ) :

            $tier = $i + 1;

            if( 'percentage' === $commission['type'] ) :
                $rule  = $commission['number'] . '%';
                $value = floatval($commission['number']) * $product->get_price() / 100;
            else :
                $rule  = $commission['type'];
                $value = $commission['number'];
            endif;

            $data[$tier] = array(
                'tier'  => $tier,
                'rule'  => $rule,
                'value' => $value,
            );

        endforeach;

        return $data;

    endif;

    return false;
}

/**
 * Get affiliate meta key value
 * @since   1.0.0
 * @return  string
 */
function sejowoo_get_affiliate_key() {
    return '_affiliate_id';
}

/**
 * Get user affiliate ID, there are two ways to get affiliate, from cookie or user_meta
 * @since   1.0.0
 * @param   integer         $user_id
 * @param   false|WC_Order  $order
 * @return  false|integer   Return false if user doesn't have affiliate ID
 */
function sejowoo_get_user_affiliate( $user_id = 0, $order = false) {

    $from         = '';
    $affiliate_id = 0;
    $cookie       = sejowoo_get_affiliate_cookie();

    if( isset($cookie['general']) && !empty($cookie['general']) ) :

        $from         = 'cookie';
        $affiliate_id = intval( $cookie['general'] );

    endif;

    if(
        is_user_logged_in() &&
        carbon_get_theme_option('sejowoo_permanent_affiliate')
    ) :
        $from                 = 'user-meta';
        $user_id              = ( 0 >= $user_id ) ? get_current_user_id() : $user_id;
        $current_affiliate_id = absint( get_user_meta( $user_id, sejowoo_get_affiliate_key(), true ) );
        $affiliate_id         = ( 0 === $current_affiliate_id ) ? $affiliate_id : $current_affiliate_id;

    endif;

    return apply_filters( 'sejowoo/user/affiliate', $affiliate_id, $user_id, $from, $order );
}

/**
 * Get max downline tiers
 * @since   1.0.0
 * @param   integer     $user_id
 * @return  integer
 */
function sejowoo_get_max_downline_tiers( $user_id = 0 ) {

    $max_tiers = absint( carbon_get_theme_option( 'sejowoo_affiliate_network_limit' ) );

    $user_id       = ( empty($user_id) ) ? get_current_user_id() : $user_id;
    $user_group_id = sejowoo_get_current_user_group( $user_id );

    if( !empty( $user_group_id) ) :
        $max_tiers = absint( carbon_get_post_meta( $user_group_id, 'affiliate_network_limit') );
    endif;


    return ( 0 >= $max_tiers ) ? 1 : $max_tiers;
}

/**
 * Generate affiliate link
 * @since   1.0.0
 * @param   string  $target
 * @param   integer $affiliate_id
 * @return  string
 */
function sejowoo_generate_affiliate_link( $target = '', $affiliate_id = 0) {

    $affiliate_id = ( 0 === $affiliate_id ) ? get_current_user_id() : $affiliate_id;
    $url          = home_url("aff/{$affiliate_id}");

    if( !empty($target) ) :
        $url .= '/' . $target;
    endif;

    return $url;
}

/**
 * Get all available affiliate links
 * @since   1.0.0
 * @return  array
 */
function sejowoo_get_all_affiliate_links() {

    $args = array(
        'post_status'            => 'publish',
        'post_type'              => SEJOWOO_AFFILIATE_CPT,
        'posts_per_page'         => -1,
        'no_found_rows'          => true,
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false
    );

    $query = new WP_Query($args);

    return $query->posts;
}

/**
 * Check if current user can be an affiliate
 * @since   1.0.1
 * @param   integer     $user_id
 * @return  boolean
 */
function sejowoo_user_can_affiliate( $user_id = 0) {

    global $sejowoo;

    // if( !isset($sejowoo['user-can-affiliate'] ) ) :

        $can_access = false;

        if( function_exists('carbon_get_theme_option') ) :

            $user_id = ( 0 === $user_id ) ? get_current_user_id() : $user_id;

            $can_access = ! boolval( sejowoo_get_plugin_setup_options()['no-access-affiliate'] );

            if( false !== ( $user_group_id = sejowoo_get_current_user_group( $user_id ) ) ):
                $can_access = boolval( sejowoo_get_global_user_group_options( $user_group_id )['can-view-affiliate'] );
            endif;

        endif;

        $sejowoo['user-can-affiliate'] = $can_access;

    // else :

    //     $can_access = boolval($sejowoo['user-can-affiliate']);

    // endif;


    return $can_access;

}
