<?php
/**
 * Get user group upgrade options
 * @since   1.0.0
 * @return  array
 */
function sejowoo_get_user_group_upgrade_options() {

    $options = array(
		'first'   => array(),
		'upgrade' => array()
    );

    $user_group_settings = sejowoo_get_user_group_settings();

    if( false !== $user_group_settings ) :
        return wp_parse_args( $user_group_settings, $options );
    endif;

    return $options;
}

/**
 * Check if currenct user is needed to be upgraded based on order total
 * @since   1.3.0
 * @param   int          $user_group_id      Current user group ID
 * @param   float        $order_total        Total order value
 * @param   boolean      $is_first_buy       Set if current order is first buy
 * @return  false|array                      Return false if the user is not needed to be upgrader, array with upgrade data
 * Return array with values :
 * - group_id   Inform with group_id that user will be updated
 * - priority
 * - value
 * - action
 */
function sejowoo_check_update_user_group_by_order_total( int $user_group_id, float $order_total, $is_first_buy = false ) {

    $user_group_id = intval( $user_group_id );
    $setting       = sejowoo_get_user_group_upgrade_options();

    $upgrade_data  = array(
        'group_id'  => 0,
        'priority'  => ( isset($setting['first'][$user_group_id] ) ) ?
                            intval( $setting['first'][$user_group_id]['priority'] ) :
                            999999999,
        'value'     => 0
    );

    // Current order is not first buy
    if(
        false === $is_first_buy &&
        0 < count($setting['upgrade'])
    ) :

        $action = 'upgrade';

        // User doesnt have user group
        if( 0 === $user_group_id ) :

            $upgrade_data['value'] = $order_total;

            foreach( $setting['upgrade']['repeat'] as $target_group_id => $_setting ) :

                if(
                    $upgrade_data['value'] >= $_setting['value'] &&
                    $upgrade_data['priority'] > $_setting['priority']
                ) :
                    $upgrade_data['group_id'] = $target_group_id;
                    $upgrade_data['value']    = $_setting['value'];
                    $upgrade_data['priority'] = $_setting['priority'];
                endif;

            endforeach;

        else :

            // Compare current user group id with current user

            foreach( $setting['upgrade']['groups'] as $target_group_id => $compare_groups ) :

                $target_group_priority = intval( $setting['first'][$target_group_id]['priority'] );

                foreach( (array) $compare_groups as $compare_group_id => $_setting ) :

                    $setting_value  = floatval( $_setting['value'] );

                    if(
                        $setting_value < $order_total &&
                        intval($compare_group_id) === $user_group_id &&
                        $upgrade_data['value'] < $setting_value &&
                        $target_group_priority < $upgrade_data['priority']
                    ) :

                        $upgrade_data['group_id'] = $target_group_id;
                        $upgrade_data['value']    = $setting_value;
                        $upgrade_data['priority'] = $target_group_priority;

                    endif;

                endforeach;

            endforeach;

        endif;

    // Check if current buy is first buy
    else :

        $action = 'first-buy';

        foreach( $setting['first'] as $target_group_id => $_setting ) :

            $target_group_priority = intval( $_setting['priority'] );
            $target_group_value    = floatval( $_setting['value'] );

            $updated = false;

            if(
                $target_group_value < $order_total &&
                intval($target_group_id) !== $user_group_id &&
                $upgrade_data['value'] <= $target_group_value &&
                $target_group_priority < $upgrade_data['priority']
            ) :

                $upgrade_data['group_id'] = $target_group_id;
                $upgrade_data['value']    = $target_group_value;
                $upgrade_data['priority'] = $target_group_priority;

                $updated = true;

            endif;

            // __debug(
            //     array(
            //         'compare value',
            //         $target_group_value,
            //         $order_total,
            //         ( $target_group_value < $order_total )
            //     ),
            //     array(
            //         'do not compare with same group id',
            //         $target_group_id,
            //         $user_group_id,
            //         ( intval($target_group_id) !== $user_group_id )
            //     ),
            //     array(
            //         'compare value with previous value',
            //         $upgrade_data['value'],
            //         $target_group_value,
            //         ( $upgrade_data['value'] <= $target_group_value )
            //     ),
            //     array(
            //         'compare priority',
            //         $target_group_priority,
            //         $upgrade_data['priority'],
            //         $target_group_priority < $upgrade_data['priority']
            //     ),
            //     $updated
            // );


        endforeach;

    endif;

    if( 0 === $upgrade_data['group_id'] ) :
        return false;
    endif;

    $upgrade_data['action'] = $action;

    return $upgrade_data;

}

/**
 * Check if current user is able to updated to product user group
 * @since   1.0.0
 * @param   integer|WP_Post  $product
 * @param   integer          $user_id
 * @return  array
 */
function sejowoo_check_update_user_group_by_product($product, $user_id = 0) {

    $update         = false;
    $disallowed     = NULL;
    $error          = new WP_Error();
    $user_id        = (0 === $user_id) ? get_current_user_id() : $user_id;
    $user           = sejowoo_get_user($user_id);
    $product        = (is_a($product, 'WP_Post')) ? $product : sejowoo_get_product($product);
    $group_options  = sejowoo_get_user_group_options();
    $group_priority = sejowoo_get_user_group_priority();

    if( false !== $product->group['update_group'] ) :

        if(
            property_exists($user->meta, 'group_id') &&
            !empty($user->meta->group_id) &&

            false !== $product->group['update_group_condition'] &&
            !in_array($user->meta->group_id, $product->group['update_group_list'])
        ) :

            $update = false;
            $disallowed = array(
                'type'          => 'not-in-group',
                'product_group' => $product->group['update_group_list'],
                'user_group'    => $user->meta->group_id
            );

            $error->add(
                'disallowed',
                sprintf(
                    __('Product group id %s, user group id %s', 'sejowoo'),
                    implode(',', $product->group['update_group_list']),
                    $user->meta->group_id
                ),
                array(
                    "updatable-group" => $product->group['update_group_list'],
                    "current-user-group" => $user->meta->group_id,
                )
            );

        else :

            $update = true;

        endif;
    endif;

    return array(
        'update'    => $update,
        'group'     => $product->group['update_group_to'],
        'error'     => array(
            'type'    => $disallowed,
            'message' => $error->get_error_messages()
        )
    );
}

/**
 * Get current user group ID
 * @since   1.0.0
 * @param   integer         $user_id
 * @return  false|array
 */
function sejowoo_get_current_user_group($user_id = 0) {

    $user_id       = ( 0 === $user_id ) ? get_current_user_id() : $user_id;
    $user_group_id = intval(carbon_get_user_meta($user_id, 'user_group'));

    if( 0 === $user_group_id ) :
        return false;
    endif;

    return $user_group_id;

}

/**
 * Get current user group data based on user ID
 * @since   1.0.0
 * @param   integer         $user_id
 * @return  false|array
 */
function sejowoo_get_current_user_group_data($user_id = 0) {

    $user_id       = ( 0 === $user_id ) ? get_current_user_id() : $user_id;
    $user_group_id = intval(carbon_get_user_meta($user_id, 'user_group'));

    if( 0 === $user_group_id ) :
        return false;
    endif;

    return sejowoo_get_user_group_data($user_group_id);
}

/**
 * Get user group data
 * @since   1.0.0
 * @param   integer         $user_group_id
 * @return  false|stdClass
 */
function sejowoo_get_user_group_data($user_group_id = 0) {

    $group = get_post($user_group_id);

    if(
        is_a($group, 'WP_Post') &&
        SEJOWOO_USER_GROUP_CPT === $group->post_type
    ) :

        $group_data = new stdClass;

        $group_data->id          = $group->ID;
        $group_data->name        = $group->post_title;
        $group_data->commissions = array();
        $group_data->per_product = array();

        $group_data->cashback = array(
            'enabled'    => boolval( carbon_get_post_meta( $group->ID, 'group_cashback_enable') ),
            'value'      => floatval( carbon_get_post_meta( $group->ID, 'group_cashback_value') ),
            'type'       => carbon_get_post_meta( $group->ID, 'group_cashback_type' ),
            'refundable' => boolval( carbon_get_post_meta( $group->ID, 'group_cashback_refundable' ) )
        );

        $group_data->discount = array(
            'enabled'   => boolval( carbon_get_post_meta( $group->ID, 'group_discount_enable') ),
            'value'     => floatval( carbon_get_post_meta( $group->ID, 'group_discount_price') ),
            'type'      => carbon_get_post_meta( $group->ID, 'group_discount_price_type' )
        );

        $commissions = carbon_get_post_meta( $group->ID, 'group_commissions' );

        foreach( (array) $commissions as $tier => $setup ) :

            $group_data->commissions[$tier] = array(
                'value' => floatval( $setup['number'] ),
                'type'  => $setup['type']
            );

        endforeach;

        $products = carbon_get_post_meta( $group->ID, 'group_setup_per_product' );

        foreach( (array) $products as $product => $setup ) :

            $configuration = array();

            $configuration['cashback'] = array(
                'enabled'    => boolval( $setup[ 'cashback_enable'] ),
                'value'      => floatval( $setup[ 'cashback_value'] ),
                'type'       => $setup[ 'cashback_type' ],
                'refundable' => boolval( $setup[ 'cashback_refundable'] )
            );

            $configuration['discount'] = array(
                'enabled'   => boolval( $setup[ 'discount_enable'] ),
                'value'     => floatval( $setup[ 'discount_price'] ),
                'type'      => $setup[ 'discount_price_type' ]
            );

            $configuration['commissions'] = array();

            $commissions = $setup[ 'commission' ];

            foreach( (array) $commissions as $tier => $commission ) :

                $configuration['commissions'][$tier] = array(
                    'value' => floatval( $commission['number'] ),
                    'type'  => $commission['type']
                );

            endforeach;

            $group_data->per_product[$setup['product']] = $configuration;

        endforeach;

        return $group_data;

    endif;

    return false;
}

/**
 * Get all user group setting
 * @since   1.0.0
 * @return  array
 */
function sejowoo_get_user_group_settings() {

    $user_groups = new \WP_Query(array(
                        'post_type'              => SEJOWOO_USER_GROUP_CPT,
                        'posts_per_page'         => 50,
                        'post_status'            => 'publish',
                        'cache_results'          => false, // do not cache the result
                        'update_post_meta_cache' => false, // do not cache the result
                        'update_post_term_cache' => false, // do not cache the result
                        'fields'                 => 'ids'
                   ));

    $setup 	= array(
        'first'   => array(),
        'upgrade' => array()
    );

    foreach( $user_groups->posts as $group_id ) :

        $enable = boolval( carbon_get_post_meta( $group_id, 'enable_user_group_upgrade'));

        if( true !== $enable ) :
            continue;
        endif;

        $priority 		 = intval( carbon_get_post_meta( $group_id, 'priority') );
        $enable_cashback = boolval( carbon_get_post_meta( $group_id, 'enable_cashback_when_upgrade' ) );
        $upgrades        = carbon_get_post_meta( $group_id, 'upgrade_user_group' );

        $setup['first'][ $group_id ] = array(
            'priority'	=> $priority,
            'cashback'	=> $enable_cashback,
            'value'		=> floatval( carbon_get_post_meta( $group_id, 'first_purchase_upgrade_min_checkout' ) )
        );


        $setup['upgrade']['repeat'][ $group_id ] = array(
            'value'    => floatval( carbon_get_post_meta( $group_id, 'next_order_purchase_upgrade_min_checkout') ),
            'priority' => $priority
        );

        $setup['upgrade']['groups'][ $group_id ] = array();

        foreach( $upgrades as $_upgrade ) :

            $setup['upgrade']['groups'][ $group_id ][ $_upgrade['user_group'] ] = array(
                'value'	=> floatval( $_upgrade['min_checkout' ]),
            );

        endforeach;

    endforeach;

    return $setup;
}

/**
 * Display user group in Edit Account Page WooCommerce
 * @since   1.0.0
 * @return  array
 */
// Add the custom field "user_group"
add_action( 'woocommerce_edit_account_form', 'add_user_group_to_edit_account_form' );
function add_user_group_to_edit_account_form() {
    $user = wp_get_current_user();

    $user_group_id = intval(carbon_get_user_meta( $user->data->ID, 'user_group' ));
    $user_group    = sejowoo_get_group_detail($user_group_id);
    ?>
        <p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
            <label for="user_group"><?php _e( 'User Group', 'sejowoo' ); ?></label>
            <input type="text" readonly class="woocommerce-Input woocommerce-Input--text input-text" name="user_group" id="user_group" value="<?php echo esc_attr( $user_group['name'] ); ?>" />
        </p>
    <?php
}
