<?php
/**
 * Calculate cashback from an order
 * @since   1.0.0
 * @param   int|WC_Order    $order
 * @return  array
 */
function sejowoo_calculate_cashback( $order ) {

    $order  = ( is_a( $order, 'WC_Order') ) ? $order : wc_get_order($order);

    $return = array(
        'total' => 0.0,
        'data'  => array()
    );

    $calculate_by = '';

    foreach( $order->get_items() as $item ) :

        $cashback_setting = apply_filters( 'sejowoo/cashback/setting', false, $item);

        if(
            false !== $cashback_setting &&
            true === $cashback_setting['enabled']
        ) :

            $product_id = ( 0 < $item->get_variation_id() ) ? $item->get_variation_id() : $item->get_product_id();

            if('fixed' === $cashback_setting['type'] ) :
                $cashback = (float) ( $item['quantity'] * $cashback_setting['value'] );
            else :
                $cashback = (float) ( ( $cashback_setting['value'] * $item['line_subtotal'] ) / 100 );
            endif;

            $return['total'] += $cashback;
            $return['data'][ $item->get_id() ] = array(
                'cashback'   => $cashback,
                'product'    => $item->get_product()->get_name(),
                'product_id' => $product_id,
                'item_id'    => $item->get_id(),
                'refundable' => $cashback_setting['refundable'], // later we need to change this
                'by'         => $calculate_by
            );

        endif;

    endforeach;

    return $return;
}

/**
 * Add cashback from an order
 * @since   1.0.0
 * @param   int|WC_Order    $order
 * @return  array|WP_Error
 */
function sejowoo_add_cashback( $order ) {

    global $sejowoo;

    $order    = ( is_a( $order, 'WC_Order') ) ? $order : wc_get_order($order);
    $cashback = sejowoo_calculate_cashback( $order );
    $return   = array();
    $error    = new WP_Error();

    foreach( (array) $cashback['data'] as $item_id => $data ) :

        $args = array(
            'order_id'    => $order->get_id(),
            'item_id'     => $item_id,
            'user_id'     => $order->get_user_id(),
            'product_id'  => $data['product_id'],
            'refundable'  => $data['refundable'],
            'valid_point' => false,
            'value'       => $data['cashback'],
            'type'        => 'in',
            'label'       => 'cashback',
        );

        $wallet_data = sejowoo_check_wallet_data( $args );

        if(
            is_wp_error($wallet_data) &&
            'unable-get-wallet-detail' === $wallet_data->get_error_code()
        ):

            $respond = $sejowoo['db']->wallet::reset()
                    ->set_data($args)
                    ->add()
                    ->respond();

            if( false !== $respond['valid'] ) :

                $wallet                = $respond['wallet'];
                $return[$wallet['ID']] = $wallet;

            else :

                foreach( (array) $respond['messages']['error'] as $message ) :
                    $error->add( $respond['error'], $message);
                endforeach;

            endif;

        else :
            $error->add(
                'unable-add-cashback',
                __('Unable to add cashback', 'sejowoo'),
                $args
            );

        endif;

    endforeach;

    if( 0 < count($return) ) :
        return $return;
    endif;

    return $error;
}

/**
 * Get cashback product data
 * @since   1.1.0
 * @param   integer         $product_id
 * @return  false|array
 */
function sejowoo_get_cashback_product( $product_id ) {

    $cashback = false;

    $enable   = boolval( get_post_meta( $product_id, 'cashback_enable', true) );

    if( $enable ) :

        $value      = floatval( get_post_meta( $product_id, 'cashback_value', true) );
        $type       = get_post_meta( $product_id, 'cashback_type', true );
        $refundable = boolval( get_post_meta( $product_id, 'cashback_refundable', true) );

        return array(
            'label'      => ( 'fixed' === $type ) ? wc_price( $value ) : $value . '%',
            'value'      => $value,
            'refundable' => $refundable,
            'type'       => $type
        );

    endif;

    return $cashback;
}
