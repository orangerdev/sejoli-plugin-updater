<?php
/**
 * Get commission setup
 * @since   1.0.0
 * @param   integer       $commission_id
 * @return  false|array   Return false if no valid commission
 */
function sejowoo_get_commission_setup( $commission_id ) {

    global $sejowoo;

    $setup       = false;

    if( ! isset( $sejowoo['data']['commission'][$commission_id] ) ) :

        $commissions = carbon_get_post_meta( $commission_id, 'commission' );

        foreach( (array) $commissions as $i => $commission ) :

            $tier = $i + 1;

            $setup[$i] = array(
                'value' => floatval( $commission['number'] ),
                'type'  => $commission['type']
            );

        endforeach;

        $sejowoo['data']['commission'][$commission_id] = $setup;

    else :

        $setup = $sejowoo['data']['commission'][$commission_id];

    endif;

    return $setup;
}

/**
 * Get product commission setup
 * @since   1.0.0
 * @param   integer       $product_id
 * @return  false|array     Return false if no valid product commission
 */
function sejowoo_get_product_commission_setup( $product_id ) {

    $commission_id  = intval( get_post_meta( $product_id, 'sejowoo_commission', true) );

    return sejowoo_get_commission_setup( $commission_id );
}

/**
 * Check commission data based on arguments
 * @since   1.0.0
 * @param   array           $args   Accept order_id, item_id and affiliate_id
 * @return  WP_Error|object
 */
function sejowoo_check_commission_data( array $args ) {

    global $sejowoo;

    $respond = $sejowoo['db']->commission::reset()
                ->set_data($args)
                ->check()
                ->respond();

    if( false !== $respond['valid'] ) :

        return $respond['commission'];

    else :

        $error = new WP_Error();

        foreach( (array) $respond['messages']['error'] as $message ) :
            $error->add( $respond['error'], $message);
        endforeach;

        return $error;

    endif;
}

/**
 * Add single commission data
 * @since   1.0.0
 * @param   array $args
 */
function sejowoo_add_commission_data(array $args) {

    $args = wp_parse_args($args, array(
        'order_id'     => 0,
        'item_id'      => 0,
        'product_id'   => 0,
        'buyer_id'     => 0,
        'affiliate_id' => 0,
        'tier'         => 0,
        'quantity'     => 0,
        'commission'   => 0.0,
        'order_status' => 'on-hold',
        'paid_status'  => false
    ));

    $return          = array();
    $commission_data = sejowoo_check_commission_data( $args );
    $error           = new WP_Error();

    if(
        is_wp_error($commission_data) &&
        'data-not-found' === $commission_data->get_error_code()
    ):

        $respond = sejowoo_db('commission')->set_data($args)
                        ->add()
                        ->respond();

        if( false !== $respond['valid'] ) :

            return $respond['commission'];

        else :

            foreach( (array) $respond['messages']['error'] as $message ) :
                $error->add( $respond['error'], $message);
            endforeach;

        endif;

    else :
        $error->add(
            'unable-add-commission',
            __('Unable to add commission', 'sejowoo'),
            $args
        );

    endif;

    if( 0 < count($return) ) :
        return $return;
    endif;

    return $error;
}

/**
 * Update commission order status
 * @since   1.0.0
 * @param   integer $order_id
 * @param   string  $order_status
 * @return  boolean
 */
function sejowoo_update_commission_order_status( $order_id, $order_status ) {

    return sejowoo_db('commission')->set_data(array(
                'order_id'     => $order_id,
                'order_status' => $order_status
            ))
            ->update_order_status()
            ->respond();
}

/**
 * Get commission data from an order
 * @since   1.0.0
 * @param   WC_Order        $order
 * @return  array|false
 */
function sejowoo_get_commissions_from_order( WC_Order $order ) {

    $response = sejowoo_db('commission')->set_data(array(
                        'order_id'     => $order->get_id(),
                        'order_status' => $order->get_status()
                    ))
                    ->get_by_order()
                    ->respond();

    if( false !== $response['valid'] ) :

        $data  = array();
        $items = $order->get_items();

        foreach( $response['commissions'] as $single ) :

            $affiliate_id = $single->affiliate_id;

            if( ! array_key_exists( $affiliate_id, $data ) ) :

                $data[$affiliate_id] = array(
                    'user'        => new \WC_Customer($affiliate_id),
                    'commissions' => array()
                );

            endif;

            $item = $items[$single->item_id];

            $data[$affiliate_id]['commissions'][] = array(
                'value'    => $single->commission,
                'tier'     => $single->tier,
                'quantity' => $single->quantity,
                'item'     => $item,
                'product'  => $item->get_product()
            );

        endforeach;

        return $data;

    endif;

    return false;
}

/**
 * Get total commission from an order
 * @since   1.0.0
 * @param   WC_Order    $order
 * @param   integer     $affiliate_id   Optional, if value is set, then it will return total commission based on affiliate ids
 * @return  array|false
 */
function sejowoo_get_total_commissions_from_order( WC_Order $order, $affiliate_id = NULL  ) {

    $data = array(
        'order_id'     => $order->get_id(),
        'order_status' => $order->get_status()
    );

    if( !empty($affiliate_id) ) :
        $data['affiliate_id'] = $affiliate_id;
    endif;

    $response = sejowoo_db('commission')->set_data($data)
                    ->get_total_by_order()
                    ->respond();

    if( false !== $response['valid'] ) :

        if( 1 < count($response['commissions'])) :
            return $response['commissions'];
        else :
            return $response['commissions'][0];
        endif;

    endif;

    return false;
}

/**
 * Get total commission from an affiliate
 * @since   1.0.0
 * @param   integer     $affiliate_id
 * @return  float
 */
function sejowoo_get_total_affiliate_commission( $affiliate_id = 0) {

    $data = array(
        'affiliate_id' => get_current_user_id()
    );

    if( !empty($affiliate_id) ) :
        $data['affiliate_id'] = $affiliate_id;
    else :

    endif;

    $response = sejowoo_db('commission')->set_data($data)
                    ->get_total_by_affiliate()
                    ->respond();

    if( false !== $response['valid'] ) :
        return floatval($response['commission']);
    endif;

    return 0.0;
}

/**
 * Get product commssion data
 * @since   1.1.0
 * @param   integer         $product_id
 * @return  false|WP_Post
 */
function sejowoo_get_commission_product( $product_id ) {

    global $sejowoo;

    $commission_id = absint( get_post_meta($product_id, 'sejowoo_commission', true));

    if( 0 < $commission_id ) :

        if( array_key_exists( $commission_id, $sejowoo['data']['commission-post'] ) ) :
            $commission = $sejowoo['data']['commission-data'][$commission_id];
        else :
            $commission = get_post( $commission_id );
        endif;

        if( is_a( $commission, 'WP_Post') ) :
            return $commission;
        endif;

    endif;

    return false;
}
