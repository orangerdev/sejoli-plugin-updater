<?php

/**
 * Get list of orders
 * @since   1.0.0
 * @param   array  $args
 * @param   array  $table
 * @return  array
 * - valid      bool
 * - order      array
 * - messages   array
 */
function sejowoo_get_orders(array $args, $table = array()) {

    $args = wp_parse_args($args, array(
        'length'       => $table['length'],
        'offset'       => $table['start'],
        'orderby'      => 'date',
        'order'        => 'DESC',
        'affiliate_id' => NULL,
    ));

    $query_args = array(
        'post_type'              => 'shop_order', // Default WooCommerce order
        'posts_per_page'         => $args['length'],
        'orderby'                => $args['orderby'],
        'order'                  => $args['order'],
        'fields'                 => 'ids',
        'offset'                 => $args['offset'],
        'post_status'            => array_keys(wc_get_order_statuses()),
        'meta_query'             => array(),
        'update_post_meta_cache' => false,
        'update_post_term_cache' => false,
    );

    $table = wp_parse_args($table, [
        'start'   => NULL,
        'length'  => NULL,
        'order'   => NULL,
        'filter'  => NULL
    ]);

    // if(isset($args['date-range']) && !empty($args['date-range'])) :
    //     $table['filter']['date-range'] = $args['date-range'];
    //     unset($args['date-range']);
    // endif;

    if(isset($args['affiliate_id']) && !empty($args['affiliate_id'])) :
        $query_args['meta_query'][] = array(
            'key'   => sejowoo_get_affiliate_key(),
            'value' => absint( $args['affiliate_id'] ),
            'type'  => 'NUMERIC'
        );
    endif;

    $respond = array(
        'orders' => array()
    );

    $query = new \WP_Query( $query_args );

    foreach ( (array) $query->posts as $order_id ) :

        $order = wc_get_order( $order_id );
        $commission = (array) sejowoo_get_total_commissions_from_order( $order, $args['affiliate_id'] );

        foreach( $order->get_items() as $item ) {
            $product_name = $item['name'];
        }

        $respond['orders'][] = array(
            'ID'            => $order->get_id(),
            'date'          => date('Y M d', $order->get_date_created()->getTimestamp()),
            'product_name'  => $product_name,
            'quantity'      => $order->get_item_count(),
            'buyer_name'    => $order->get_formatted_billing_full_name(),
            'buyer_email'   => sejowoo_display_buyer_email( $order->get_billing_email() ),
            'buyer_phone'   => sejowoo_display_buyer_phone( $order->get_billing_phone() ),
            'buyer_address' => sejowoo_display_buyer_address( $order->get_formatted_shipping_address() ),
            'commission'    => wc_price(
                                    ( isset( $commission['total_commission'] ) && 0 < $commission['total_commission'] ) ?
                                        $commission['total_commission'] :
                                        0
                               ),
            'total'         => wc_price( $order->get_total() ),
            'status'        => wc_get_order_status_name( $order->get_status() ),
            'color_status'  => sejowoo_get_label_color( $order->get_status() )
        );

    endforeach;

    $respond['total'] = $query->found_posts;

    return wp_parse_args($respond,[
        'valid'    => true,
        'orders'   => NULL,
        'total'    => 0,
        'messages' => []
    ]);
}
/**
 * Get single order by latest
 * @since   1.0.0
 * @param  array  $args
 * @return array
 * - valid      bool
 * - order      array
 * - messages   array
 */
function sejowoo_get_order(array $args) {

    reset($args);

    $column  = key($args);
    $value   = $args[$column];

    $respond = sejowoo_get_order_by($column, $value);

    // $respond = SejoliSA\Model\Order::reset()
    //                 ->get_by($column, $value )
    //                 ->respond();

    // if(false !== $respond['valid']) :
    //     $respond['orders']['meta_data'] = maybe_unserialize($respond['orders']['meta_data']);
    //     $respond['orders'] = apply_filters('sejowoo/order/order-detail', $respond['orders']);
    // endif;

    return wp_parse_args($respond,[
        'valid'    => false,
        'orders'   => NULL,
        'messages' => []
    ]);
}

/**
 * Get single order by field
 * @since   1.0.0
 * @param   string  $field ID
 * @param   mixed   $value
 * @return array
 * - valid      bool
 * - order      array
 * - messages   array
 */
function sejowoo_get_order_by($field, $value) {

    reset($args);

    $respond = [];

    if( $field == 'ID' ) :
        $respond['orders'] = sejowoo_get_order_details($value);
        $respond['valid'] = true;
    endif;

    // $column  = key($args);
    // $value   = $args[$column];
    // $respond = SejoliSA\Model\Order::reset()
    //                 ->get_by($column, $value )
    //                 ->respond();

    // if(false !== $respond['valid']) :
    //     $respond['orders']['meta_data'] = maybe_unserialize($respond['orders']['meta_data']);
    //     $respond['orders'] = apply_filters('sejowoo/order/order-detail', $respond['orders']);
    // endif;

    return wp_parse_args($respond,[
        'valid'    => false,
        'orders'   => NULL,
        'messages' => []
    ]);
}

/**
 * Get formatted order details
 * @since   1.0.0
 * @param   mixed   $order      WC_Order or $order_id
 * @return  integer
 */
function sejowoo_get_order_details($order) {
    if( ! is_object( $order ) ) :
        $order = wc_get_order( $order );
    endif;

    $order_items = [];
    foreach ( $order->get_items() as $item_id => $item ) :

        $order_items[] = array(
            'product_id'    => $item->get_product_id(),
            'variation_id'  => $item->get_variation_id(),
            // 'product'       => $item->get_product(),
            'name'          => $item->get_name(),
            'quantity'      => $item->get_quantity(),
            'subtotal'      => $item->get_subtotal(),
            'total'         => $item->get_total(),
            'tax'           => $item->get_subtotal_tax(),
            'meta_data'     => $item->get_meta_data()
        );

    endforeach;

    $data = array(
        'ID'			=> $order->get_id(),
        'quantity'		=> $order->get_item_count(),
        'user_name'		=> $order->get_formatted_billing_full_name(),
        'grand_total'	=> $order->get_total(),
        'status'		=> $order->get_status(),
        'affiliate_id'  => 0,
        'affiliate'     => false,
        'subscription'  => null,
        'items'         => $order_items,
        'type'          => 'subscription-signup',
        'created_at'    => $order->get_date_created()->format('Y-m-d H:i:s'),
        'user'          => $order->get_user()

        // id : order_id,
        // date : sejowoo.convertdate(response.created_at),
        // buyer_name : response.user.data.display_name,
        // buyer_email : response.user.data.user_email,
        // buyer_phone : response.user.data.meta.phone,
        // variants : variants,
        // product_name : response.product.post_title,
        // quantity : response.quantity,
        // total : sejowoo_member_area.text.currency + sejowoo.formatPrice(response.grand_total),
        // status : sejowoo_member_area.order.status[response.status],
        // color : sejowoo_member_area.color[response.status],
        // subscription : (null != subscription) ? subscription.toUpperCase() : null,
        // courier : response.courier,
        // address : response.address,
        // parent_order : response.order_parent_id,
        // affiliate_name : affiliate_name,
        // affiliate_phone : affiliate_phone,
        // affiliate_email : affiliate_email
    );

    return (object) $data;
}
