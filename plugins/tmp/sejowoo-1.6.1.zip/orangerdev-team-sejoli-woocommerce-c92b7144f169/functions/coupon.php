<?php
/**
 * Ge all available to affiliate use coupons
 * @since   1.0.0
 * @return  array
 */
function sejowoo_get_affiliated_coupons() {

    $coupons = array();

    $response = sejowoo_db('coupon')->get_affiliated_coupons()
                    ->respond();

    if( false !== $response['valid'] ) :
        $coupons = $response['coupons'];
    endif;

    return $coupons;
}

/**
 * Get total affiliate coupons
 * @since   1.0.0
 * @param   integer $affiliate_id
 * @param   integer $parent_coupon_id
 * @return  integer
 */
function sejowoo_get_total_affiliate_coupon( $affiliate_id = 0, $parent_coupon_id = 0) {

    $affiliate_id = ( 0 === $affiliate_id ) ? get_current_user_id() : $affiliate_id;

    $response = sejowoo_db('coupon')
                    ->set_data(array(
                        'affiliate_id'     => $affiliate_id,
                        'parent_coupon_id' => $parent_coupon_id
                    ))
                    ->get_total_affiliate_coupon()
                    ->respond();

    if( false !== $response['valid'] ) :
        return $response['total_coupons'];
    endif;

    return 0;

}

/**
 * Create affiliate coupon
 * @since   1.0.0
 * @param   string  $coupon_code
 * @param   integer $affiliate_id
 * @param   integer $parent_coupon_id
 * @return  WP_Error|WC_Coupon
 */
function sejowoo_create_affiliate_coupon( $coupon_code, $affiliate_id, $parent_coupon_id ) {


    $response = sejowoo_db('coupon')
                    ->set_data(array(
                        'coupon_code'      => $coupon_code,
                        'affiliate_id'     => $affiliate_id,
                        'parent_coupon_id' => $parent_coupon_id
                    ))
                    ->create_affiliate_coupon()
                    ->respond();

    if( false !== $response['valid'] && is_a($response['coupon'], 'WC_Coupon')) :
        return $response['coupon'];
    endif;

    return new WP_Error(
        'unable-create-affiliate-coupon',
        __('Tidak bisa membuat kupon affiliasi', 'sejowoo')
    );
}

/**
 * Get all available coupon list, return array with coupon ID
 * @since   1.0.0
 * @param   array   $args
 * @param   array   $table
 * @return  array
 */
function sejowoo_get_available_coupon_list( array $args, $table = array() ) {

    $args = wp_parse_args($args, array(
        'affiliate_id' => NULL,
    ));

    $query = sejowoo_db('coupon')->set_data( $args )
                ->set_data_start($table['start']);

    if(0 < $table['length']) :
        $query->set_data_length($table['length']);
    endif;

    $response = $query->get()->respond();

    return wp_parse_args($response,[
        'valid'    => false,
        'coupons'  => $response['coupons'],
        'messages' => []
    ]);
}

/**
 * Update all affiliated coupon meta data based on parent coupon
 * @since   1.0.0
 * @param   integer     $parent_coupon_id
 * @return  integer     Return with total affiliated coupons updated
 */
function sejowoo_update_affiliate_coupons( $parent_coupon_id ) {

    $args = array(
        'parent_coupon_id'  => $parent_coupon_id
    );

    $response = sejowoo_db('coupon')->set_data( $args )
                    ->update_affiliate_coupons()
                    ->respond();

    return $response['total'];

}
