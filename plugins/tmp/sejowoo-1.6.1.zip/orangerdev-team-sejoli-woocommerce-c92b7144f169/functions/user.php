<?php
/**
 * Get multiple user data
 * @since   1,0.0
 * @param   array  $multiple_user_ids [description]
 * @return  array
 */
function sejowoo_get_users(array $multiple_user_ids) {
    $user_data = [];

    $users = get_users([
        'include'   => $multiple_user_ids
    ]);

    foreach( $users as $user ) :

        $user_data[$user->ID] = $user;
        $user_data[$user->ID]->meta = new stdClass();
        $user_data[$user->ID]->meta = apply_filters('sejowoo/user/meta-data', $user);

    endforeach;

    return $user_data;
}

/**
 * Get user data, user meta will be extended by hook
 * @param  mixed    $by_value accepted values are email, id and phone number
 * @return mixed    WP_Post or false
 */
function sejowoo_get_user($by_value) {

    global $sejowoo;

    $user = false;
    $get_from_temp = false;

    if(is_email($by_value)) :

        $user = get_user_by('email', $by_value);

    elseif(0 < absint($by_value) && 5 > strlen($by_value)) :

        if(isset($sejowoo['users'][$by_value])) :
            $user          = $sejowoo['users'][$by_value];
            $get_from_temp = true;
        else :
            $user = get_user_by('id', $by_value);
        endif;

    elseif(!empty($by_value)) :
        $users = get_users([
            'number'     => 1,
            'meta_key'   => '_phone',
            'meta_value' => trim($by_value)
        ]);

        $user = (is_array($users) && 0 < count($users)) ? $users[0] : $user;
    endif;

    if(false === $get_from_temp && is_a($user, 'WP_User')) :
        $user->meta = new stdClass();
        $sejowoo['users'][$user->ID] = $user = apply_filters('sejowoo/user/meta-data', $user);
    endif;

    return $user;
}

/**
 * Get user_group data as array for select options
 * @since   1.3.3
 * @return  array
 */
function sejowoo_get_user_group_options() {

    global $sejowoo;

    if(
        ( is_array( $sejowoo ) ) &&
        (!array_key_exists('user-groups', $sejowoo) ||
        0 < count($sejowoo['user-groups']))
    ) :

        $user_group_data = [];

        $user_groups = get_posts([
            'posts_per_page' => -1,
            'post_type'      => SEJOWOO_USER_GROUP_CPT,
            'meta_key'       => '_priority',
            'orderby'        => 'meta_value',
            'order'          => 'ASC'
        ]);

        foreach( (array) $user_groups as $user_group ) :

            $user_group_data[ $user_group->ID ] = sprintf(
                                                    __('%s ( LVL %s )', 'sejowoo'),
                                                    $user_group->post_title,
                                                    get_post_meta($user_group->ID, '_priority', true)
                                                  );

        endforeach;

        $sejowoo['user-groups'] = $user_group_data;

    endif;

    return ( !empty($sejowoo['user-groups']) ) ? $sejowoo['user-groups'] : [];
}


/**
 * Get user group detail
 * @since   1.3.0
 * @since   1.4.0       Add extra conditional to check if no group for current user
 * @param   integer     $group_id
 * @return  array|false
 */
function sejowoo_get_group_detail($group_id) {

    global $sejowoo;

    $group_data = false;

    if(
        !empty($group_id) &&
        array_key_exists('group', $sejowoo) &&
        array_key_exists($group_id, $sejowoo['group'])
    ) :
        $group_data = $sejowoo['group'][$group_id];
    endif;

    if(false === $group_data && !empty($group_id)) :
        $group = get_post($group_id);

        $group_data = array(
            'name'                => $group->post_title,
            'affiliate'           => boolval(carbon_get_post_meta($group_id, 'can_view_affiliate')),
            'priority'            => carbon_get_post_meta($group_id, 'priority'),
            'enable_discount'     => carbon_get_post_meta($group_id, 'group_discount_enable'),
            'discount_price'      => floatval(carbon_get_post_meta($group_id, 'group_discount_price')),
            'discount_price_type' => carbon_get_post_meta($group_id, 'group_discount_price_type'),
            'commissions'         => array(),
            'per_product'         => array(),
            'upgrade'   => array(
                'enable'    => boolval( carbon_get_post_meta($group_id, 'enable_user_group_upgrade')),
                'first_buy' => floatval( carbon_get_post_meta($group_id, 'first_purchase_upgrade_min_checkout')),
                'option'    => carbon_get_post_meta($group_id, 'upgrade_user_group')
            )
        );

        $commissions = carbon_get_post_meta($group_id, 'group_commissions');
        $per_product = carbon_get_post_meta($group_id, 'group_setup_per_product');

        $group_data['commissions'] = sejowoo_set_group_commission($commissions);

        if(is_array($per_product) && 0 < count($per_product)) :

            foreach($per_product as $detail) :

                $group_data['per_product'][$detail['product']] = array(
                    'enable_discount'     => $detail['discount_enable'],
                    'discount_price'      => floatval($detail['discount_price']),
                    'discount_price_type' => $detail['discount_price_type'],
                    'commissions'         => array()
                );

                $per_product_commissions    = $detail['commission'];

                $group_data['per_product'][$detail['product']]['commissions'] = sejowoo_set_group_commission($per_product_commissions);

                //
                // I put comment block here since i'm afraid it will reduce the system performance
                //
                // $group_data['per_product'][$detail['product']] = apply_filters(
                //                                                     'sejoli/user-group/per-product/detail',
                //                                                     $group_data['per_product'][$detail['product']],
                //                                                     $detail
                //                                                  );

            endforeach;
        endif;

        $group_data = apply_filters('sejowoo/user-group/detail', $group_data, $group_id, $commissions, $per_product);

    endif;

    return $group_data;
}

/**
 * Set group commission detail
 * @since   1.3.0
 * @param   array $commissions
 * @return  array
 */
function sejowoo_set_group_commission(array $commissions) {

    $commission_data = array();

    if(is_array($commissions) && 0 < count($commissions)) :
        foreach($commissions as $i => $_detail) :
            $tier = $i + 1;
            $commission_data[$tier] = array(
                'tier'  => $tier,
                'fee'   => floatval($_detail['number']),
                'type'  => $_detail['type']
            );
        endforeach;
    endif;

    return $commission_data;
}

/**
 * Return all available colors
 * @since   1.0.0
 * @return  array
 */
function sejowoo_get_all_colors() {

    $code = dechex(crc32('payment-confirm'));
    $confirm_color = '#'.substr($code, 0, 6);

    return [
        'completed'       => '#27ae60',
        'paid'            => '#27ae60',
        'shipping'        => '#16a085',
        'in-progress'     => '#2980b9',
        'payment-confirm' => $confirm_color,
        'on-hold'         => '#7f8c8d',
        'cancelled'       => '#d35400',
        'refunded'        => '#c0392b',
        'pending'         => '#7f8c8d',
        'added'           => '#2980b9',
        'inactive'        => '#c0392b',
        'active'          => '#2ecc71',
        'expired'         => '#c0392b'
    ];
}

/**
 * Update user group, set force true if there is no check group level
 * If force is false then current user's group will be checked based on $action_type
 * @since   1.3.0
 * @param   integer  $user_id
 * @param   integer  $group_id
 * @param   boolean  $force
 * @param   string   $action_type   Values are upgrade and downgrade
 * @return  true|WP_error
 */
function sejowoo_update_user_group($user_id, $group_id, $force = false, $action_type = 'upgrade') {

    $need_update = false;

    // Need checking first before update
    if(false === $force) :

        $current_user_group = intval(carbon_get_user_meta($user_id, 'user_group'));

        // User group is not set
        if(0 === $current_user_group) :
            $need_update = true;
        else :

            $group_priority          = sejowoo_get_user_group_priority();
            $current_group_priority  = (int) (array_key_exists($current_user_group, $group_priority)) ? $group_priority[$current_user_group] : 0;
            $selected_group_priority = (int) (array_key_exists($group_id, $group_priority)) ? $group_priority[$group_id] : 0;

            if(0 === $current_group_priority) :
                $need_update = true;
            elseif('upgrade' === $action_type && $current_group_priority < $selected_group_priority ) :
                $need_update = true;
            elseif('downgrade' === $action_type && $current_group_priority > $selected_group_priority ) :
                $need_update = true;
            endif;

        endif;

    // Force to update user group and ignore group level
    else :

        $need_update = true;

    endif;

    if(false !== $need_update) :

        update_user_meta($user_id, '_user_group', $group_id);
        return true;

    else :
        $error = new \WP_Error();
        $error->add($type, $message);

        return $error;
    endif;
}

/**
 * Get user group priority
 * @since   1.3.0
 * @return  array
 */
function sejowoo_get_user_group_priority() {

    global $sejowoo;

    if(
        !array_key_exists('user-group-priority', $sejowoo) ||
        0 < count($sejowoo['user-group-priority'])
    ) :

        $user_group_data = [];

        $user_groups = get_posts([
            'posts_per_page' => -1,
            'post_type'      => SEJOWOO_USER_GROUP_CPT,
            'meta_key'       => '_priority',
            'orderby'        => 'meta_value',
            'order'          => 'ASC'
        ]);

        foreach( (array) $user_groups as $user_group ) :

            $user_group_data[ $user_group->ID ] = intval(carbon_get_post_meta($user_group->ID, 'priority'));

        endforeach;

        $sejowoo['user-group-priority'] = $user_group_data;

    endif;

    return $sejowoo['user-group-priority'];
}

/**
 * Check user group with product
 * @since  1.0.0
 * @param  WP_Post|integer  $product
 * @param  integer          $user_id
 * @return array
 */
function sejowoo_check_user_permission_by_product_group($product, $user_id = 0) {

    $allow_buy      = true;
    $disallowed     = NULL;
    $error          = new WP_Error();
    if( is_user_logged_in() ) :
        $user_id        = (0 === $user_id) ? get_current_user_id() : $user_id;
    endif;
    $user           = ( is_user_logged_in() ) ? sejowoo_get_user($user_id) : false;
    $product        = (is_a($product, 'WP_Post')) ? $product : sejowoo_get_product($product);
    $group_priority = sejowoo_get_user_group_priority();
    $group_options  = sejowoo_get_user_group_options();
    $group_options['0'] = 'User yang belum login';

    if(
        false !== $product->group['buy_group'] &&
        !is_a($user, 'WP_User') &&
        !in_array('0', $product->group['buy_group_list'])
    ) :

        $error->add('disallowed', __('Not valid user', 'sejowoo'));

        return array(
            'allow' => false,
            'error' => array (
                'type'    => 'not-logged-in-user',
                'message' => $error->get_error_messages()
            )
        );

    elseif(
        false !== $product->group['buy_group'] &&
        property_exists($user->meta, 'group_id') &&
        !empty($user->meta->group_id) &&
        !in_array($user->meta->group_id, (array) $product->group['buy_group_list'])
    ) :

        $allow_buy = false;
        $disallowed  = 'not-in-group';

        $error->add(
            'disallowed',
            $product->group["buy_restricted_message"],
            array(
                "buyable-group" => $product->group['buy_group_list'],
                "current-user-group" => $user->meta->group_id,
            )
        );

    endif;

    return array(
        'allow' => $allow_buy,
        'error' => array(
            'type'    => $disallowed,
            'message' => $error->get_error_messages()
        )
    );
}

/**
 * Get upline list of an user
 * @since   1.0.0
 * @param   integer     $user_id
 * @param   integer     $limit
 * @param   string      $return
 * @return  array       $users
 */
function sejowoo_user_get_uplines($user_id = 0, $limit = 0, $return = 'id')
{
    $user_id = absint($user_id);
    $user_id = ( 0 === $user_id ) ? get_current_user_id() : $user_id;
    $limit   = absint( apply_filters('sejoli/affiliate/max-upline', $limit) );

    $respond = Sejowoo\Database\Affiliate::reset()
                    ->set_user_id($user_id)
                    ->set_upline_tier($limit)
                    ->get_uplines()
                    ->respond();

    if(true === $respond['valid']) :
        return apply_filters('sejoli/user/uplines',$respond['uplines']);
    endif;

    return false;
}

/**
 * Get downline list of an user
 * @param  integer $user_id [description]
 * @param  integer $limit
 * @param  string  $return
 * @return array   $users
 */
function sejowoo_user_get_downlines($user_id = 0, $limit = 0, $return = 'id')
{
    $user_id = absint($user_id);
    $user_id = (0 === $user_id) ? get_current_user_id() : $user_id;
    $limit   = absint( apply_filters('sejoli/affiliate/max-downline',$limit) );

    $respond = Sejowoo\Database\Affiliate::reset()
                    ->set_user_id($user_id)
                    ->set_downline_tier($limit)
                    ->get_downlines()
                    ->respond();

    if(true === $respond['valid']) :
        return apply_filters('sejoli/user/downlines',$respond['downlines']);
    endif;

    return false;
}

/**
 * Do we need to to display buyer email
 * @since   1.0.0
 * @return  boolean|string
 */
function sejowoo_display_buyer_email( $email ) {

    return
        ( true !== boolval( carbon_get_theme_option( 'sejowoo_display_buyer_email' ) ) ) ?
        NULL :
        $email;
}

/**
 * Do we need to to display buyer address
 * @since   1.0.0
 * @return  boolean|string
 */
function sejowoo_display_buyer_address( $address ) {

    return
        ( true !== boolval( carbon_get_theme_option( 'sejowoo_display_buyer_address' ) ) ) ?
        NULL :
        $address;
}

/**
 * Do we need to to display buyer address
 * @since   1.0.0
 * @return  boolean|string
 */
function sejowoo_display_buyer_phone( $phone ) {
    return
        ( true !== boolval( carbon_get_theme_option( 'sejowoo_display_buyer_phone' ) ) ) ?
        NULL :
        $phone;
}
