=== Plugin Name ===
Contributors: (this should be a list of wordpress.org userid's)
Donate link: https://ridwan-arifandi.com
Tags: membership, wallet, point, cashback
Requires at least: 6.0.0
Tested up to: 6.0.2
Stable tag: 1.2.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add Wallet feature to Sejoli Premium Membership Plugin

== Description ==

== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload `sejoli-wallet.zip` to the `/wp-content/plugins/` directory

== Frequently Asked Questions ==

= A question that someone might have =

An answer to that question.

= What about foo bar? =

Answer to foo bar dilemma.

== Screenshots ==

1. This screen shot description corresponds to screenshot-1.(png|jpg|jpeg|gif). Note that the screenshot is taken from
the /assets directory or the directory that contains the stable readme.txt (tags or trunk). Screenshots in the /assets
directory take precedence. For example, `/assets/screenshot-1.png` would win over `/tags/4.3/screenshot-1.png`
(or jpg, jpeg, gif).
2. This is the second screen shot

== Changelog ==

= 1.2.1
Improve performance

= 1.2.0
Add bump sale feature integration
Add export data to CSV
Add support to currency
Fix issue with cashback with quantity
Fix issue with coupon usage

= 1.1.4 =
Fix error when showing unmatched number
Fix error notice
Fix export csv data

= 1.1.3 =
Fix wrong cashback calculation

= 1.1.2 =
Fix several issue

* 1.1.1 *
Fix problem in select2 not loading

* 1.1.0 *
Add manual input wallet form

* 1.0.0 *
First release
