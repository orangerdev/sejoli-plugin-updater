<?php
    printf(
        __('%s telah melakukan permintaan pencairan dana sebesar %s. Silahkan cek halaman admin untuk informasi rekening', 'sejoli'),
        '{{buyer-name}}',
        '{{request-fund}}'
    );
