<?php
    printf(
        __('Anda telah melakukan permintaan pencairan dana sebesar %s', 'sejoli'),
        '{{request-fund}}'
    );
