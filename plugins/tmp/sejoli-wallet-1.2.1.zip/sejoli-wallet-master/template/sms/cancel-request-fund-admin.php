<?php
    printf(
        __('Pencairan dana sebesar %s oleh %s telah dibatalkan. Dana dikembalikan ke saldo', 'sejoli'),
        '{{request-fund}}',
        '{{buyer-name}}'
    );
