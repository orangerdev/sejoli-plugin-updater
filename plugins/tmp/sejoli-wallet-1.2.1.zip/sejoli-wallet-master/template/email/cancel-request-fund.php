<p>
<?php
    printf(
        __('Pencairan dana sebesar %s telah dibatalkan oleh kami.', 'sejoli'),
        '{{request-fund}}'
    );
?>
</p>
<p>
<?php
    printf(
        __('Dana sebesar %s telah kami kembalikan ke saldo membership anda.', 'sejoli'),
        '{{request-fund}}'
    );
?>
</p>
