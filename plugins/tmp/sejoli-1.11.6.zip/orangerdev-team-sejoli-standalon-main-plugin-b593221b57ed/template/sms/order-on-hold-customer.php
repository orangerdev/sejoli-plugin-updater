Halo {{buyer-name}}, pesanan anda untuk order {{order-id}} sebesar {{order-grand-total}} sudah kami terima. Segera lakukan pembayaran ke {{payment-gateway}} ya sebelum {{close-time}}
