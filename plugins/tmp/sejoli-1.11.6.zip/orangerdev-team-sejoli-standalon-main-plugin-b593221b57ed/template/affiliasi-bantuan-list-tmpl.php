<div class="item">
    <div class="content">
        <a data-product-id="{{:product_id}}" data-key="{{:key}}" class="header help-detail">{{:title}}</a>
    </div>
</div>