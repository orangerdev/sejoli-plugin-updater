<p><?php printf(__('Kamu baru saja mendapatkan order sebagai berikut dari %s', 'sejoli'),'{{buyer-name}}' ); ?></p>
{{order-detail}}
{{order-meta}}
