<p><?php printf(__('Halo %s', 'sejoli'),'{{buyer-name}}' ); ?></p>
<p><?php _e('Terima kasih Pembayaran {{buyer-name}} telah berhasil kami terima dan verifikasi. Semoga rezekinya {{buyer-name}} oleh Alloh diluaskan seluas lautan, usahanya diberikan keuntungan berlimpah, keluarganya diberikan kesehatan, dilancarkan segala urusannya, sisa umurnya diberikan keberkahan dan transaksi kita di ridhoi Alloh SWT. Aamiin...', 'sejoli'); ?></p>
<p><?php __('Berikut detail pembelian {{buyer-name}}', 'sejoli'); ?>
{{order-detail}}
{{order-meta}}
