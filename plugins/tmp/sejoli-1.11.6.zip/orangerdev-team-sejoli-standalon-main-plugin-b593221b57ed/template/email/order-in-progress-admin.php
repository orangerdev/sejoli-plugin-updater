<p><?php _e('Halo admin, pesanan berikut telah selesai dibayarkan. Harap segera diproses', 'sejoli'); ?></p>
<p><?php __('Berikut detail pembelian {{buyer-name}}', 'sejoli'); ?>
{{order-detail}}
{{order-meta}}
