<p><?php printf(__('Alhamdulillah %s', 'sejoli'), '{{affiliate-name}}'); ?></p>

<p><?php printf(__('Kamu baru saja mendapatkan order sebagai berikut dari %s', 'sejoli'),'{{buyer-name}}' ); ?></p>

{{order-detail}}
{{order-meta}}

<p><?php printf( __('Pantau terus ya, jika perlu follow-up terus %s sampai deal ya.', 'sejoli'), '{{buyer-name}}'); ?></p>
