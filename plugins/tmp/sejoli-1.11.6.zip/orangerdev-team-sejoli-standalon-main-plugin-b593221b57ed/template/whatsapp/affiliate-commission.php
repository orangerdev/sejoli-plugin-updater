*<?php _e('Komisi Affiliasi', 'sejoli'); ?>*.

<?php printf(__('%s %s (Tier %s)', 'sejoli'), $affiliate['affiliate_name'], $affiliate['commission'], $affiliate['tier']); ?>.
