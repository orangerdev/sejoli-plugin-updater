<?php //empty like your hope
