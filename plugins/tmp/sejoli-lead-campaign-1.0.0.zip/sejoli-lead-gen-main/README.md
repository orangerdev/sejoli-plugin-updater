# sejoli-lead-gen
Add lead functions for Sejoli - Premium Membership WordPress plugin
